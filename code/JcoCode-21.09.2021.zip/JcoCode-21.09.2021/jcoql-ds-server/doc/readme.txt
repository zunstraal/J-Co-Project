J-CO-QL-DS Server

The main catalog is a file called instance.metadata containing the settings of the instance.

Every database inside the DS Server is a folder with the followind structure:
- one file db.metadata containing the settings of the database
- every collection is a file named <collection name>.collection i.e.: movies.collection