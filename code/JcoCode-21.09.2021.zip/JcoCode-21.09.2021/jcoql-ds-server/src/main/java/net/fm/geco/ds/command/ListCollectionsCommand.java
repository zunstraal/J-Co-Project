package net.fm.geco.ds.command;

import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.ListCollectionsResponseMessage;
import net.fm.geco.ds.service.DataSourceService;

@JcoDsCommand
public class ListCollectionsCommand extends AbstractCommand {
	
	private final DataSourceService dataSourceService;

	public ListCollectionsCommand(DataSourceService dataSourceService) {
		super(MessageCodes.LIST_COLLECTIONS);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		String database = (String) request.getParams().get("database");
		return new ListCollectionsResponseMessage(database, dataSourceService.listCollections(database));
	}

}
