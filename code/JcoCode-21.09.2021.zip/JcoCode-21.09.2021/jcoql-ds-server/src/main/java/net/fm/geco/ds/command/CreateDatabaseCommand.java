package net.fm.geco.ds.command;

import java.util.Map;
import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.CreateDatabaseResponseMessage;
import net.fm.geco.ds.message.response.ErrorResponseMessage;
import net.fm.geco.ds.service.DataSourceService;
import net.fm.geco.ds.util.DataSourceUtils;

@JcoDsCommand
public class CreateDatabaseCommand extends AbstractCommand {
	
	private final DataSourceService dataSourceService;

	public CreateDatabaseCommand(DataSourceService dataSourceService) {
		super(MessageCodes.CREATE_DATABASE);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		Map<String, Object> params = request.getParams();
		String name = (String) params.get("name");
		if(DataSourceUtils.validDatabaseName(name)) {
			return new CreateDatabaseResponseMessage(dataSourceService.createDatabase(name));
		} else {
			return new ErrorResponseMessage("Invalid database name");
		}
	}

}
