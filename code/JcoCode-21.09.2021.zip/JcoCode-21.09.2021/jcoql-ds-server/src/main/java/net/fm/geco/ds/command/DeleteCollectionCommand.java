package net.fm.geco.ds.command;

import java.util.Map;
import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.DeleteCollectionResponseMessage;
import net.fm.geco.ds.service.DataSourceService;

@JcoDsCommand
public class DeleteCollectionCommand extends AbstractCommand {
	
	private final DataSourceService dataSourceService;

	public DeleteCollectionCommand(DataSourceService dataSourceService) {
		super(MessageCodes.DELETE_COLLECTION);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		Map<String, Object> params = request.getParams();
		String database = (String) params.get("database");
		String name = (String) params.get("name");
		return new DeleteCollectionResponseMessage(dataSourceService.deleteCollection(database, name));
	}

}
