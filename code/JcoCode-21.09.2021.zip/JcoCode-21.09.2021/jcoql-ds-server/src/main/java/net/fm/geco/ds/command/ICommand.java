package net.fm.geco.ds.command;

import java.util.Properties;

import net.fm.geco.ds.message.IMessageData;

public interface ICommand {
	
	long getCode();

	IMessageData execute(final Properties serverSettings, final Properties instanceMetadata, IMessageData request);
	
}
