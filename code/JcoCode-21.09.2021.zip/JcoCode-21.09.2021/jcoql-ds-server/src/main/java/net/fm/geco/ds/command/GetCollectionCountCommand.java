package net.fm.geco.ds.command;

import java.util.Map;
import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.GetCollectionCountResponseMessage;
import net.fm.geco.ds.service.DataSourceService;

@JcoDsCommand
public class GetCollectionCountCommand extends AbstractCommand {
	
	private final DataSourceService dataSourceService;

	public GetCollectionCountCommand(DataSourceService dataSourceService) {
		super(MessageCodes.GET_COLLECTION_COUNT);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		Map<String, Object> params = request.getParams();
		String database = (String) params.get("database");
		String collection = (String) params.get("collection");
		GetCollectionCountResponseMessage response = new GetCollectionCountResponseMessage(database, collection, dataSourceService.getCollectionCount(database, collection));
		return response;
	}

}
