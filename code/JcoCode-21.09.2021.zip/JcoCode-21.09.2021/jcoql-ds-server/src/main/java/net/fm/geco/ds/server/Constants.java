package net.fm.geco.ds.server;

public final class Constants {
	
	public static final String SETTINGS_CONFIG_PATH = "config";
	public static final String SETTINGS_CONFIG_FILE = "settings.properties";
	public static final String SETTINGS_SERVER_PORT = "server.port";
	public static final String SETTINGS_SERVER_DATA_PATH = "server.data-path";

	public static final String DEFAULT_SETTINGS_SERVER_PORT = "44446";

	public static final String INSTANCE_METADATA_FILE = "instance.metadata";
	public static final String DATABASE_METADATA_FILE = "database.metadata";
	public static final String COLLECTION_FILE = "collection.data";
	public static final String COLLECTION_INDEX_FILE = "collection.idx";
}
