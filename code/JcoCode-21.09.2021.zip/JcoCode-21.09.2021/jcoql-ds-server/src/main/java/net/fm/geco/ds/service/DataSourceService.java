package net.fm.geco.ds.service;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import net.fm.geco.ds.datatype.CollectionWrapper;

public interface DataSourceService {

	Properties getServerSettings();
	Properties getInstanceMetadata();
	
	boolean createDatabase(String name);
	boolean deleteDatabase(String name);
	List<String> listDatabases();

	boolean createCollection(String database, String collectionName);
	boolean deleteCollection(String database, String collectionName);
	List<String> listCollections(String database);
	CollectionWrapper getCollection(String database, String collection);
	CollectionWrapper getCollection(String database, String collection, Integer limit, Integer offset, Integer batchSize);
	boolean saveCollection(String database, String collection, List<Map<String, Object>> documents, boolean append);
	Long getCollectionCount(String database, String collection);

}