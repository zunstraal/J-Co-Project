package net.fm.geco.ds.command;

import java.util.Map;
import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.datatype.CollectionWrapper;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.GetCollectionResponseMessage;
import net.fm.geco.ds.service.DataSourceService;

@JcoDsCommand
public class GetCollectionCommand extends AbstractCommand {
	
	private final DataSourceService dataSourceService;

	public GetCollectionCommand(DataSourceService dataSourceService) {
		super(MessageCodes.GET_COLLECTION);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		Map<String, Object> params = request.getParams();
		String database = (String) params.get("database");
		String collection = (String) params.get("collection");
		Integer limit = (Integer) params.get("limit");
		Integer offset = (Integer) params.get("offset");
		Integer batchSize = (Integer) params.get("batchSize");
		CollectionWrapper collectionWrapper = dataSourceService.getCollection(database, collection, limit, offset, batchSize);
		GetCollectionResponseMessage response = new GetCollectionResponseMessage(database, collection, collectionWrapper);
		return response;
	}

}
