package net.fm.geco.ds.command;

import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.PingResponseMessage;

@JcoDsCommand
public class PingCommand extends AbstractCommand {
	
	public PingCommand() {
		super(MessageCodes.PING);
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		return new PingResponseMessage();
	}

}
