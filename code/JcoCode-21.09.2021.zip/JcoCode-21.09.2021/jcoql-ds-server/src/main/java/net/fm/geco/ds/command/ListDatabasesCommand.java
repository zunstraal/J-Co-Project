package net.fm.geco.ds.command;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.ListDatabasesResponseMessage;
import net.fm.geco.ds.service.DataSourceService;

@JcoDsCommand
public class ListDatabasesCommand extends AbstractCommand {
//	private static final Logger logger = LoggerFactory.getLogger(ListDatabasesCommand.class);
	
	private final DataSourceService dataSourceService;
	
	@Autowired
	public ListDatabasesCommand(DataSourceService dataSourceService) {
		super(MessageCodes.LIST_DATABASE);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		return new ListDatabasesResponseMessage(dataSourceService.listDatabases());
	}

}
