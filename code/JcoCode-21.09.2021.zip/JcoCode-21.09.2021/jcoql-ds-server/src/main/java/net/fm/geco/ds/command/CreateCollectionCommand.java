package net.fm.geco.ds.command;

import java.util.Map;
import java.util.Properties;

import net.fm.geco.ds.annotation.JcoDsCommand;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;
import net.fm.geco.ds.message.response.CreateCollectionResponseMessage;
import net.fm.geco.ds.message.response.ErrorResponseMessage;
import net.fm.geco.ds.service.DataSourceService;
import net.fm.geco.ds.util.DataSourceUtils;

@JcoDsCommand
public class CreateCollectionCommand extends AbstractCommand {
	
	private final DataSourceService dataSourceService;

	public CreateCollectionCommand(DataSourceService dataSourceService) {
		super(MessageCodes.CREATE_COLLECTION);
		this.dataSourceService = dataSourceService;
	}

	@Override
	protected IMessageData doExecute(Properties serverSettings, Properties instanceMetadata, IMessageData request) {
		Map<String, Object> params = request.getParams();
		String database = (String) params.get("database");
		String name = (String) params.get("name");
		if(DataSourceUtils.validCollectionName(name)) {
			return new CreateCollectionResponseMessage(dataSourceService.createCollection(database, name));
		} else {
			return new ErrorResponseMessage("Invalid collection name");
		}
	}

}
