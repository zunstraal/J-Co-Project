package net.fm.geco.ds.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import net.fm.geco.ds.Server;
import net.fm.geco.ds.datatype.CollectionWrapper;
import net.fm.geco.ds.datatype.json.GeoJsonValueSerializer;
import net.fm.geco.ds.datatype.json.JcoValueDeserializer;
import net.fm.geco.ds.server.Constants;
import net.fm.geco.ds.service.DataSourceService;
import net.fm.geco.ds.util.DirectoryFileFilter;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.Value;

@Service
@Profile("server")
public class DataSourceServiceImpl implements DataSourceService {
	
	private static final Logger logger = LoggerFactory.getLogger(Server.class);
	
	//Maximum response message size (20 MB)
	private static final int MAX_MESSAGE_SIZE = 1024 * 1024 * 20;
	private static final int MAX_PER_BATCH = 5000;
	
	private final Properties settings;
	private final Properties instanceMetadata;
	private final ObjectMapper jsonMapper;
	
	private File dataDirectory;

	
	@Autowired
	public DataSourceServiceImpl() {
		this.settings = new Properties();
		this.instanceMetadata = new Properties();
		
		jsonMapper = new ObjectMapper();
	}
	
	@PostConstruct
	protected void init() {
		loadSettings();
		startupDatabase();
		initSerializer();
	}
	
	private void loadSettings() {
		try {
			InputStream fis = new FileInputStream(Paths.get(Constants.SETTINGS_CONFIG_PATH, Constants.SETTINGS_CONFIG_FILE).toFile());
			if(fis != null) {
				settings.load(fis);
			}
		} catch (IOException e) {
			logger.error("Error loading settings from the instance.metadata file", e);
		}
		
	}
	
	private void startupDatabase() {
		String dataPath = settings.getProperty(Constants.SETTINGS_SERVER_DATA_PATH, "data");
		
		File dataDirectory = new File(dataPath);
		//Checking data directory existence or create it
		if(!dataDirectory.exists() || !dataDirectory.isDirectory()) {
			logger.info("Data directory not found. Creating at path: {}", dataDirectory);
			if(dataDirectory.mkdirs()) {
				logger.info("Data directory successfully created");
			} else {
				logger.info("Data directory not created");
				throw new RuntimeException("Impossible to create data directory");
			}
		}
		this.dataDirectory = dataDirectory;

		getInstanceMetadata(dataPath);
	}
	
	private void initSerializer() {
		SimpleModule valueModule = new SimpleModule();
		valueModule.addSerializer(GeoJsonValue.class, new GeoJsonValueSerializer());
		valueModule.addDeserializer(Value.class, new JcoValueDeserializer());
		jsonMapper.registerModule(valueModule);
	}

	private void getInstanceMetadata(String dataPath) {
		File metadataFile = Paths.get(dataPath, Constants.INSTANCE_METADATA_FILE).toFile();
		try {
			if(!metadataFile.exists()) {
				metadataFile.createNewFile();
			} else {
				instanceMetadata.load(new FileInputStream(metadataFile));
			}
			initDefaultMetadata(instanceMetadata);
		} catch (FileNotFoundException e) {
			logger.error("Instance metadata file not found");
			throw new RuntimeException("Missing Instance metadata file");
		} catch (IOException e) {
			logger.error("Impossible to read instance metadata file");
			throw new RuntimeException("Impossible to read instance metadata file");
		}
	}

	private void initDefaultMetadata(Properties metadata) {
		metadata.putIfAbsent("storage.format", "JSON");
	}

	public Properties getServerSettings() {
		return settings;
	}

	public Properties getInstanceMetadata() {
		return instanceMetadata;
	}
	
	/**
	 * Create a new database
	 */
	@Override
	public boolean createDatabase(String name) {
		boolean success = false;
		if(name != null && !name.trim().isEmpty()) {
			File databaseDir = getDatabaseDirectory(name, true);
			if(databaseDir != null && databaseMetadataExists(databaseDir)) {
				success = true;
			}
		}
		return success;
	}

	/**
	 * Delete a database
	 */
	@Override
	public boolean deleteDatabase(String name) {
		boolean success = false;
		if(name != null && !name.trim().isEmpty()) {
			File databaseDir = getDatabaseDirectory(name, true);
			if(databaseDir != null && databaseDir.isDirectory()) {
				success = deleteDirectory(databaseDir);
			}
		}
		return success;
	}
	
	/**
	 * Delete a directory
	 * @param databaseDir
	 * @return
	 */
	private boolean deleteDirectory(File databaseDir) {
		return deleteDirectoryContent(databaseDir) && databaseDir.delete();
	}

	/**
	 * Delete the content of a directory
	 * @param databaseDir
	 * @return
	 */
	private boolean deleteDirectoryContent(File databaseDir) {
		File[] files = databaseDir.listFiles();
		if(files != null) {
			for(File file : files) {
				if(file.isDirectory()) {
					deleteDirectory(file);
				} else {
					file.delete();
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * List all the available databases
	 */
	@Override
	public List<String> listDatabases() {
		List<String> databases = new LinkedList<>();
		
		File[] databaseDirs = this.dataDirectory.listFiles(new DirectoryFileFilter());
		if(databaseDirs != null && databaseDirs.length > 0) {
			for(File databaseDir : databaseDirs) {
				if(databaseMetadataExists(databaseDir)) {
					databases.add(databaseDir.getName());
				}
			}
		}
		return databases;
	}
	
	/**
	 * Check that the database metadata file exists
	 * @param databaseDir
	 * @return
	 */
	private boolean databaseMetadataExists(File databaseDir) {
		return getDatabaseMetadataFile(databaseDir).exists();
	}
	
	/**
	 * Get the database metadata file
	 * @param databaseDir
	 * @return
	 */
	private File getDatabaseMetadataFile(File databaseDir) {
		return Paths.get(databaseDir.getAbsolutePath(), Constants.DATABASE_METADATA_FILE).toFile();
	}
	
	/**
	 * Return a file pointing to the directory of a database
	 * @param database
	 * @param create
	 * @return
	 */
	private File getDatabaseDirectory(String database, boolean create) {
		File databaseDir = Paths.get(this.dataDirectory.getAbsolutePath(), database).toFile();
		if((databaseDir == null || !databaseDir.exists() || !databaseDir.isDirectory()) && create) {
			if(databaseDir.mkdirs()) {
				File metadataFile = getDatabaseMetadataFile(databaseDir);
				if(!metadataFile.exists()) {
					try {
						metadataFile.createNewFile();
					} catch (IOException e) {
						logger.error("Impossible to create database metadata file", e);
					}
				}
			}
		}
		return databaseDir;
	}

	/**
	 * List all the collections inside a database
	 */
	@Override
	public List<String> listCollections(String database) {
		List<String> collections = new LinkedList<>();
		
		File[] collectionDirs = getDatabaseDirectory(database, false).listFiles(new DirectoryFileFilter());
		if(collectionDirs != null && collectionDirs.length > 0) {
			for(File databaseDir : collectionDirs) {
				if(collectionFileExists(databaseDir) && collectionIndexFileExists(databaseDir)) {
					collections.add(databaseDir.getName());
				}
			}
		}
		return collections;
	}

	/**
	 * Check the presence of the collection file inside the database directory
	 * @param databaseDir
	 * @return
	 */
	private boolean collectionFileExists(File databaseDir) {
		return Paths.get(databaseDir.getPath(), Constants.COLLECTION_FILE).toFile().exists();
	}

	/**
	 * Check the presence of the collection index file inside the database directory
	 * @param databaseDir
	 * @return
	 */
	private boolean collectionIndexFileExists(File databaseDir) {
		return Paths.get(databaseDir.getPath(), Constants.COLLECTION_INDEX_FILE).toFile().exists();
	}
	
	/**
	 * Create a new collection in an existing database
	 */
	@Override
	public boolean createCollection(String database, String collectionName) {
		File collectionFile = getCollectionFile(database, collectionName, true);
		File collectionIndexFile = getCollectionIndexFile(database, collectionName, true);
		
		return collectionFile != null && collectionFile.exists()
				&& collectionIndexFile != null && collectionIndexFile.exists();
	}
	
	/**
	 * Delete a collection
	 */
	@Override
	public boolean deleteCollection(String database, String collectionName) {
		File collectionDir = getCollectionDir(database, collectionName, false);
		if(collectionDir != null && collectionDir.isDirectory()) {
			return deleteDirectory(collectionDir);
		}
		return false;
	}
	
	/**
	 * Retrieve the collection file
	 * @param database
	 * @param collectionName
	 * @param create
	 * @return
	 */
	private File getCollectionFile(String database, String collectionName, boolean create) {
		File collectionDir = getCollectionDir(database, collectionName, create);
		if(collectionDir == null || !collectionDir.exists() || !collectionDir.isDirectory()) {
			collectionDir.mkdirs();
		}
		File collectionFile = Paths.get(collectionDir.getAbsolutePath(), Constants.COLLECTION_FILE).toFile();
		if(!collectionFile.exists() &&  create) {
			try {
				collectionFile.createNewFile();
			} catch (IOException e) {
				logger.error("Error creating collection file", e);
			}
		}
		return collectionFile;
	}

	/**
	 * Retrieve the collection index file
	 * @param database
	 * @param collectionName
	 * @param create
	 * @return
	 */
	private File getCollectionIndexFile(String database, String collectionName, boolean create) {
		File collectionDir = getCollectionDir(database, collectionName, create);
		if(collectionDir == null || !collectionDir.exists() || !collectionDir.isDirectory()) {
			collectionDir.mkdirs();
		}
		File collectionFile = Paths.get(collectionDir.getAbsolutePath(), Constants.COLLECTION_INDEX_FILE).toFile();
		if(!collectionFile.exists() &&  create) {
			try {
				collectionFile.createNewFile();
			} catch (IOException e) {
				logger.error("Error creating collection file", e);
			}
		}
		return collectionFile;
	}

	/**
	 * Get the directory of a collection
	 * @param database
	 * @param collectionName
	 * @param create
	 * @return
	 */
	private File getCollectionDir(String database, String collectionName, boolean create) {
		return Paths.get(getDatabaseDirectory(database, create).getAbsolutePath(), collectionName).toFile();
	}

	/**
	 * Get the content of an existing collection
	 */
	@Override
	public CollectionWrapper getCollection(String database, String collection) {
		return getCollection(database, collection, -1, 0, null);
	}
	
	/**
	 * Get the content of an existing collection returning {limit} maximum documents
	 * starting from {offset}
	 */
	@Override
	public CollectionWrapper getCollection(String database, String collection, Integer limit, Integer offset, Integer batchSize) {
		CollectionWrapper collectionWrapper = null;;
		List<Map<String, Object>> documents = new LinkedList<>();
		File collectionFile = getCollectionFile(database, collection, false);
		File collectionIndexFile = getCollectionIndexFile(database, collection, false);
		if(collectionFile != null && collectionIndexFile != null) {
			try {
				FileInputStream collectionStream = new FileInputStream(collectionFile);
				FileInputStream collectionIndexStream = new FileInputStream(collectionIndexFile);
				int collectionSize = (int) (collectionIndexFile.length() / 12);
				
				int skip = Optional.ofNullable(offset).orElse(0);
				int remaining = limit != null && limit > 0 ? limit : collectionSize;
				remaining =  remaining > collectionSize ? collectionSize : remaining;
				int maxPerBatch = Optional.ofNullable(batchSize).orElse(MAX_PER_BATCH);
				int size = 0;
				int count = 0;
				
				byte[] offsetBuf = new byte[8];
				byte[] sizeBuf = new byte[4];
				collectionIndexStream.skip(12 * skip);
				collectionIndexStream.read(offsetBuf);
				collectionIndexStream.read(sizeBuf);
				long startPosition = bytesToLong(offsetBuf);
				int documentSize = bytesToInt(sizeBuf);
				//Position at the beginning of the first document to read
				collectionStream.skip(startPosition);
				
				while(remaining > 0) {
					byte[] docBytes = new byte[documentSize];
					//Retrieve the document
					if(collectionStream.read(docBytes) <= 0) {
						//if no more documents exit loop
						remaining = 0;
						break;
					}
					//Process the document
					Map<String, Object> jsonDocument = jsonMapper.readValue(docBytes, new TypeReference<Map<String, Object>>() {});
					documents.add(jsonDocument);
					//Update counts
					count++;
					remaining--;
					size += documentSize;
					
					//Check limits
					if(size > MAX_MESSAGE_SIZE) {
						break;
					}
					if(count >= maxPerBatch) {
						break;
					}
					
					//Check next document position and size
					if(remaining > 0) {
						collectionIndexStream.read(offsetBuf);
						collectionIndexStream.read(sizeBuf);
						startPosition = bytesToLong(offsetBuf);
						documentSize = bytesToInt(sizeBuf);
					}
				}
				
				collectionStream.close();
				collectionIndexStream.close();

				collectionWrapper = new CollectionWrapper(documents, count, remaining <= 0, remaining, offset + count);
			} catch (IOException e) {
				logger.error("Impossible to deserialize collection from file", e);
			}
		}
		return collectionWrapper;
	}

	/**
	 * Save a list of documents inside a collection
	 */
	@Override
	public boolean saveCollection(String database, String collection, List<Map<String, Object>> documents, boolean append) {
		boolean success = false;
		File collectionFile = getCollectionFile(database, collection, true);
		File indexFile = getCollectionIndexFile(database, collection, true);
		if(collectionFile != null) {
			try {
				final FileOutputStream collectionFileStream = new FileOutputStream(collectionFile, append);
				final FileOutputStream indexFileStream = new FileOutputStream(indexFile, append);
				final byte[] lineSeparator = "\n".getBytes();
				int sepLen = lineSeparator.length;
				long objOffset = 0;
				if(append) {
					FileInputStream fis = new FileInputStream(indexFile);
					long lastDoc = indexFile.length() - 12;
					if(lastDoc > 0) {
						fis.skip(lastDoc);
					}
					byte[] offsetBytes = new byte[8];
					byte[] sizeBytes = new byte[4];
					fis.read(offsetBytes);
					fis.read(sizeBytes);
					fis.close();
					objOffset = bytesToLong(offsetBytes) + bytesToInt(sizeBytes);
				}
				for(Map<String, Object> d : documents) {
					try {
						byte[] objBytes = jsonMapper.writeValueAsBytes(d);
						int objLen = objBytes.length;
						
						//Write the document to the collection file
						collectionFileStream.write(objBytes);
						collectionFileStream.write(lineSeparator);
						
						//Write the index file
						writeIndex(indexFileStream, objOffset, objLen + sepLen);
						objOffset += objLen + sepLen;
					} catch (IOException e) {
						logger.error("Impossible to serialize document to JSON", e);
					}
				};
				collectionFileStream.flush();
				collectionFileStream.close();
				indexFileStream.flush();
				indexFileStream.close();
				success = true;
			} catch (FileNotFoundException e) {
				logger.error("Collection file not found", e);
			} catch (IOException e) {
				logger.error("Impossible to serialize collection to JSON", e);
			}
		}
		return success;
	}

	/**
	 * Write the index record for a document
	 * @param indexFileStream
	 * @param objOffset
	 * @param objSize
	 * @throws IOException
	 */
	private void writeIndex(FileOutputStream indexFileStream, long objOffset, int objSize) throws IOException {
		byte[] longToBytes = longToBytes(objOffset);
		indexFileStream.write(longToBytes);
		byte[] intToBytes = intToBytes(objSize);
		indexFileStream.write(intToBytes);
	}

	/**
	 * Convert a byte array to long
	 * @param bytes
	 * @return
	 */
	private long bytesToLong(byte[] bytes) {
		return ((bytes[0] & 0xFF) << 56) | 
			   ((bytes[1] & 0xFF) << 48) | 
			   ((bytes[2] & 0xFF) << 40) | 
			   ((bytes[3] & 0xFF) << 32) | 
			   ((bytes[4] & 0xFF) << 24) | 
	           ((bytes[5] & 0xFF) << 16) | 
	           ((bytes[6] & 0xFF) << 8 ) | 
	           ((bytes[7] & 0xFF) << 0 );
	}

	/**
	 * Convert a byte array to int
	 * @param bytes
	 * @return
	 */
	private int bytesToInt(byte[] bytes) {
		return ((bytes[0] & 0xFF) << 24) | 
	           ((bytes[1] & 0xFF) << 16) | 
	           ((bytes[2] & 0xFF) << 8 ) | 
	           ((bytes[3] & 0xFF) << 0 );
	}

	/**
	 * Convert a long to byte array
	 * @param objOffset
	 * @return
	 */
	private byte[] longToBytes(long objOffset) {
		return new byte[] {
				(byte) (objOffset >> 56),
				(byte) (objOffset >> 48),
				(byte) (objOffset >> 40),
				(byte) (objOffset >> 32),
				(byte) (objOffset >> 24),
				(byte) (objOffset >> 16),
				(byte) (objOffset >> 8),
				(byte) (objOffset)
		};
	}

	/**
	 * Convert an int to byte array
	 * @param objOffset
	 * @return
	 */
	private byte[] intToBytes(long objOffset) {
		return new byte[] {
				(byte) ((objOffset >> 24) & 0xFF),
				(byte) ((objOffset >> 16) & 0xFF),
				(byte) ((objOffset >> 8) & 0xFF),
				(byte) ((objOffset) & 0xFF)
		};
	}

	@Override
	public Long getCollectionCount(String database, String collection) {
		long count = 0;
		File collectionIndexFile = getCollectionIndexFile(database, collection, false);
		if(collectionIndexFile != null) {
			count = collectionIndexFile.length() / (Long.BYTES + Integer.BYTES);
		}
		return count;
	}
	
	

}
