package net.fm.geco.engine.mongodb;
/*
import org.junit.Before;
import org.junit.Test;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

import net.fm.geco.engine.registry.DatabaseRegistry;

public class MongoEngineTest {
	
	private DatabaseRegistry registry;
	
	@Before
	public void setUp() {
		registry = new DatabaseRegistry();
	}

	@Test
	public void test() {
//		MongoClient client = new MongoClient("127.0.0.1");
//		MongoDatabase db = client.getDatabase("test");
//		
//		MongoDbDatabase database = new MongoDbDatabase(db);
//		registry.registerDatabase("test", database);
	}

}*/
