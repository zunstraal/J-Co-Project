package net.fm.geco.engine.mongodb;
/*
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import net.fm.geco.engine.GecoEngine;
import net.fm.geco.engine.registry.ExecutorRegistry;

//@Configuration
//@ComponentScan
public class MongoDbGecoEngine extends GecoEngine {
	
	//@Autowired
	public MongoDbGecoEngine(ExecutorRegistry executorRegistry) {
		super(executorRegistry);
	}
	
}
*/