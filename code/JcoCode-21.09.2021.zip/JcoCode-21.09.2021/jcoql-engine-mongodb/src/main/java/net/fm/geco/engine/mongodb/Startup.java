package net.fm.geco.engine.mongodb;

/*
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;

import net.fm.geco.engine.IEngine;
import net.fm.geco.engine.exception.ExecutionException;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.command.GetCollectionCommand;
import net.fm.geco.model.command.ICommand;
import net.fm.geco.model.command.SaveAsCommand;

public class Startup {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("net.fm.geco.engine");
		IEngine engine = context.getBean(IEngine.class);
		
		
		DatabaseRegistry registry = context.getBean(DatabaseRegistry.class);
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		
		try {
			
			
			registry.registerDatabase("test", new MongoDbDatabase(mongoClient, "test"));
			
			List<ICommand> commands = new ArrayList<ICommand>();
			commands.add(new GetCollectionCommand("test", "inTest"));
			commands.add(new SaveAsCommand("test", "outTest"));
			
			try {
				engine.execute(commands);
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			mongoClient.close();
			context.close();
		}
	}
}
*/