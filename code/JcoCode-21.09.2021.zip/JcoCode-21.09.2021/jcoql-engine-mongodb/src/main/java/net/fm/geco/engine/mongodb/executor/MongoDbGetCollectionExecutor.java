package net.fm.geco.engine.mongodb.executor;
/*
import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.engine.IDatabase;
import net.fm.geco.engine.IDocumentCollection;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecutionException;
import net.fm.geco.engine.executor.IExecutor;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.command.GetCollectionCommand;

//@Executor(value = GetCollectionCommand.class, overrideStandard = true)
public class MongoDbGetCollectionExecutor implements IExecutor<GetCollectionCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public MongoDbGetCollectionExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}

	@Override
	public void execute(Pipeline pipeline, GetCollectionCommand command) throws ExecutionException {
		System.out.println("MONGO");
		if (command.getDbName() != null) {

			IDatabase database = databaseRegistry.getDatabase(command.getDbName());
			if (database == null) {
				throw new ExecutionException("Invalid database " + command.getDbName());
			}

			IDocumentCollection collection = database.getCollection(command.getCollectionName());
			pipeline.addCollection(collection, command.getCollectionName());

		} else {

			IDocumentCollection collection = pipeline.getCollection(command.getCollectionName());
			pipeline.addCollection(collection, command.getCollectionName());

		}
	}
}*/
