package net.fm.geco.engine.parser.example;
/*
import net.fm.geco.engine.ExecuteJCO;

public class Parser {

	public static void main(String[] args) {

		if(args.length != 3)
			throw new RuntimeException("Invalid arguments number: " + args.length + ". Must be 4");
		
		ExecuteJCO ee = new ExecuteJCO();
		
		ee.ExecuteJCOQL(args[0], args[1].substring(1), args[2]);

		
	}

}
*/