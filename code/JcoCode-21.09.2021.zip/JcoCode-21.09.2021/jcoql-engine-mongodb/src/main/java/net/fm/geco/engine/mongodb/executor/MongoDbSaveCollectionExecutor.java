package net.fm.geco.engine.mongodb.executor;
/*
import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.engine.IDatabase;
import net.fm.geco.engine.IDocumentCollection;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecutionException;
import net.fm.geco.engine.executor.IExecutor;
import net.fm.geco.engine.mongodb.MongoDbDatabase;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.command.SaveAsCommand;

//@Executor(value = SaveAsCommand.class, overrideStandard = true)
public class MongoDbSaveCollectionExecutor implements IExecutor<SaveAsCommand>{
	
	private DatabaseRegistry databaseRegistry;
	
	@Autowired
	public MongoDbSaveCollectionExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}

	@Override
	public void execute(Pipeline pipeline, SaveAsCommand command) throws ExecutionException {
		IDatabase database = databaseRegistry.getDatabase(command.getDbName());
		if(database == null || !(database instanceof MongoDbDatabase)) {
			throw new ExecutionException("Invalid database " + command.getDbName());
		}
		MongoDbDatabase mongoDatabase = (MongoDbDatabase) database;
		
		IDocumentCollection collection = pipeline.getCurrentCollection();
		String collectionName = command.getCollectionName();
		
		mongoDatabase.addCollection(collection, collectionName);
	}

}*/
