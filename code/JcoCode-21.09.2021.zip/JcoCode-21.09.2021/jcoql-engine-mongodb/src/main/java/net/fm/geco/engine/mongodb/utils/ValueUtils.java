package net.fm.geco.engine.mongodb.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import org.bson.Document;
import org.wololo.jts2geojson.GeoJSONReader;

//import net.fm.geco.engine.Constants;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.engine.Constants;
import net.fm.geco.model.value.ArrayValue;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class ValueUtils {

	public static Value fromObject(Object object) {
		return fromObject(null, object);
	}

	public static Value fromObject(String key, Object object) {
		Value value = null;
		//System.out.println(key);
		//System.out.println("object = " + object.toString());
		//System.out.println("object class = " + object.getClass());
		if (object instanceof Integer) {
			value = new SimpleValue((Integer) object);
		} else if(object instanceof Long){
			value = new SimpleValue((Long) object);
		}else if (object instanceof Double) {
			value = new SimpleValue(new BigDecimal((Double) object));
		} else if (object instanceof Float) {
			value = new SimpleValue(new BigDecimal((Float) object));
		} else if (object instanceof BigDecimal) {
			value = new SimpleValue((BigDecimal) object);
		} else if (object instanceof String) {
			value = new SimpleValue((String) object);
		} else if (object instanceof Boolean) {
			value = new SimpleValue((Boolean) object);
		}else if(object instanceof Date){
			value = new SimpleValue((Date)object);
		} else if (object instanceof Document) {
			if (Constants.GEOMETRY_FIELD_NAME.equals(key)) {
				String geoJsonString = ((Document) object).toJson();
				value = new GeoJsonValue(new GeoJSONReader().read(geoJsonString));
			} else {
				value = new DocumentValue(((Document) object).entrySet().stream()
						.map(e -> new FieldDefinition(e.getKey(), ValueUtils.fromObject(e.getKey(), e.getValue())))
						.collect(Collectors.toList()));
			}
		} /* aggiunto 30-06-2017 */
		else if (object instanceof ArrayList) {
			@SuppressWarnings("unchecked")
			ArrayList<Value> array = ArrayList.class.cast(object);
			ListIterator<Value> litr = array.listIterator();
			List<Value> values = new ArrayList<Value>();
			while (litr.hasNext()) {

				values.add(fromObject(litr.next()));
			}
			value = new ArrayValue(values);
			/* aggiunto 5-07-2017 */
		} else if (object == null) {

			value = new SimpleValue();

		}

		return value;
	}

}
