package net.fm.geco.engine.mongodb;

import java.util.Map;

import org.bson.Document;

import net.fm.geco.engine.mongodb.utils.ValueUtils;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.engine.IDocument;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.Value;

public class MongoDocument extends Document implements IDocument {

	private static final long serialVersionUID = 1L;

	@Override
	public void putAll(Map<? extends String, ? extends Object> map) {
		super.putAll(map);
	}

	@Override
	public Value getValue(FieldName fieldName) {
		String[] parts = fieldName.getParts();
		int level = fieldName.getLevel();
		Value value = null;
		value = ValueUtils.fromObject(this.get(parts[0]));
		if (level > 1) {
			if (value.getType() == EValueType.DOCUMENT) {
				/*
				 * { A : { B : { C : 1 } } } A.B.C => 1
				 */
//				value = getValue((DocumentValue) value, parts, level, 1);
			} else {
				value = null;
			}
		}
		return value;
	}
/*
	private Value getValue(DocumentValue parent, String parts, int level, int i) {
		Value value = null;
		if (i < level) {
//			value = parent.getFieldValue(parts[i]);
		}
		return value;
	}
*/
}
