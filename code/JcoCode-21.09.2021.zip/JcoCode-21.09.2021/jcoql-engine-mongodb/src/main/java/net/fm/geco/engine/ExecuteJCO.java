package net.fm.geco.engine;
/*
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.antlr.runtime.ANTLRReaderStream;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.mongodb.MongoClient;
import geco.model.Instruction;
import geco.parser.Environment;
import geco.parser.GecoLexer;
import geco.parser.GecoParser;
import net.fm.geco.engine.exception.ExecutionException;
import net.fm.geco.engine.mongodb.MongoDbDatabase;
import net.fm.geco.engine.mongodb.MongoDbGecoEngine;
import net.fm.geco.engine.parser.Translator;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.command.ICommand;
*/

// PF. TODO Classe inutile da cancellare?
public class ExecuteJCO {

	/**
	 * Metodo che permette di eseguire comandi J-CO-QL
	 *
	 * @param configurationFile
	 *            path del file che contiene la configurazione del database.
	 * @param option
	 *            stringa che indica se l'input è il path di un file (f) o un
	 *            comando inserito a terminale (c).
	 * @param input
	 *            stringa che indica il path del file contenente i comandi (se
	 *            option e' pari a f) oppure i comandi direttamente (se option e'
	 *            pari a c)
	 * @param geometryType
	 *            se pari a 0 indica che il campo contenente la geometria è
	 *            ~geometry altrimenti con 1 si ha geometry
	 *
	 * @author Francesco Bigoni
	 * @author Oscar Titta
	 *
	 **/
	/*
	public void ExecuteJCOQL(String configurationFile, String option, String input) {
		// public void mongoExecuteJCOQL(String host, int port, String dbname) {
		System.out.println("ExecuteJCOQL");
		// connessione al mongo db
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(GecoEngine.class);
		System.out.println("1");
		MongoDbGecoEngine engine = context.getBean(MongoDbGecoEngine.class);
		System.out.println("2");
		DatabaseRegistry registry = context.getBean(DatabaseRegistry.class);
		System.out.println("3");

		Properties prop = new Properties();
		InputStream inputStream = null;
		String host = "";
		int port = 0;
		String dbname = "";

		try {

			inputStream = new FileInputStream(configurationFile);
			prop.load(inputStream);

			host = prop.getProperty("host");
			port = Integer.parseInt(prop.getProperty("port"));
			dbname = prop.getProperty("dbname");

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {

			if (input != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}

		}

		MongoClient client = new MongoClient(host, port);
		MongoDbDatabase database = new MongoDbDatabase(client, dbname);
		registry.registerDatabase(dbname, database);

		List<ICommand> commands = new ArrayList<>();

		GecoParser parser;
		String fileIn = input;

		try {

			GecoLexer lexer = null;
			if (option.equals("f")) {
				lexer = new GecoLexer(new ANTLRReaderStream(new FileReader(fileIn)));
			} else if (option.equals("c")) {
				lexer = new GecoLexer(new ANTLRReaderStream(new StringReader(fileIn)));
			} else
				throw new ExecutionException("Unexpected parameter: " + option);

			parser = new GecoParser(lexer);

			// si lancia il parser
			parser.start();

			// la classe Environment contiene tutte le info relative all'analisi
			// del parser
			Environment env = parser.getEnvironment();

			// numero delle istruzioni
			System.out.println("Numero di istruzioni analizzate: " + env.getNInstruction());

			System.out.println("\nLista degli errori (" + env.getErrorList().size() + "):");
			// lista degli errori (eventuali)
			for (int i = 0; i < env.getErrorList().size(); i++) {
				System.out.println((i + 1) + ".\t" + parser.getErrorList().get(i));

			}
			if (!parser.getErrorList().isEmpty())
				throw new RuntimeException("Parsing error");

			System.out.println("\nLista delle istruzioni:");
			// lista delle istruzioni
			for (int i = 0; i < env.getInstructionList().size(); i++) {
				doSomethingWithInstruction(env.getInstructionList().get(i));
				commands.add(Translator.translate(env.getInstructionList().get(i)));
			}

		} catch (Exception e) {
			System.out.println("Parsing con ANTLR abortito\n\n");
			e.printStackTrace();
		}

		try {
			long start = System.nanoTime();
			engine.execute(commands);
			long end = System.nanoTime();
			System.out.println(String.format("Tempo di esecuzione: %d ms", (end - start) / 1000000));
		} catch (ExecutionException e) {
			e.printStackTrace();
		} finally {
			context.close();
		}
	}

	static void doSomethingWithInstruction(Instruction instr) {
		System.out.println(instr.getSeguence() + "\tid:" + instr.getId() + "\tinstr:" + instr.getInstructionName());

		System.out.println(instr.toMultilineString());
		System.out.println();
	}
*/
}
