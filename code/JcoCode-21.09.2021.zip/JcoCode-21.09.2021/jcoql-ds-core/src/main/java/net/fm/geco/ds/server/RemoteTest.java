package net.fm.geco.ds.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fm.geco.ds.datatype.JcoDsCollection;
import net.fm.geco.ds.datatype.JcoDsRemoteDatabase;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.builder.DocumentDefinitionBuilder;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class RemoteTest {
	private static final Logger logger = LoggerFactory.getLogger(RemoteTest.class);
	
	private static final String COLLECTION_NAME = "collection1";

	public static void main(String[] args) throws IOException {
		JcoDsRemoteDatabase db = new JcoDsRemoteDatabase("localhost", 44446, "db1");
		
		logger.info("Trying to add a new collection");
		IDocumentCollection collection = new JcoDsCollection(COLLECTION_NAME);
		List<Value> values = new ArrayList<Value>();
		values.add(new SimpleValue(1));
		values.add(new SimpleValue(2));
		values.add(new SimpleValue(3));
		values.add(new SimpleValue(4));
		values.add(new SimpleValue(5));
		
//		String geoJsonString = "{\"type\":\"Point\",\"coordinates\":[125.6,10.1]}";
//		String geoJsonString = "{\"type\":\"LineString\",\"coordinates\":[[102.0,0.0],[103.0,1.0],[104.0,0.0],[105.0,1.0]]}";
		String geoJsonString = "{\"type\":\"Polygon\",\"coordinates\":[[[100.0,0.0],[101.0,0.0],[101.0,1.0],[100.0,1.0],[100.0,0.0]]]}";
		
		DocumentDefinition document = DocumentDefinitionBuilder.create()
					.withField()
						.fromString("firstName", "Ada")
					.add()
					.withField()
						.fromString("lastName", "Lovelace")
					.add()
					.withField()
						.fromInteger("age", 40)
					.add()
					.withField()
						.fromDocument("subdoc")
							.withField()
								.fromString("property", "value")
							.add()
						.buildField()
					.add()
					.withField()
						.fromList("list", values)
					.add()
					.withField()
						.fromGeoJsonString("geometry", geoJsonString)
					.add()
				.build();
		collection.addDocument(document);
		collection.addDocument(document);
		
		String preSaveCollection = collection.toString();
		logger.info(preSaveCollection);
		db.addCollection(collection);
		
		collection = db.getCollection(COLLECTION_NAME);
		String postSaveCollection = collection.toString();
		logger.info(postSaveCollection);
		logger.info("Equals: {}", preSaveCollection.equals(postSaveCollection));
	}
}
