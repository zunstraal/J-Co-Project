package net.fm.geco.ds.message;

public final class MessageCodes {
	//Error Message
	public static final long ERROR_RESPONSE =					0xF0000000;
	
	//Instance messages
	public static final long PING = 							0x00000001;
	public static final long PING_RESPONSE = 					0x00000002;
	
	//Database messages
	public static final long LIST_DATABASE = 					0x00010001;
	public static final long LIST_DATABASE_RESPONSE = 			0x00010002;
	public static final long CREATE_DATABASE = 					0x00010003;
	public static final long CREATE_DATABASE_RESPONSE = 		0x00010004;
	public static final long DELETE_DATABASE = 					0x00010005;
	public static final long DELETE_DATABASE_RESPONSE = 		0x00010006;
	
	//Collection messages
	public static final long LIST_COLLECTIONS = 				0x00020001;
	public static final long LIST_COLLECTIONS_RESPONSE = 		0x00020002;
	public static final long CREATE_COLLECTION = 				0x00020003;
	public static final long CREATE_COLLECTION_RESPONSE = 		0x00020004;
	public static final long DELETE_COLLECTION = 				0x00020005;
	public static final long DELETE_COLLECTION_RESPONSE = 		0x00020006;
	public static final long GET_COLLECTION = 					0x00020007;
	public static final long GET_COLLECTION_RESPONSE = 			0x00020008;
	public static final long SAVE_COLLECTION = 					0x00020009;
	public static final long SAVE_COLLECTION_RESPONSE = 		0x0002000A;
	public static final long GET_COLLECTION_COUNT =				0x0002000B;
	public static final long GET_COLLECTION_COUNT_RESPONSE =	0x0002000C;
}
