package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class CreateCollectionResponseMessage extends AbstractMessage<CreateCollectionResponseMessage> implements IMessageData {

	public CreateCollectionResponseMessage(boolean success) {
		super(MessageCodes.CREATE_COLLECTION_RESPONSE);
		
		addBodyParam("success", success);
	}

}
