package net.fm.geco.ds.message.request;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class CreateDatabaseMessage extends AbstractMessage<CreateDatabaseMessage> implements IMessageData {

	public CreateDatabaseMessage(String name) {
		super(MessageCodes.CREATE_DATABASE);
		
		addParam("name", name);
	}

}
