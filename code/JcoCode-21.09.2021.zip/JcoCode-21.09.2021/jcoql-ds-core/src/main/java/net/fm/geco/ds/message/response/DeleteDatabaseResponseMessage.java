package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class DeleteDatabaseResponseMessage extends AbstractMessage<DeleteDatabaseResponseMessage> implements IMessageData {

	public DeleteDatabaseResponseMessage(boolean success) {
		super(MessageCodes.DELETE_DATABASE_RESPONSE);
		
		addBodyParam("success", success);
	}

}
