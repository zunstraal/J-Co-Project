package net.fm.geco.ds.datatype;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import net.fm.geco.ds.datatype.json.GeoJsonValueSerializer;
import net.fm.geco.ds.datatype.json.JcoValueDeserializer;
import net.fm.geco.ds.util.Constants;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.Value;

@Deprecated
public class JcoDsLocalDatabase implements IDatabase {
	private static final Logger logger = LoggerFactory.getLogger(JcoDsLocalDatabase.class);
	
	private final String name;
	private final File dbPath;
	private final ObjectMapper jsonMapper;
	
	public JcoDsLocalDatabase(String path, String name) {
		this(new File(path), name);
	}
	
	public JcoDsLocalDatabase(File dbPath, String name) {
		this.name = name;
		this.dbPath = dbPath;
		
		jsonMapper = new ObjectMapper();
//		jsonMapper = new ObjectMapper(new BsonFactory());
		initDeserializer();
	}

	private void initDeserializer() {
		SimpleModule valueModule = new SimpleModule();
		valueModule.addSerializer(GeoJsonValue.class, new GeoJsonValueSerializer());
		valueModule.addDeserializer(Value.class, new JcoValueDeserializer());
		jsonMapper.registerModule(valueModule);
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public IDocumentCollection getCollection(String name) {
		return doGetCollection(name);
	}

	@Override
	public void addCollection(IDocumentCollection collection) {
		doSaveCollection(collection);
	}


	private IDocumentCollection doGetCollection(String name) {
		IDocumentCollection collection = null;
		File collectionFile = getCollectionFile(name, false);
		if(collectionFile == null) {
			logger.error("Invalid collection file");
		} else {
			try {
				BufferedReader collectionFileReader = new BufferedReader(new FileReader(collectionFile));
				String line = null;
				List<DocumentDefinition> documents = new LinkedList<DocumentDefinition>();
				while((line = collectionFileReader.readLine()) != null) {
					documents.add(jsonMapper.readValue(line, DocumentDefinition.class));
				}
				collectionFileReader.close();
				collection = new JcoDsCollection(name, documents);
			} catch (IOException e) {
				logger.error("Impossible to deserialize collection from file", e);
			}
		}
		return collection;
	}

	private void doSaveCollection(IDocumentCollection collection) {
		List<DocumentDefinition> documents = collection.getDocument();
		if(documents == null || documents.isEmpty()) {
			logger.warn("No documents inside the collection, skipping save");
			return;
		}

		File collectionFile = getCollectionFile(collection.getName(), true);
		if(collectionFile == null) {
			logger.error("Invalid collection file");
			return;
		}
		logger.info("Saving to collection file {}", collectionFile.getAbsolutePath());
		try {
			final FileOutputStream collectionFileStream = new FileOutputStream(collectionFile);
			final byte[] lineSeparator = "\n".getBytes();
			documents.stream().forEach(d -> {
				try {
					collectionFileStream.write(jsonMapper.writeValueAsBytes(d));
					collectionFileStream.write(lineSeparator);
				} catch (IOException e) {
					logger.error("Impossible to serialize document to JSON", e);
				}
			});
			collectionFileStream.close();
		} catch (FileNotFoundException e) {
			logger.error("Collection file not found", e);
		} catch (IOException e) {
			logger.error("Impossible to serialize collection to JSON", e);
		}
	}

	/**
	 * Retrieve the collection file
	 * @param collectionName The name of the collection to look for
	 * @param archiveExisting Archive the old collection file if it exists
	 * @return the collection file or null if not found
	 */
	private File getCollectionFile(String collectionName, boolean archiveExisting) {
		Path collectionPath = Paths.get(dbPath.getPath(), collectionName);
		File collectionDir = collectionPath.toFile();
		if(collectionDir == null || !collectionDir.exists()) {
			if(!collectionDir.mkdirs()) {
				logger.error("Error creating collection directory");
				return null;
			}
		}

		File collectionFile = Paths.get(collectionPath.toString(), Constants.COLLECTION_FILE).toFile();
		if(collectionFile != null && collectionFile.exists() && collectionFile.isFile() && archiveExisting) {
			collectionFile.renameTo(Paths.get(collectionPath.toString(), Constants.COLLECTION_FILE + ".bak").toFile());
		}
		collectionFile = new File(Paths.get(collectionPath.toString(), Constants.COLLECTION_FILE).toString());
		return collectionFile;
	}
}
