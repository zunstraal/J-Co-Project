package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class SaveCollectionResponseMessage extends AbstractMessage<SaveCollectionResponseMessage> implements IMessageData {
	
	public SaveCollectionResponseMessage(String database, String collection, boolean success) {
		super(MessageCodes.SAVE_COLLECTION_RESPONSE);
		
		if(database != null && collection != null) {
			addParam("database", database);
			addParam("collection", collection);
		}

		addBodyParam("success", success);
	}

}
