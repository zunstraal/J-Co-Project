package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class CreateDatabaseResponseMessage extends AbstractMessage<CreateDatabaseResponseMessage> implements IMessageData {

	public CreateDatabaseResponseMessage(boolean success) {
		super(MessageCodes.CREATE_DATABASE_RESPONSE);
		
		addBodyParam("success", success);		
	}

}
