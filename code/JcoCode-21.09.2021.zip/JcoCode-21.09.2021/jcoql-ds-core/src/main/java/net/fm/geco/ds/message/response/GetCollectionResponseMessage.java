package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.datatype.CollectionWrapper;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class GetCollectionResponseMessage extends AbstractMessage<GetCollectionResponseMessage> implements IMessageData {
	
	public GetCollectionResponseMessage(String database, String collectionName, CollectionWrapper collection) {
		super(MessageCodes.GET_COLLECTION_RESPONSE);
		

		addBodyParam("database", database);
		addBodyParam("collection", collectionName);
		if(collection != null) {
			addBodyParam("count", collection.getCount());
			addBodyParam("documents", collection.getDocuments());
			addBodyParam("complete", collection.isComplete());
			addBodyParam("remaining", collection.getRemaining());
			addBodyParam("partialOffset", collection.getPartialOffset());
		}
	}

}
