package net.fm.geco.ds.message.response;

import java.util.List;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class ListDatabasesResponseMessage extends AbstractMessage<ListDatabasesResponseMessage> implements IMessageData {
	
	public ListDatabasesResponseMessage(List<String> databaseList) {
		super(MessageCodes.LIST_DATABASE_RESPONSE);
		
		if(databaseList != null) {
			setBodyData(databaseList);
		}
	}

	private void setBodyData(List<String> databaseList) {
		addBodyParam("databases", databaseList);
	}
	
}
