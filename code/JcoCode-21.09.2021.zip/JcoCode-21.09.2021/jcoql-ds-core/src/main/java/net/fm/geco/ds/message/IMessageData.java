package net.fm.geco.ds.message;

import java.util.Map;

public interface IMessageData {

	long getCode();
	
	Map<String, Object> getParams();
	
	Map<String, Object> getBody();
}
