package net.fm.geco.ds.message.request;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class ListCollectionsMessage extends AbstractMessage<ListCollectionsMessage> implements IMessageData {
	
	public ListCollectionsMessage(String database) {
		super(MessageCodes.LIST_COLLECTIONS);
		
		if(database != null) {
			addParam("database", database);
		}
	}

}
