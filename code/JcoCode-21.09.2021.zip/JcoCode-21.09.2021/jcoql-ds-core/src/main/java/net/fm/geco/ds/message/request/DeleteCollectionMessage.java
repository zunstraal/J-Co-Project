package net.fm.geco.ds.message.request;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class DeleteCollectionMessage extends AbstractMessage<DeleteCollectionMessage> implements IMessageData {

	public DeleteCollectionMessage(String database, String collectionName) {
		super(MessageCodes.DELETE_COLLECTION);
		
		addParam("database", database);
		addParam("name", collectionName);
	}

}
