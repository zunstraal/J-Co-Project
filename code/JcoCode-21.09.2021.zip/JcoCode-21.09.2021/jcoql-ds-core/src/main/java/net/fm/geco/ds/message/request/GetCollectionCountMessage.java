package net.fm.geco.ds.message.request;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class GetCollectionCountMessage extends AbstractMessage<GetCollectionCountMessage> implements IMessageData {
	
	public GetCollectionCountMessage(String database, String collection) {
		super(MessageCodes.GET_COLLECTION_COUNT);
		
		if(database != null) {
			addParam("database", database);
			addParam("collection", collection);
		}
	}
}
