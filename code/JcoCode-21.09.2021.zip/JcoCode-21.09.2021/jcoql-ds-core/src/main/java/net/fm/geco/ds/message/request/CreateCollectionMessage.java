package net.fm.geco.ds.message.request;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class CreateCollectionMessage extends AbstractMessage<CreateCollectionMessage> implements IMessageData {

	public CreateCollectionMessage(String database, String collectionName) {
		super(MessageCodes.CREATE_COLLECTION);
		
		addParam("database", database);
		addParam("name", collectionName);
	}

}
