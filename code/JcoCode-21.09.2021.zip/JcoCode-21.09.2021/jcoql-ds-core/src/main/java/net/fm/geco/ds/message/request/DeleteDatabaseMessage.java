package net.fm.geco.ds.message.request;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class DeleteDatabaseMessage extends AbstractMessage<DeleteDatabaseMessage> implements IMessageData {

	public DeleteDatabaseMessage(String name) {
		super(MessageCodes.DELETE_DATABASE);
		
		addParam("name", name);
	}

}
