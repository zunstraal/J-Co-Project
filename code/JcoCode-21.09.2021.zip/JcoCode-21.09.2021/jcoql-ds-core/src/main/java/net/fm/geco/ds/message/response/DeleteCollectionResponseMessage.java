package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class DeleteCollectionResponseMessage extends AbstractMessage<DeleteCollectionResponseMessage> implements IMessageData {

	public DeleteCollectionResponseMessage(boolean success) {
		super(MessageCodes.DELETE_COLLECTION_RESPONSE);
		
		addBodyParam("success", success);
	}

}
