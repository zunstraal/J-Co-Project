package net.fm.geco.ds.message.response;

import net.fm.geco.ds.annotation.JcoDsMessage;
import net.fm.geco.ds.message.AbstractMessage;
import net.fm.geco.ds.message.IMessageData;
import net.fm.geco.ds.message.MessageCodes;

@JcoDsMessage
public class ErrorResponseMessage extends AbstractMessage<ErrorResponseMessage> implements IMessageData {

	protected ErrorResponseMessage() {
		this("Unknown error");
	}
	
	public ErrorResponseMessage(String errorMsg) {
		super(MessageCodes.ERROR_RESPONSE);
		addBodyParam("success", false);
		addBodyParam("errorMessage", errorMsg);
	}

}
