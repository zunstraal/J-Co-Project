package net.fm.geco.engine;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.antlr.runtime.ANTLRReaderStream;
import org.antlr.runtime.RecognitionException;

import geco.parser.GecoLexer;
import geco.parser.GecoParser;
import net.fm.geco.byZun.ZunProperties;
import net.fm.geco.byZun.ZunTimer;
import net.fm.geco.byZun.ZunWarningTracker;
import net.fm.geco.engine.parser.Parser;

public class ZunTestDATA {
	static String ver = "1.00";

	static List<String> getInstructions (String fileIn, int ndx) throws IOException, RecognitionException {
		ZunProperties.getInstance().setVer(ver);
		
	  	String data = "";
		File myObj = new File(fileIn);
		Scanner myReader = new Scanner(myObj);
		while (myReader.hasNextLine()) {
			  data += myReader.nextLine() + "\n";
		}
		myReader.close();	  	
		String x = "0"+(1+ndx);
		String y = "0"+(2+ndx);
		String z = ""+(1+ndx);
		data = data.replace("XXXX", x).replace("YYYY", y).replace("ZZZZ", z);
		ZunWarningTracker.getInstance().addWarning(data);
		GecoLexer lexer = new GecoLexer(new ANTLRReaderStream(new StringReader(data)));
		GecoParser parser = new GecoParser(lexer);
		parser.start();
		if (parser.getErrorList().size()>0)
			for (int i=0; i<parser.getErrorList().size();i++)
				ZunWarningTracker.getInstance().addWarning("ERRORE:"+parser.getErrorList().get(i));
		List<String> li = new ArrayList<String>();
		for (int i = 0; i < parser.getEnvironment().getInstructionList().size(); i++) {
			System.out.println(parser.getEnvironment().getInstructionList().get(i).toString());
			li.add(parser.getEnvironment().getInstructionList().get(i).toString());
		}
		if (parser.getErrorList().size()>0)
			System.exit(1);
		
		
		return li;		
	}

	
	
	
	public static void main(String[] args) {
		String propFileName = "..\\.zunTestScripts\\p.properties";
		
		if (args.length>0)
			propFileName = args[0];

		try {
			ZunWarningTracker.getInstance().addWarning("*****\t\tStart J-co Engine Ver. " + ver + "\tTest:\t" + propFileName + "\t*****");
			FileReader reader=new FileReader(propFileName);
			Properties prop = new Properties();
			prop.load(reader);
			String fileInProlog = prop.getProperty("fileInProlog");		
			String fileInTest  = prop.getProperty("fileInTest");		
			String testName  = prop.getProperty("testName");		
			boolean toScreen = "true".equalsIgnoreCase(prop.getProperty("toScreen"));
			
			ZunWarningTracker.getInstance().toggleToScreen(toScreen);
			ZunWarningTracker.getInstance().addWarning("Test Name:   \t" + testName);
			ZunWarningTracker.getInstance().addWarning("Parser ver.: \t" + GecoParser.version);
			ZunWarningTracker.getInstance().addWarning("Parser rel.: \t" + GecoParser.release);
			ZunWarningTracker.getInstance().addWarning("Properties:  \t" + propFileName);
			ZunWarningTracker.getInstance().addWarning("FileInProlog:\t" + fileInProlog);
			ZunWarningTracker.getInstance().addWarning("FileInTest:  \t" + fileInTest);
			ZunWarningTracker.getInstance().addWarning("th:  \t" + Constants.getInstance().getNProcessors()+ "\n");

			Parser p = new Parser();
			System.gc();

			List<String> prolog = getInstructions (fileInProlog, 0);
			ZunWarningTracker.getInstance().addWarning("Test. Start executing prolog: " + prolog.size() + " instructions.");
			p.parse(prolog);
				  	
	
			for (int i=0; i<1; i++) {
				ZunTimer.getInstance().reset();
			  	List<String> instructions = getInstructions (fileInTest,i);
				ZunWarningTracker.getInstance().addWarning("Test. Start executing test: " + instructions.size() + " instructions ");
				p.parse(instructions);
//				ZunTimer.getInstance().getPartial("***** End Cycle " + i);
//				ZunTimer.getInstance().getTotal("##### Total execution time");
//				ZunTimer.getInstance().getMilliTotal("##### Total execution time");
			}
			ZunWarningTracker.getInstance().println();
//			ZunWarningTracker.getInstance().saveToFile();;		
		    ZunTimer.getInstance().println();
//		    ZunTimer.getInstance().saveToFile();
		   
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			ZunWarningTracker.getInstance().addWarning("ECCEZIONE:\n" + sw.toString());
			ZunWarningTracker.getInstance().println();
//			ZunWarningTracker.getInstance().saveToFile();
			ZunTimer.getInstance().getTotal("##### CRASH ##### \n+ " + sw.toString());
//			ZunTimer.getInstance().saveToFile();			
		}
		System.exit(0);
	}

}
