package net.fm.geco.engine;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;


public class Tester {

    public static void main (String[] args){
    	System.out.println(Runtime.getRuntime().availableProcessors());
 //   	String doc =testUrl().trim();
    	String doc = "GET COLLECTION FROM WEB \"https://www.dati.lombardia.it/resource/647i-nhxk.json?$limit=1000000&$where=data >= '2021-03-XXXX' AND data < '2021-03-YYYY' "
    			+ "AND idoperatore='1' AND (stato='VV' OR stato='VA')\"";
    	int i=2;
    	String x =""+(15+i);
    	String y =""+(16+i);
    	String z =""+(1+i);
    	doc=doc.replace("XXXX", x).replace("YYYY", y).replace("ZZZZ", z);
    	if (doc.startsWith("[") && doc.endsWith("]"))
    		doc = "{\"data\":"+doc+"}";
    	System.out.println(x+"\t"+y+"\t"+z+"\t"+doc);

    } 

    /*
	public IDocumentCollection createCollection(String alias, String fileName) {
		List<DocumentDefinition> list = new ArrayList<>();
		if(fileName == null)
			throw new ExecuteProcessException("[GET COLLECTION]: collection " + alias + " does not exist");
		try {
			// Apro il file, leggo ogni riga e per ognuna creo un documento
			FileReader fr = new FileReader(new File(fileName));
			BufferedReader br = new BufferedReader(fr);

			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				Document bson = Document.parse(sCurrentLine);
				list.add(DocumentUtils.mapDocumentDefinitionFromBson(bson));
			}
			br.close();
			fr.close();



		} catch (Exception e) {
			e.printStackTrace();
		}

		return new SimpleDocumentCollection(alias, list);
	}
    */

    public static String testUrl() {
        String outSt ="";
        String urlSt;
        int timeout = 5000;
        try {
            urlSt = "https://www.dati.lombardia.it/resource/nf78-nj6b.json";
            urlSt = "https://dati.comune.milano.it/dataset/406867c6-ff96-4347-86af-c10e8967cc93/resource/ae1bb314-1931-4150-85ba-612178adbddb/download/qaria_reportariagiorno_2021-03-16.json";
            urlSt = "https://www.dati.lombardia.it/resource/647i-nhxk.json?$where=data >= \"2021-03-10\" AND data <\"2021-03-12\"";
            urlSt = "https://www.dati.lombardia.it/resource/647i-nhxk.json?$where=data>='2021-03-15' AND data <'2021-03-18'";
            urlSt = urlSt.replace(" ", "%20");
            urlSt = urlSt.replace(">", "%3E");
            urlSt = urlSt.replace("<", "%3C");
            RequestConfig config = RequestConfig.custom()
            		.setConnectTimeout(timeout)
            		.setConnectionRequestTimeout(timeout)
            		.setSocketTimeout(timeout).build();
            CloseableHttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(config).build();

            HttpGet request = new HttpGet(urlSt);

            // add request header
            String USER_AGENT = "Mozilla/5.0";
            request.addHeader("User-Agent", USER_AGENT);

            HttpResponse response = client.execute(request); // conn= response
            
            String strCurrentLine;
            BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            while ((strCurrentLine = rd.readLine()) != null) 
            	outSt += strCurrentLine+"\n";


        } catch (Exception e) {
        	System.out.println("eccezione");
        	e.printStackTrace();
        }
	
        return outSt;
    }
   
}