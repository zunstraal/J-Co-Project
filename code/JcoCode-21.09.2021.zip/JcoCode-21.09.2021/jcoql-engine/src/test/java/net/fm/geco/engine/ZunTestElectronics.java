package net.fm.geco.engine;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.antlr.runtime.ANTLRReaderStream;
import org.antlr.runtime.RecognitionException;

import geco.parser.GecoLexer;
import geco.parser.GecoParser;
import net.fm.geco.byZun.ZunProperties;
import net.fm.geco.byZun.ZunTimer;
import net.fm.geco.byZun.ZunWarningTracker;
import net.fm.geco.engine.parser.Parser;

public class ZunTestElectronics {
	static String ver = "1.05";

	static List<String> getInstructions (String fileIn, String ds) throws IOException, RecognitionException {
		ZunProperties.getInstance().setVer(ver);
		
	  	String data = "";
		File myObj = new File(fileIn);
		Scanner myReader = new Scanner(myObj);
		while (myReader.hasNextLine()) {
			  data += myReader.nextLine() + "\n";
		}
		myReader.close();	  	
		if ((ds == null) || ds.equals("1"))
			ds = "";
		ds="";
		data = data.replace("NNNN", ds);
		System.out.println(data);
		GecoLexer lexer = new GecoLexer(new ANTLRReaderStream(new StringReader(data)));
		GecoParser parser = new GecoParser(lexer);
		parser.start();
		if (parser.getErrorList().size()>0)
			for (int i=0; i<parser.getErrorList().size();i++)
				ZunWarningTracker.getInstance().addWarning("ERRORE:"+parser.getErrorList().get(i));
		List<String> li = new ArrayList<String>();
		for (int i = 0; i < parser.getEnvironment().getInstructionList().size(); i++) {
			System.out.println(parser.getEnvironment().getInstructionList().get(i).toString());
			li.add(parser.getEnvironment().getInstructionList().get(i).toString());
		}
		
		return li;		
	}

	public static void main(String[] args) {
//		String propFileName = "..\\.zunTestScripts\\jcoTest-ab1.properties";
		String propFileName = "..\\.zunTestScripts\\p.properties";
//		String propFileName = "..\\.zunTestScripts\\p2.properties";
		
		if (args.length>0)
			propFileName = args[0];

		try {
			ZunWarningTracker.getInstance().addWarning("*****\t\tStart J-co Engine Ver. " + ver + "\tTest:\t" + propFileName + "\t*****");
			FileReader reader=new FileReader(propFileName);
			Properties prop = new Properties();
			prop.load(reader);
			String fileInProlog = prop.getProperty("fileInProlog");		
			String fileInTest  = prop.getProperty("fileInTest");		
			fileInTest = "..\\.zunTestScripts\\TEST Information2021\\testInformation2021 2-3.txt";
			String testName  = prop.getProperty("testName");		
			boolean toScreen = "true".equalsIgnoreCase(prop.getProperty("toScreen"));
//			boolean doRemove = "yes".equalsIgnoreCase(prop.getProperty("doRemove"))d
			int nInterations = 1;//Integer.parseInt(prop.getProperty("nInterations"));		
	//		int prime = Integer.parseInt(prop.getProperty("prime"));
		//	int prime2l = Integer.parseInt(prop.getProperty("prime2l"));
			//int priority1 = Integer.parseInt(prop.getProperty("priority1"));
//			int priority2 = Integer.parseInt(prop.getProperty("priority2"));
	//		int nThreads = Integer.parseInt(prop.getProperty("nThreads"));
			String ds = prop.getProperty("ds");		
			
//			ZunWarningTracker.getInstance().setPrime(prime);
	//		ZunWarningTracker.getInstance().setPrime2l(prime2l);
		//	ZunWarningTracker.getInstance().setPriority1(priority1);
			//ZunWarningTracker.getInstance().setPriority2(priority2);
//			ZunWarningTracker.getInstance().setNThreads(nThreads);
	//		ZunWarningTracker.getInstance().toggleDoRemove(doRemove);
			ZunWarningTracker.getInstance().toggleToScreen(toScreen);
			ZunWarningTracker.getInstance().addWarning("Test Name:   \t" + testName);
			ZunWarningTracker.getInstance().addWarning("Parser ver.: \t" + GecoParser.release);
			ZunWarningTracker.getInstance().addWarning("Properties:  \t" + propFileName);
			ZunWarningTracker.getInstance().addWarning("DS:          \t" + ds);
			ZunWarningTracker.getInstance().addWarning("FileInProlog:\t" + fileInProlog);
			ZunWarningTracker.getInstance().addWarning("FileInTest:  \t" + fileInTest);
			ZunWarningTracker.getInstance().addWarning("Iterations:  \t" + nInterations + "\n");
			ZunWarningTracker.getInstance().addWarning("th:  \t" + Constants.getInstance().getNProcessors()+ "\n");
//			ZunTimer.getInstance().getPartial("### JCo Engine v. " + ver + " \tTest name: " + testName + " ###");

				  	
		  	List<String> prolog = getInstructions (fileInProlog, ds);
		  	List<String> instructions = getInstructions (fileInTest, ds);
	
			for (int i=0; i<nInterations; i++) {
//				ZunTimer.getInstance().reset();
//				ZunTimer.getInstance().getPartial("***** Start Cycle " + (i+1) + ":");
				Parser p = new Parser();
				System.gc();
			
				ZunWarningTracker.getInstance().addWarning("Test. Start executing prolog: " + prolog.size() + " instructions.");
				p.parse(prolog);
	
				ZunWarningTracker.getInstance().addWarning("Test. Start executing test: " + instructions.size() + " instructions " + nInterations + " times");
				p.parse(instructions);
//				ZunTimer.getInstance().getPartial("***** End Cycle " + i);
//				ZunTimer.getInstance().getTotal("##### Total execution time");
//				ZunTimer.getInstance().getMilliTotal("##### Total execution time");
			} 
			ZunWarningTracker.getInstance().println();
			ZunWarningTracker.add("############ END ################");			
//			ZunWarningTracker.getInstance().saveToFile();		
		    ZunTimer.getInstance().println();
//		    ZunTimer.getInstance().saveToFile();
		    System.out.println("------------------ FINE -------------------------");
		   
			
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			ZunWarningTracker.getInstance().addWarning("ECCEZIONE sprasta:\n" + sw.toString());
			ZunWarningTracker.getInstance().println();
			ZunWarningTracker.add("############ END WITH EXCEPTION ################");
	//		ZunWarningTracker.getInstance().saveToFile();
			ZunTimer.getInstance().getTotal("##### CRASH ##### \n+ " + sw.toString());
	//		ZunTimer.getInstance().saveToFile();			
		}
		
	}

}
