package net.fm.geco.engine;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.exception.InitializationError;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.builder.DocumentDefinitionBuilder;
import net.fm.geco.model.command.GetCollectionCommand;
import net.fm.geco.model.command.ICommand;
import net.fm.geco.model.engine.SimpleDocumentCollection;

import static java.lang.System.out;
import static java.lang.Math.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = GecoEngine.class)
public class EngineTest {

	
//	@Autowired
//	private GecoEngine engine;
	
	@Autowired
	private DatabaseRegistry registry;
	
	@Before
	public void setUp() throws IOException {
		out.println("******** SET UP *********" + max(3,2));
		SimpleDocumentCollection collection = new SimpleDocumentCollection("inTest");
		collection.addDocument(DocumentDefinitionBuilder.create()
					.withField().fromString("A", "a1").add()
					.withField().fromString("B", "b1").add()
				.build()
		);
		collection.addDocument(DocumentDefinitionBuilder.create()
					.withField().fromString("C", "c1").add()
					.withField().fromString("D", "d1").add()
				.build()
		);
		
		SimpleDatabase db = new SimpleDatabase("test", collection);
		
		registry.registerDatabase("test", db);
		
		SimpleDocumentCollection outCollection = new SimpleDocumentCollection("outTest");
		SimpleDatabase outDb = new SimpleDatabase("outTest", outCollection);
		registry.registerDatabase("outTest", outDb);

		
	}
	

	@Test
	public void testExecute() throws ExecuteProcessException, InitializationError, IOException {
		System.out.println("******** testExecute *********");
//		Parser p = new Parser();
//		p.parse();

		List<ICommand> commands = new ArrayList<ICommand>();
		
		commands.add(new GetCollectionCommand("test", "inTest"));
 	//commands.add(new SaveAsCommand("test", "outTest"));
		
		//engine.execute(commands);
	}

	/*
	@Test
	public void testFilter() throws ExecuteProcessException, InitializationError {
		System.out.println("******** testFilter *********");
		List<ICommand> commands = new ArrayList<ICommand>();
		
		commands.add(new GetCollectionCommand("test", "inTest"));
		
		List<WhereCondition> whereConditions = new ArrayList<WhereCondition>();
		List<ICondition> with = Collections.singletonList(new FieldPresenceCondition(new FieldReference("inTest", ".A")));
		List<ICondition> without = Collections.emptyList();
		DocumentDefinition outDefinition = DocumentDefinitionBuilder.create()
												.withField().fromFieldReference("inTest", ".A").add()
												.withField().fromFieldReference("inTest", ".C").add()
												.withField().fromString("S", "s1").add()
											.build();
													
		GenerateCommand generate = new GenerateCommand(outDefinition, EGeometryAction.KEEP, null);
		//whereConditions.add(new WhereCondition(with, without, generate));
		with = Collections.emptyList();
		without = Collections.singletonList(new FieldPresenceCondition(new FieldReference("inTest", ".A")));
		whereConditions.add(new WhereCondition(with)); // add(new WhereCondition(with, without))
		Case caseFilter = new Case(whereConditions, false);
		FilterCommand filter = new FilterCommand(caseFilter);
		commands.add(filter);
		commands.add(new SaveAsCommand("outTest", "outTest"));
		
	//	commands.add(new LogCommand());
		
		//engine.execute(commands);
		
		IDatabase outDb = registry.getDatabase("outTest");
		IDocumentCollection outCollection = outDb.getCollection("outTest");
		List<DocumentDefinition> outDocs = outCollection.getDocuments();
		
		assertNotNull(outDocs);
		assertEquals(2, outDocs.size());
	}
*/
}
