package net.fm.geco.engine.parser.utils.model;

import java.util.ArrayList;
import java.util.List;


public class FieldsStructureNode {

	/*
	 * field è l'elemento singolo che fa parte della lista di stringhe che viene
	 * passata dal parser
	 * 
	 * Esempio di costruzione dei nodi a partire da: ".occhio.malocchio.a"
	 * 
	 * Ci sono tre nodi: - due interni con field pari rispettivamente a "occhio"
	 * e "malocchio" - una foglia con field pari ad "a" e fieldReference pari a
	 * ".occhio.malocchio.a"
	 *
	 */

	private String field;
	private boolean isLeaf;
	/* Solo per nodi foglia */
	private String fieldReference;

	private List<FieldsStructureNode> children;
	private FieldsStructureNode parent;

	private FieldsStructureNode() {

	}

	/**
	 * 
	 * Costruttore che prende sia il nome del campo sia il riferimento del
	 * campo. Con questo metodo si costruisce quindi un nodo foglia. Esempio
	 * field: ".a" fieldReference: ".occhio.malocchio.a"
	 * 
	 **/
	public FieldsStructureNode(String field, String fieldReference) {

		this();

		/* ai Fields viene automaticamente rimosso il punto */
		if (field.startsWith(".")) {
			this.field = field.substring(1, field.length());
		} else {
			this.field = field;
		}

		this.fieldReference = fieldReference;
		isLeaf = true;
		children = null;

	}

	/**
	 * 
	 * Costruttore che prende sia il nome di un campo. Viene usato per i nodi
	 * interni. Esempio field: ".occhio" (a partire ad esempio da
	 * ".occhio.malocchio")
	 * 
	 **/
	public FieldsStructureNode(String field) {

		this();

		/* ai Fields viene automaticamente rimosso il punto */
		if (field.startsWith(".")) {
			this.field = field.substring(1, field.length());
		} else {
			this.field = field;
		}
		children = new ArrayList<>();
		isLeaf = false;
		this.fieldReference = null;

	}

	public FieldsStructureNode getParent() {

		return this.parent;
	}

	public List<FieldsStructureNode> getChildren() {

		return this.children;
	}

	public FieldsStructureNode addChild(FieldsStructureNode child) {
		child.parent = this;

		if (!child.isLeaf)
			children.add(0, child);
		else
			children.add(child);

		return child;
	}

	public String getField() {

		return this.field;
	}

	public String getFieldReference() {

		return this.fieldReference;
	}

	public boolean isLeaf() {
		return isLeaf;
	}

	public String toString() {

		if (isLeaf)
			return field + " = " + fieldReference;
		else
			return field;

	}

}
