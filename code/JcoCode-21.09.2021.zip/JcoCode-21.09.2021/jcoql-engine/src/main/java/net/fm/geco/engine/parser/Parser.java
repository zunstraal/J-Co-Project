package net.fm.geco.engine.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.antlr.runtime.ANTLRReaderStream;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import geco.parser.Environment;
import geco.parser.GecoLexer;
import geco.parser.GecoParser;
import net.fm.geco.byZun.ZunTimer;
import net.fm.geco.engine.GecoEngine;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.executor.utils.Configuration;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.engine.registry.Servers;
import net.fm.geco.model.command.ICommand;
import net.fm.geco.model.engine.IDocumentCollection;

/**
 *
 * @author Savino Lechiancole
 *
 */

public class Parser {

	private final AnnotationConfigApplicationContext context;
	private final GecoEngine engine;
	private final DatabaseRegistry registry;
	private final Servers s;
	private final List<Configuration> configurations;

	public Parser() throws IOException  {
		context = new AnnotationConfigApplicationContext(GecoEngine.class);
		engine = context.getBean(GecoEngine.class);
		registry = context.getBean(DatabaseRegistry.class);
		s = context.getBean(Servers.class);

		configurations = new ArrayList<Configuration>();
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		InputStream is = classloader.getResourceAsStream("conf");
		//FileInputStream stream= new FileInputStream("conf.txt");
		readConfig(is);

//		ClassPathResource configFile = new ClassPathResource("conf");
//		readConfig(configFile.getInputStream());
	}

	public void readConfig(InputStream is) {
		Properties prop = new Properties();
		try {
			prop.load(is);

			int servers = Integer.parseInt(prop.getProperty("servers", "0"));

			String server = "server_";
			String host = "host_";
			String port = "port_";
			String servertype = "server_type_";
			String def = "default_";


			for (int i = 1; i <= servers; i++) {
				String server_value = prop.getProperty(server + i);
				String host_value = prop.getProperty(host + i);
				int port_value = Integer.parseInt(prop.getProperty(port + i));
				String type_value = prop.getProperty(servertype + i);
				boolean default_value = Boolean.parseBoolean(prop.getProperty(def + i, "false"));

				Configuration c = new Configuration(server_value, host_value, port_value, type_value, default_value);
				configurations.add(c);
				s.addConfiguration(c);
			}

			is.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	/*
	 * for (Configuration con : configurations) { if
	 * (con.getType().toLowerCase().equals("mongodb")) { //MongoDbDatabase db =
	 * MongoDBCreator.createDB(conf.getServer(), conf.getHost(), conf.getPort());
	 * MongoDbDatabase db = new MongoDbDatabase(con.getHost(), con.getPort(),
	 * con.getServer()); registry.registerDatabase(db.getName(), db); } else
	 * if(con.getType().toLowerCase().equals("elasticsearch")) { ElasticDatabase db
	 * = new ElasticDatabase(con.getHost(), con.getPort(), con.getServer());
	 * registry.registerDatabase(db.getName(), db); } else {
	 * System.out.println("Unknown type: " + con.getType()); System.exit(1); } }
	 */


	public void parse(List<String> istructions) throws ExecuteProcessException {
		engine.getPipeline().setIstructions(istructions);
		GecoParser parser;
		GecoLexer lexer = null;

		for (String istr : istructions) {

			try {
				lexer = new GecoLexer(new ANTLRReaderStream(new StringReader(istr)));
				parser = new GecoParser(lexer);

				// si lancia il parser
				parser.start();

				// la classe Environment contiene tutte le info relative all'analisi
				// del parser
				Environment env = parser.getEnvironment();

				// lista degli errori (eventuali)
				if (env.getErrorList().size() > 0) {
					System.out.println("\nError list (" + env.getErrorList().size() + "):");
					for (int i = 0; i < env.getErrorList().size(); i++) {
						System.out.println((i + 1) + ".\t" + parser.getErrorList().get(i));
					}
				}

				if (!parser.getErrorList().isEmpty()) {
					String errorMessage = "Parsing error: \n";
					for (int i = 0; i < env.getErrorList().size(); i++)
						errorMessage = errorMessage + (i + 1) + ". " + parser.getErrorList().get(i) + "\n";
					throw new ExecuteProcessException(errorMessage);
				}


				ICommand instrTans = Translator.translate(env.getInstructionList().get(0));

				ZunTimer.getInstance().reset();
				engine.execute(instrTans);
				ZunTimer.getInstance().getMilliTotal(instrTans.getName());
//				ZunTimer.getInstance().saveToFile("Temp");


			} catch (Exception e) {
// *** PF added- to print stack trace on pop-up
					StringWriter sw = new StringWriter();
					PrintWriter pw = new PrintWriter(sw);
					e.printStackTrace(pw);
					System.out.println("Exception:" + istr + "\n" + sw.toString());
// *** PF end
				throw new ExecuteProcessException(e.getMessage() + "\nOn line:\n" + istr + "\n\n" + sw.toString());

			} finally {
				context.close();
			}
		}

	}



	public void backtrack() {
		engine.getPipeline().backtrack(registry);
	}

	public IDocumentCollection getTemporaryCollection() {
		return engine.getPipeline().getCurrentCollection();
	}

	public List<String> getProcess() {
		return engine.getPipeline().getIstructions();
	}

	public Collection<String> getIRList() {
		return engine.getPipeline().getIRList();
	}

	public IDocumentCollection getIRCollection(String collectionName) {
		return engine.getPipeline().getIRCollection(collectionName);
	}

	public List<Configuration> getConfigurations() {
		return configurations;
	}

	public List<Configuration> addServer(String s) {
		readConfig(new ByteArrayInputStream(s.getBytes()));
		return getConfigurations();
	}

}
