package net.fm.geco.engine.executor;

import java.util.List;
import java.util.ListIterator;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;

//import net.fm.geco.engine.IDatabase;
//import net.fm.geco.engine.IDocumentCollection;
import net.fm.geco.engine.Pipeline;
//import net.fm.geco.engine.SimpleDocumentCollection;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.SubtractCollectionsCommand;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;
import net.fm.geco.model.reference.CollectionReference;

@Executor(SubtractCollectionsCommand.class)
public class SubtractCollectionsExecutor implements IExecutor<SubtractCollectionsCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public SubtractCollectionsExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}

	@Override
	public void execute(Pipeline pipeline, SubtractCollectionsCommand command) throws ExecuteProcessException {

		/*
		 * Prima fase, vengono istanziati: 1) La collezione che andrà in output
		 * nella pipeline 2) Una collezione temporanea che serve come
		 * riferimento per la collezione corrente da elaborare 3) La lista di
		 * documenti corrente da elaborare
		 */
		final SimpleDocumentCollection outCollection = new SimpleDocumentCollection("subtract");

		IDocumentCollection singleCollection;
		List<DocumentDefinition> docs;
		IDatabase database;
		CollectionReference collectionReference;
		String collectionName;
		String dbName;

		/* Iteratore per la lista di collezioni su cui eseguire il subtract */
		ListIterator<CollectionReference> litr = command.getCollections().listIterator();

		/* Nomi della prima collezione e del suo database */
		collectionReference = litr.next();
		collectionName = collectionReference.getAlias();
		dbName = collectionReference.getDatabaseName();

		if(dbName != null){

		database = databaseRegistry.getDatabase(dbName);
		if(database == null) {
			throw new ExecuteProcessException("[SUBTRACT COLLECTIONS]: Invalid database " + dbName);
		}

		/*
		 * Inizializzazione: viene prelevata la prima collezione dalla pipeline
		 */
		singleCollection = database.getCollection(collectionReference.getAlias());
		}else{

			singleCollection = pipeline.getCollection(collectionReference.getAlias());
		}
		/*
		 * i documenti vengono subito salvati nella collezione di documenti che
		 * andrà in output dopodichè verranno filtrati dal momento che l'output
		 * è sicuramente un sottoinsieme di questo gruppo
		 */
		docs = singleCollection.getDocument();
		/* Se non viene trovata nessuna collezione la pipeline è vuota */
		if (docs == null)
			throw new ExecuteProcessException("Empty pipeline");

		Stream<DocumentDefinition> stream = docs.stream();
		while (litr.hasNext()) {

			/*
			 * Viene estratta una collezione alla volta (e i suoi documenti)
			 * dall'input
			 */
			collectionReference = litr.next();
			collectionName = collectionReference.getAlias();
			dbName = collectionReference.getDatabaseName();


			if(dbName != null){

			database = databaseRegistry.getDatabase(dbName);
			if(database == null) {
				throw new ExecuteProcessException("[SUBTRACT COLLECTIONS]: Invalid database " + dbName);
			}

			//singleCollection = pipeline.getCollection(collectionName);
			singleCollection = database.getCollection(collectionName);
			}else{
				singleCollection = pipeline.getCollection(collectionName);
			}

			List<DocumentDefinition> tempDocs = singleCollection.getDocument();

			if (docs != null) {

				/* Lo stream di documenti viene filtrato ad ogni passo */
				stream = stream.filter(d -> {
					return (!tempDocs.contains(d));
				});

			}
		}
		/* Alla fine la collezione di output viene aggiunta alla pipeline */
		stream.forEach(outCollection::addDocument);
		pipeline.addCollection(outCollection);

	}

}
