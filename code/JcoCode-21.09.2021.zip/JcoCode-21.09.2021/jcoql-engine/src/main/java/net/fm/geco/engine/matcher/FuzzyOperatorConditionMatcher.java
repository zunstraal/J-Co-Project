package net.fm.geco.engine.matcher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.script.ScriptException;

import geco.model.util.Expression;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.FuzzyOp;
import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.FuzzyOperatorCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.value.Value;

public class FuzzyOperatorConditionMatcher implements IMatcher {

	List<Value> listValue = null;

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {
		return false;
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) throws ScriptException {
		FuzzyOperatorCondition c = (FuzzyOperatorCondition) condition;

		// cerco l'operatore giusto
		FuzzyOp fOp = getOperator(pipeline, c);

		if (fOp != null) {
			for (int i = 0; i < listValue.size(); i++) {
				pipeline.addFuzzyOperatorParameters(fOp.getParameters().get(i).getName(), listValue.get(i));
			}

			
			// se la precondition è true, calcola EVALUATE
			if (checkPrecondition(fOp, pipeline)) {
				double value;
				// calcolo evaluate
				value = getEvaluateValue(fOp.getEvaluate().get(0), pipeline);

				if (value == -1.0) {
					return -1.0;
				} else {
					return fOp.evaluateMembership(value);
				}

			} else {
				return -1.0;
			}
		} else {
			return -1.0;
		}
	}

	// check precondition
	private boolean checkPrecondition(FuzzyOp fOp, Pipeline pipeline) throws ScriptException {
		boolean matchPrecondition = true;
		// PF. "if" added on 18.05.2021 after deciding that PRECONDITIONS are optional
		if (fOp.getPrecondition() != null)
			for (ICondition precondition : fOp.getPrecondition().getConditions()) {
        		// PF - what is for?
//				TreeCondition t = (TreeCondition)precondition;
				
				IMatcher matcher = getMatcher(precondition);
				if (matcher != null && !matcher.matches(precondition, pipeline)) {
					matchPrecondition = false;
				}
			}
		return matchPrecondition;
	}

	// calcola il valore dell'espressione EVALUATE
	private double getEvaluateValue(OperationTree opTree, Pipeline pipeline) throws ScriptException {
		OperationConditionMatcher opMatcher = new OperationConditionMatcher();

		Value v = opMatcher.evaluateOperationTreeValue(opTree.getRoot(), pipeline);
		if (v == null) {
			return -1.0;
		} else {
			if (v.getStringValue().equals("")) {
				return -1.0;
			} else {
				return Double.parseDouble(v.getStringValue());
			}
		}
	}

	// cerca l'operatore corretto tra tutti quelli contenuti nella pipeline
	private FuzzyOp getOperator(Pipeline pipeline, FuzzyOperatorCondition fc) throws ScriptException {

		listValue = new ArrayList<>();

		for (Expression e : fc.getParameters()) {
			OperationTree opTree = new OperationTree("Generate Fuzzy");
			opTree.expression2Tree(e);
			List<OperationTree> opTreeList = Collections.singletonList(opTree);
			OperationConditionMatcher opCondMatcher = new OperationConditionMatcher();
			for (OperationTree opT : opTreeList) {
				Value v = opCondMatcher.evaluateOperationTree(opT.getRoot(), pipeline);
				listValue.add(v);
			}
		}

		FuzzyOp fuzzyOp = operatorWithSameName(pipeline, listValue, fc);

		return fuzzyOp;
	}

	private FuzzyOp operatorWithSameName(Pipeline pipeline, List<Value> parameters, FuzzyOperatorCondition fc) {
		List<FuzzyOp> listOperator = new ArrayList<>();

		for (FuzzyOp fo : pipeline.getFuzzyOperators()) {
			if (fo.getFuzzyOperatorName().equals(fc.getNameFunction())) {
				listOperator.add(fo);
			}
		}

		if (listOperator.size() == 1) {
			return listOperator.get(0);
		} else if (listOperator.size() > 1) {
			return operatorWithSameNumParameters(listOperator, parameters, pipeline);
		} else {
			return null;
		}
	}

	private FuzzyOp operatorWithSameNumParameters(List<FuzzyOp> operators, List<Value> parameters, Pipeline pipeline) {
		List<FuzzyOp> listOperator = new ArrayList<>();
		if (operators.size() != 0) {
			for (FuzzyOp fo : operators) {
				if (fo.getParameters().size() == parameters.size()) {
					listOperator.add(fo);
				}
			}
		} else {
			return null;
		}

		if (listOperator.size() == 1) {
			return listOperator.get(0);
		} else if (listOperator.size() > 1) {
			return checkParametersType(listOperator, parameters);
		} else {
			return null;
		}
	}

	private FuzzyOp checkParametersType(List<FuzzyOp> operators, List<Value> parameters) {

		if (operators.size() != 0) {
			for (FuzzyOp fo : operators) {
				boolean match = false;

				for (int p = 0; p < parameters.size(); p++) {
					if (fo.getParameters().get(p).getType().equals(parameters.get(p).getType().toString())) {
						match = true;
					}
				}

				if (match) {
					return fo;
				}
			}
		} else {
			return null;
		}

		return null;
	}

	private IMatcher getMatcher(ICondition condition) {
		IMatcher matcher = null;
		if (condition instanceof TreeCondition) {
			matcher = new TreeConditionMatcher();
		}
		return matcher;
	}
}
