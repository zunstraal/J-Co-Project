package net.fm.geco.engine.matcher;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.IdCondition;
import net.fm.geco.model.value.DocumentValue;


public class IdConditionMatcher implements IMatcher {

    @Override
    public boolean matches(ICondition condition, Pipeline pipeline) {
        IdCondition c = (IdCondition) condition;

        DocumentDefinition dd = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());

        boolean match = false;
        if(dd.getValue(Constants.FUZZY_FIELD_NAME) != null) {
            DocumentDefinition docFuzzy = new DocumentDefinition(((DocumentValue) dd.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
            for(FieldDefinition fd : docFuzzy.getFields()) {
                if(fd.getName().equals(c.getId())) {
                    match = true;
                }
            }
        }
        return match;
    }

    @Override
    public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
        DocumentDefinition dd = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());
        IdCondition c = (IdCondition) condition;

        if(dd.getValue(Constants.FUZZY_FIELD_NAME) != null) {
            DocumentDefinition docFuzzy = new DocumentDefinition(((DocumentValue) dd.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
            for(FieldDefinition fd : docFuzzy.getFields()) {
                if(fd.getName().equals(c.getId())) {
                    return Double.parseDouble(fd.getValue().getStringValue());
                }
            }
        }
        return -1;
    }

}
