package net.fm.geco.engine.matcher;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.condition.ICondition;

public interface IMatcher {

	public boolean matches(ICondition condition, Pipeline pipeline) throws ScriptException;

	public double fuzzyMatches(ICondition condition, Pipeline pipeline) throws ScriptException;

}
