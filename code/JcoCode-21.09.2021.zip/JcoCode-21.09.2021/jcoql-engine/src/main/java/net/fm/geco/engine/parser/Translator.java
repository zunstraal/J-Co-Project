package net.fm.geco.engine.parser;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import geco.model.Expand;
import geco.model.Filter;
import geco.model.FuzzyOperator;
import geco.model.GetCollection;
import geco.model.GetDictionary;
import geco.model.Group;
import geco.model.Instruction;
import geco.model.IntersectCollections;
import geco.model.JavascriptFunction;
import geco.model.JoinCollections;
import geco.model.MergeCollections;
import geco.model.SaveAs;
import geco.model.SetIntermediateAs;
import geco.model.SpatialJoin;
import geco.model.SubtractCollections;
import geco.model.TrajectoryMatching;
import geco.model.UseDb;
import geco.model.fuzzy.AlphaCut;
import geco.model.fuzzy.FuzzyCheck;
import geco.model.fuzzy.FuzzyPoint;
import geco.model.util.CaseClause;
import geco.model.util.DbCollection;
import geco.model.util.Field;
import geco.model.util.GenerateAction;
import geco.model.util.NonFuzzyFunction;
import geco.model.util.Parameter;
import geco.model.util.Partition;
import geco.model.util.PartitionMatching;
import geco.model.util.SortField;
import geco.model.util.TrajectoryPartition;
import geco.model.util.Unpack;
import geco.model.util.WhereCase;
import net.fm.geco.engine.parser.utils.GenerateCommandCreator;
import net.fm.geco.model.Case;
import net.fm.geco.model.EOperator;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.NoFuzzyFunction;
import net.fm.geco.model.ParameterDefinition;
import net.fm.geco.model.PointDefinition;
import net.fm.geco.model.RangeDefinition;
import net.fm.geco.model.command.AddFieldsCommand;
import net.fm.geco.model.command.AlphaCutCommand;
import net.fm.geco.model.command.ExpandCommand;
import net.fm.geco.model.command.FilterCommand;
import net.fm.geco.model.command.FuzzyOperatorCommand;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.command.GenerateFuzzyCommand;
import net.fm.geco.model.command.GetCollectionCommand;
import net.fm.geco.model.command.GetDictionaryCommand;
import net.fm.geco.model.command.GroupCommand;
import net.fm.geco.model.command.ICommand;
import net.fm.geco.model.command.IntersectCollectionsCommand;
import net.fm.geco.model.command.JavascriptFunctionCommand;
import net.fm.geco.model.command.JoinCommand;
import net.fm.geco.model.command.KeepingDroppingFuzzySetsCommand;
import net.fm.geco.model.command.MergeCollectionsCommand;
import net.fm.geco.model.command.SaveAsCommand;
import net.fm.geco.model.command.SetFuzzySetsCommand;
import net.fm.geco.model.command.SetIntermediateCommand;
import net.fm.geco.model.command.SpatialJoinCommand;
import net.fm.geco.model.command.SubtractCollectionsCommand;
import net.fm.geco.model.command.TrajectoryMatchingCommand;
import net.fm.geco.model.command.UseDbCommand;
import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.PartitionCondition;
import net.fm.geco.model.condition.PartitionMatchingCondition;
import net.fm.geco.model.condition.TrajectoryPartitionCondition;
import net.fm.geco.model.condition.UnpackCondition;
import net.fm.geco.model.condition.WhereCondition;
import net.fm.geco.model.condition.join.AreaJoinCondition;
import net.fm.geco.model.condition.join.DistanceJoinCondition;
import net.fm.geco.model.condition.join.EFrom;
import net.fm.geco.model.condition.join.EOrientation;
import net.fm.geco.model.condition.join.EUnitOfMeasure;
import net.fm.geco.model.condition.join.IncludedJoinCondition;
import net.fm.geco.model.condition.join.IntersectJoinCondition;
import net.fm.geco.model.condition.join.JoinCondition;
import net.fm.geco.model.condition.join.MeetJoinCondition;
import net.fm.geco.model.condition.join.OrientationJoinCondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.operation.AllOperation;
import net.fm.geco.model.operation.IGeometryOperation;
import net.fm.geco.model.operation.IntersectionOperation;
import net.fm.geco.model.operation.LeftOperation;
import net.fm.geco.model.operation.RightOperation;
import net.fm.geco.model.reference.CollectionReference;
import net.fm.geco.model.reference.FieldReference;

public class Translator {
	private static String currentCollection;

	static public String getCurrentCollection() {
		return currentCollection;
	}

	static public ICommand translate(Instruction instr) {
		if (instr instanceof GetCollection) {
			return createGetCollection(instr);
		} else if (instr instanceof SaveAs) {
			return createSaveAs(instr);
		} else if (instr instanceof Filter) {
			return createFilter(instr);
		} else if (instr instanceof  FuzzyOperator) {
			return createFuzzyOperator(instr);
		} else if (instr instanceof MergeCollections) {
			return createMergeCollections(instr);
		} else if (instr instanceof IntersectCollections) {
			return createIntersectCollections(instr);
		} else if (instr instanceof JavascriptFunction) {
			return createJavascriptFunction(instr);
		} else if (instr instanceof SetIntermediateAs) {
			return createSetIntermediateAs(instr);
		} else if (instr instanceof SubtractCollections) {
			return createSubstractCollection(instr);
		} else if (instr instanceof Group) {
			return createGroup(instr);
		} else if (instr instanceof JoinCollections) {
			return createJoinCollections(instr);
		}else if(instr instanceof Expand){
			return createExpand(instr);
		}else if (instr instanceof TrajectoryMatching) {
			return createTrajectoryMatching(instr);
		}else if(instr instanceof SpatialJoin) {
			return createSpatialJoin(instr);
		}else if(instr instanceof UseDb) {
			return createUseDb(instr);		
		}else if(instr instanceof GetDictionary) {
			return createGetDictionary(instr);
		}

		return null;
	}


	// PF. Added on 22.07.2021
	// GET DICTIONARY
	private static ICommand createGetDictionary(Instruction instr) {
		GetDictionary gd = (GetDictionary) instr;
		GetDictionaryCommand gdc = new GetDictionaryCommand(gd.collection.collection, gd.collection.db, gd.collection.alias);
		return gdc;
	}

	//USE DB
	private static ICommand createUseDb(Instruction instr) {
		UseDb use = (UseDb) instr;
		UseDbCommand usedbcmd;
		if(use.type == 0) {
			//ON DEFAULT SERVER
			usedbcmd = new UseDbCommand(use.dbList, true);
		} else if(use.type == 1) {
			//ON SERVER serverName
			usedbcmd = new UseDbCommand(use.dbList, use.server);
		} else {
			//ON SERVER serverType connectionString
			//ATTENZIONE: use.server = serverType (in questo caso)
			usedbcmd = new UseDbCommand(use.dbList, use.server, use.connectionString);
		}

		return usedbcmd;
	}

	// GET COLLECTION
	private static GetCollectionCommand createGetCollection(Instruction instr) {
		GetCollectionCommand gcc;
		GetCollection gcp = (GetCollection) instr;
		//PF.
		int type = gcp.type;
		if (type == GetCollection.DB_TYPE) {
			String dbName = gcp.collection.db;
			String collectionName = gcp.collection.collection;
			currentCollection = collectionName;
			if (dbName == null) {
				gcc = new GetCollectionCommand(collectionName);
			} else {
				gcc = new GetCollectionCommand(dbName, collectionName);
			}
		} 
		else {
			String urlString = gcp.urlString;
			currentCollection = "fromWeb";
			gcc = new GetCollectionCommand(urlString, type);
		}
		
		return gcc;
	}

	// SAVE AS
	private static SaveAsCommand createSaveAs(Instruction instr) {
		SaveAs sap = (SaveAs) instr;
		String dbName = sap.collection.db;
		String collectionName = sap.collection.collection;
		SaveAsCommand sac;
		if (dbName == null) {
			sac = new SaveAsCommand(collectionName);
		} else {
			sac = new SaveAsCommand(dbName, collectionName);
		}
		return sac;
	}

	// FILTER (MODIFICATO!!!)
	private static FilterCommand createFilter(Instruction instr) {
		Filter filterInstr = (Filter) instr;
		List<WhereCase> wherecaselist = filterInstr.caseClause.whereList;
		TreeCondition tc;
		boolean keepOthers;
		List<WhereCondition> whereConditions = new ArrayList<>();

		if (filterInstr.caseClause.others.equals("KEEP")) {
			keepOthers = true;
		} else {
			keepOthers = false;
		}

		// scorro la lista dei where case
		for (int i = 0; i < wherecaselist.size(); i++) {
			// GENERATE
			GenerateCommand gc = null;
			if(wherecaselist.get(i).generateAction != null) {
				GenerateAction ga = wherecaselist.get(i).generateAction;
				GenerateCommandCreator gcc = new GenerateCommandCreator(ga, "Filter");
				gc = gcc.getGenerateCommand();
			}

			// GENERATE FUZZY
			List<GenerateFuzzyCommand> gfcList = null;
			if(wherecaselist.get(i).fuzzyChecks.size() > 0) {
				gfcList = new ArrayList<>();
				TreeCondition tcUsing;

				for (FuzzyCheck fg : wherecaselist.get(i).fuzzyChecks ) {
					tcUsing = new TreeCondition("Filter");
					tcUsing.parser2Engine(fg.using);
					WhereCondition using = new WhereCondition(Collections.singletonList(tcUsing));
					GenerateFuzzyCommand gfc = new GenerateFuzzyCommand(fg.fuzzySet, using);
					gfcList.add(gfc);
				}
			}

            // ALPHA-CUT
			List<AlphaCutCommand> alphaCutCommands = null;
			if(wherecaselist.get(i).alphaCuts.size() > 0) {
				alphaCutCommands = new ArrayList<>();
				for (AlphaCut acc : wherecaselist.get(i).alphaCuts) {
					alphaCutCommands.add(new AlphaCutCommand(acc.alphacut, acc.on));
				}
			}

            // DROPPING - KEEPING FUZZY SETS
            List<String> listKeepingFuzzySets = null;
            KeepingDroppingFuzzySetsCommand keepDropFuzzyCommand = null;
			if(wherecaselist.get(i).keepDropFuzzySets != null) {
				if(wherecaselist.get(i).keepDropFuzzySets.type == 0 || wherecaselist.get(i).keepDropFuzzySets.type == 1) {
					listKeepingFuzzySets = new ArrayList<>();
					for (String s : wherecaselist.get(i).keepDropFuzzySets.fuzzySets) {
						listKeepingFuzzySets.add(s);
					}
				}

				int type = wherecaselist.get(i).keepDropFuzzySets.type;
				//System.out.println(type);
				keepDropFuzzyCommand = new KeepingDroppingFuzzySetsCommand(listKeepingFuzzySets, type);
			}


			// TreeCondition
			tc = new TreeCondition("Filter");
			tc.parser2Engine(wherecaselist.get(i).condition);

			whereConditions.add(new WhereCondition(Collections.singletonList(tc), gc, gfcList, alphaCutCommands,
					keepDropFuzzyCommand));

		}

		Case caseFilter = new Case(whereConditions, keepOthers);

		return new FilterCommand(caseFilter, filterInstr.isRemoveDuplicates());
	}

	// CREATE FUZZY OPERATOR (AGGIUNTO)
	private static FuzzyOperatorCommand createFuzzyOperator(Instruction instr){

		FuzzyOperator fo = (FuzzyOperator) instr;

		// Nome fuzzy operator
		String name = fo.fuzzyOperator;

		// Parameters
		List<ParameterDefinition> parameters = new ArrayList<>();
		for(Parameter p : fo.parameters) {
			parameters.add(new ParameterDefinition(p.var, p.type));
		}

		// Precondition
		WhereCondition preCondition = null;
		TreeCondition tpc = new TreeCondition("Generate Fuzzy");
		tpc.parser2Engine(fo.preCondition);
		preCondition = new WhereCondition(Collections.singletonList(tpc));


		// EVALUATE
		/*WhereCondition evaluate = null;
		Predicate predicate = new Predicate(fo.evaluate);
		Condition condition = new Condition(predicate);
		TreeCondition tcEval = new TreeCondition();
		tcEval.parser2Engine(condition);
		evaluate = new WhereCondition(Collections.singletonList(tcEval));*/

		List<OperationTree> opTreeList = null;
		OperationTree operationTree = new OperationTree("Generate Fuzzy");
		operationTree.expression2Tree(fo.evaluate);
		opTreeList = Collections.singletonList(operationTree);

		// Range
		RangeDefinition range = new RangeDefinition(fo.range.x1, fo.range.x2);

		// Polyline
		List<PointDefinition> polyline = new ArrayList<>();
		for(FuzzyPoint p : fo.polyline) {
			polyline.add(new PointDefinition(Float.parseFloat(p.x), Float.parseFloat(p.y)));
		}

		return new FuzzyOperatorCommand(name, parameters, preCondition, opTreeList/*evaluate*/, range, polyline, fo.evaluate);
	}

	// CREATE JAVASCRIPT FUNCTION (AGGIUNTO)
	private static JavascriptFunctionCommand createJavascriptFunction(Instruction instr) {
		JavascriptFunction jsF = (JavascriptFunction) instr;

		// Nome funzione JS
		String jsFunctionName = jsF.functionName;

		// Parameters
		List<ParameterDefinition> parameters = new ArrayList<>();
		for(Parameter p : jsF.parameters) {
			parameters.add(new ParameterDefinition(p.var, p.type));
		}

		// Precondition
		TreeCondition tc = new TreeCondition("Create JS Function");
		tc.parser2Engine(jsF.preCondition);
		WhereCondition precondition = new WhereCondition(Collections.singletonList(tc));

		// Body
		String body = jsF.body;

		return new JavascriptFunctionCommand(jsFunctionName, parameters, precondition, body);
	}

	// MERGE
	private static MergeCollectionsCommand createMergeCollections(Instruction instr) {
		MergeCollections mg = (MergeCollections) instr;
		List<DbCollection> collectionList = mg.collectionList;
		List<CollectionReference> collections = new ArrayList<>();
		CollectionReference cr;

		for (int i = 0; i < collectionList.size(); i++) {
			if (collectionList.get(i).alias == null) {
				cr = new CollectionReference(collectionList.get(i).db, collectionList.get(i).collection);

			} else {
				cr = new CollectionReference(collectionList.get(i).db, collectionList.get(i).collection,
						collectionList.get(i).alias);
			}
			collections.add(cr);
		}

		return new MergeCollectionsCommand(collections, mg.isRemoveDuplicates());
	}

	// INTERSECT
	private static IntersectCollectionsCommand createIntersectCollections(Instruction instr) {
		IntersectCollections ic = (IntersectCollections) instr;
		// problema il parser accetta solo due collezioni alla volta mentre
		// l'engine vuole una lista di CollectionReference
		List<CollectionReference> collections = new ArrayList<>();
		CollectionReference cr1;
		CollectionReference cr2;
		if (ic.collection1.alias == null && ic.collection2.alias == null) {
			cr1 = new CollectionReference(ic.collection1.db, ic.collection1.collection);
			cr2 = new CollectionReference(ic.collection2.db, ic.collection2.collection);
			collections.add(cr1);
			collections.add(cr2);
		} else if (ic.collection1.alias != null && ic.collection2.alias != null) {
			cr1 = new CollectionReference(ic.collection1.db, ic.collection1.collection, ic.collection1.alias);
			cr2 = new CollectionReference(ic.collection2.db, ic.collection2.collection, ic.collection2.alias);
			collections.add(cr1);
			collections.add(cr2);
		} else if (ic.collection1.alias == null && ic.collection2.alias != null) {
			cr1 = new CollectionReference(ic.collection1.db, ic.collection1.collection);
			cr2 = new CollectionReference(ic.collection2.db, ic.collection2.collection, ic.collection2.alias);
			collections.add(cr1);
			collections.add(cr2);
		} else if (ic.collection1.alias != null && ic.collection2.alias == null) {
			cr1 = new CollectionReference(ic.collection1.db, ic.collection1.collection, ic.collection1.alias);
			cr2 = new CollectionReference(ic.collection2.db, ic.collection2.collection);
			collections.add(cr1);
			collections.add(cr2);
		}
		return new IntersectCollectionsCommand(collections);
	}

	// SET INTERMEDIATE AS
	private static SetIntermediateCommand createSetIntermediateAs(Instruction instr) {
		SetIntermediateAs sia = (SetIntermediateAs) instr;
		SetIntermediateCommand sic = new SetIntermediateCommand(sia.collection.collection);
		currentCollection = sia.collection.collection;
		return sic;
	}

	// SUBSTRACT COLLECTION
	private static SubtractCollectionsCommand createSubstractCollection(Instruction instr) {
		SubtractCollections sc = (SubtractCollections) instr;
		List<CollectionReference> collections = new ArrayList<>();
		CollectionReference cr1;
		CollectionReference cr2;
		if (sc.collection1.alias == null && sc.collection2.alias == null) {
			cr1 = new CollectionReference(sc.collection1.db, sc.collection1.collection);
			cr2 = new CollectionReference(sc.collection2.db, sc.collection2.collection);
			collections.add(cr1);
			collections.add(cr2);
		} else if (sc.collection1.alias != null && sc.collection2.alias != null) {
			cr1 = new CollectionReference(sc.collection1.db, sc.collection1.collection, sc.collection1.alias);
			cr2 = new CollectionReference(sc.collection2.db, sc.collection2.collection, sc.collection2.alias);
			collections.add(cr1);
			collections.add(cr2);
		} else if (sc.collection1.alias == null && sc.collection2.alias != null) {
			cr1 = new CollectionReference(sc.collection1.db, sc.collection1.collection);
			cr2 = new CollectionReference(sc.collection2.db, sc.collection2.collection, sc.collection2.alias);
			collections.add(cr1);
			collections.add(cr2);
		} else if (sc.collection1.alias != null && sc.collection2.alias == null) {
			cr1 = new CollectionReference(sc.collection1.db, sc.collection1.collection, sc.collection1.alias);
			cr2 = new CollectionReference(sc.collection2.db, sc.collection2.collection);
			collections.add(cr1);
			collections.add(cr2);
		}
		return new SubtractCollectionsCommand(collections);
	}

	// GROUP COLLECTION (da completare)
	private static GroupCommand createGroup(Instruction instr) {
		Group g = (Group) instr;

		int others = g.others;
		List<Partition> partitions = g.partitions;
		List<PartitionCondition> partitionCondition = new ArrayList<>();
		TreeCondition tc;
		List<ICondition> with;
		List<FieldReference> groupBy;
		List<FieldReference> orderBy ;
		List<Integer> versus ;

		//EC NUOVO
		boolean dropGrouping;

		// PartitionCondition(List<ICondition> with, List<FieldReference> groupBy,FieldName groupOutputField, List<FieldReference> orderBy,
		// GenerateCommand generate)
		for (int i = 0; i < partitions.size(); i++) {

			with = new ArrayList<>();
			groupBy = new ArrayList<>();
			orderBy = null;
			versus =null;

			dropGrouping = partitions.get(i).dropGroupingFields;	//EC NUOVO

			tc = new TreeCondition("Group");
			tc.parser2Engine(partitions.get(i).whereCondition);
			with.add(tc);
			GenerateAction ga = partitions.get(i).generate;
			GenerateCommandCreator gcc = new GenerateCommandCreator(ga, "Group");
			GenerateCommand gc = gcc.getGenerateCommand();
			for (Field field : partitions.get(i).by) {
				groupBy.add(new FieldReference("", field.toString()));
			}

			if(partitions.get(i).sortedBy != null){

				orderBy = new ArrayList<>();
				versus =new ArrayList<>();

				for (SortField sortField : partitions.get(i).sortedBy) {


					orderBy.add(new FieldReference("", sortField.field.toString()));

					if(sortField.versus == 1)
						versus.add(1);
					else
						versus.add(0);

				}
			}

			//EC NUOVO aggiunto parametro bool dropGrouping
			partitionCondition.add(new PartitionCondition(with, groupBy, FieldName.fromString(partitions.get(i).into.toString()), orderBy,versus, gc, dropGrouping));
			//  partitionCondition.add(new PartitionCondition(with, groupBy, partitions.get(i).into, orderBy,versus, gc, dropGrouping));
		}

		boolean keepOthers = false;
		if (others == 1) {
			keepOthers = false;
		}
		if (others == 0) {
			keepOthers = true;
		}
		if (others == -1) {
			keepOthers = false;
		}

		return new GroupCommand(partitionCondition, keepOthers);
	}

	// EXPAND

	private static ExpandCommand createExpand(Instruction instr){
		Expand e = (Expand) instr;

		boolean keepOthers = false;

		/* keepOther */
		if (e.others == 1) {
			keepOthers = false;
		}
		if (e.others == 0) {
			keepOthers = true;
		}
		if (e.others == -1) {
			keepOthers = false;
		}

		List<Unpack> unpacks = e.unpacks;
		List<UnpackCondition> unpackConditions = new ArrayList<>();
		TreeCondition tc;
		for (Unpack unpack : unpacks) {
// PF. - Generate Action is deprecated on 10.05.2021			
//			GenerateAction ga = unpack.generate;
//			GenerateCommandCreator gcc = new GenerateCommandCreator(ga, "Expand");
//			GenerateCommand gc = gcc.getGenerateCommand();
			tc = new TreeCondition("Expand");
			tc.parser2Engine(unpack.where);
//			unpackConditions.add(new UnpackCondition(Collections.singletonList(tc), new FieldReference("Expand", unpack.array.toString()), FieldName.fromString(unpack.to.toString()), gc));
			unpackConditions.add(new UnpackCondition(Collections.singletonList(tc), new FieldReference("Expand", unpack.array.toString()), FieldName.fromString(unpack.to.toString())));
		}

		return new ExpandCommand(unpackConditions, keepOthers);
	}

	// GENERATE


	// JOIN
	private static JoinCommand createJoinCollections(Instruction instr) {
		JoinCollections j = (JoinCollections) instr;
		JoinCommand jc;
		CollectionReference cr1 = null;
		CollectionReference cr2 = null;
		TreeCondition tc;
		boolean keepOthers = false;
		AddFieldsCommand addFieldsCommand = null;
		SetFuzzySetsCommand setFuzzySets = null;

		/* gestione delle collezioni su cui fare join */
		if (j.collection1.alias == null && j.collection2.alias == null) {
			cr1 = new CollectionReference(j.collection1.db, j.collection1.collection);
			cr2 = new CollectionReference(j.collection2.db, j.collection2.collection);
		} else if (j.collection1.alias != null && j.collection2.alias != null) {
			cr1 = new CollectionReference(j.collection1.db, j.collection1.collection, j.collection1.alias);
			cr2 = new CollectionReference(j.collection2.db, j.collection2.collection, j.collection2.alias);
		} else if (j.collection1.alias == null && j.collection2.alias != null) {
			cr1 = new CollectionReference(j.collection1.db, j.collection1.collection);
			cr2 = new CollectionReference(j.collection2.db, j.collection2.collection, j.collection2.alias);
		} else if (j.collection1.alias != null && j.collection2.alias == null) {
			cr1 = new CollectionReference(j.collection1.db, j.collection1.collection, j.collection1.alias);
			cr2 = new CollectionReference(j.collection2.db, j.collection2.collection);
		}

		Case caseFilter = null;

		/* keepOther */
		if(j.caseClause != null) {
			List<WhereCase> wherecaselist = j.caseClause.whereList;
			List<WhereCondition> whereConditions = new ArrayList<>();

			if (j.caseClause.others.equals("KEEP")) {
				keepOthers = true;
			} else {
				keepOthers = false;
			}

			/* creazione lista di alberi dei where */
			for (int i = 0; i < wherecaselist.size(); i++){
				GenerateAction ga = wherecaselist.get(i).generateAction;
				GenerateCommandCreator gcc = new GenerateCommandCreator(ga);
				GenerateCommand gc = gcc.getGenerateCommand();
				tc = new TreeCondition(); // attenzione da
				tc.parser2Engine(wherecaselist.get(i).condition);
				//whereConditions.add(new WhereCondition(Collections.singletonList(tc), null, gc));
				// Aggiugere GENERATE FUZZY, ALPHA-CUT???????????
				whereConditions.add(new WhereCondition(Collections.singletonList(tc), gc, null, null, null));
			}

			caseFilter = new Case(whereConditions, keepOthers);
		 }

		/* ADD FIELDS */
		if(j.addFields != null) {
			List<NoFuzzyFunction> noFuzzyFunctions = new ArrayList<>();
			for (NonFuzzyFunction nff : j.addFields.fieldList) {
				noFuzzyFunctions.add(new NoFuzzyFunction(nff.type, nff.unit, nff.from, nff.orientation, nff.side));
			}

			List<List<String>> s = new ArrayList<>();

			for (Field f : j.addFields.asList) {
				List<String> innerList = new ArrayList<>();
				String str = f.toString();
				str = str.replaceFirst("\\.", "");
				String[] sArray = str.split("\\.");
				for(int i = 0; i < sArray.length; i++) {
					innerList.add(sArray[i]);
				}
				s.add(innerList);
			}

			addFieldsCommand = new AddFieldsCommand(noFuzzyFunctions, s);
		}

		if (j.setFuzzySets != null) 
			setFuzzySets = new SetFuzzySetsCommand(j.setFuzzySets);


		jc = new JoinCommand(cr1, cr2, addFieldsCommand, setFuzzySets, caseFilter, j.isRemoveDuplicates());
		return jc;
	}


	// SPATIAL JOIN
    private static SpatialJoinCommand createSpatialJoin(Instruction instr) {
        SpatialJoin sj = (SpatialJoin) instr;
        CollectionReference cr1 = null;
        CollectionReference cr2 = null;
		AddFieldsCommand addFieldsCommand = null;
		SetFuzzySetsCommand setFuzzySets = null;
        boolean keepOthers = false;


        /* gestione delle collezioni su cui fare spatialjoin */
        if (sj.collection1.alias == null && sj.collection2.alias == null) {
            cr1 = new CollectionReference(sj.collection1.db, sj.collection1.collection);
            cr2 = new CollectionReference(sj.collection2.db, sj.collection2.collection);
        } else if (sj.collection1.alias != null && sj.collection2.alias != null) {
            cr1 = new CollectionReference(sj.collection1.db, sj.collection1.collection, sj.collection1.alias);
            cr2 = new CollectionReference(sj.collection2.db, sj.collection2.collection, sj.collection2.alias);

        } else if (sj.collection1.alias == null && sj.collection2.alias != null) {
            cr1 = new CollectionReference(sj.collection1.db, sj.collection1.collection);
            cr2 = new CollectionReference(sj.collection2.db, sj.collection2.collection, sj.collection2.alias);

        } else if (sj.collection1.alias != null && sj.collection2.alias == null) {
            cr1 = new CollectionReference(sj.collection1.db, sj.collection1.collection, sj.collection1.alias);
            cr2 = new CollectionReference(sj.collection2.db, sj.collection2.collection);

        }

        Case caseFilter = null;

        if(sj.caseClause != null){
        	 /* caseFilter */
            List<WhereCase> wherecaselist = sj.caseClause.whereList;
            TreeCondition tc;
            List<WhereCondition> whereConditions = new ArrayList<>();
            /* keepOther */

            if (sj.caseClause.others.equals(CaseClause.KEEP)) {
                keepOthers = true;
            } else {
                keepOthers = false;
            }

	        for (int i = 0; i < wherecaselist.size(); i++) {
	            /* creazione del generate */
	            GenerateAction ga = wherecaselist.get(i).generateAction;
	            GenerateCommandCreator gcc = new GenerateCommandCreator(ga);
	            GenerateCommand gc = gcc.getGenerateCommand();
	            /*------------------------------------------------------------*/
	            tc = new TreeCondition();
	            tc.parser2Engine(wherecaselist.get(i).condition);
	            //whereConditions.add(new WhereCondition(Collections.singletonList(tc), null, gc));
				whereConditions.add(new WhereCondition(Collections.singletonList(tc), gc, null, null, null));
	        }

	        caseFilter = new Case(whereConditions, keepOthers);
        }
        JoinCondition joinCondition = null;

        if(sj.on !=null) {
        	joinCondition = evaluateJoinCondition(sj.on);
        }

        IGeometryOperation geometryOperation = evaluateGeometryOperation(sj.geometry);

		/* ADD FIELDS */
		if(sj.addFields != null) {
			List<NoFuzzyFunction> noFuzzyFunctions = new ArrayList<>();

			for (NonFuzzyFunction nff : sj.addFields.fieldList) {
				noFuzzyFunctions.add(new NoFuzzyFunction(nff.type, nff.unit, nff.from, nff.orientation, nff.side));
			}

			List<List<String>> s = new ArrayList<>();

			for (Field f : sj.addFields.asList) {
				List<String> innerList = new ArrayList<>();
				String str = f.toString();
				str = str.replaceFirst("\\.", "");
				String[] sArray = str.split("\\.");
				for(int i = 0; i < sArray.length; i++) {
					innerList.add(sArray[i]);
				}
				s.add(innerList);
			}


			addFieldsCommand = new AddFieldsCommand(noFuzzyFunctions, s);
		}

		if (sj.setFuzzySets != null)
			setFuzzySets = new SetFuzzySetsCommand(sj.setFuzzySets);
		
        return new SpatialJoinCommand(cr1, cr2, joinCondition, geometryOperation, 
        								addFieldsCommand, setFuzzySets, caseFilter, sj.isRemoveDuplicates());
    }

    //TRAJECTORY MATCHING
	private static TrajectoryMatchingCommand createTrajectoryMatching(Instruction instr) {
		TrajectoryMatching tm = (TrajectoryMatching) instr;
		int others = tm.others;
		CollectionReference cr1=null;
		CollectionReference cr2=null;

		if (tm.collection1.alias == null && tm.collection2.alias == null) {
			cr1 = new CollectionReference(tm.collection1.db, tm.collection1.collection);
			cr2 = new CollectionReference(tm.collection2.db, tm.collection2.collection);
		} else if (tm.collection1.alias != null && tm.collection2.alias != null) {
			cr1 = new CollectionReference(tm.collection1.db, tm.collection1.collection, tm.collection1.alias);
			cr2 = new CollectionReference(tm.collection2.db, tm.collection2.collection, tm.collection2.alias);

		} else if (tm.collection1.alias == null && tm.collection2.alias != null) {
			cr1 = new CollectionReference(tm.collection1.db, tm.collection1.collection);
			cr2 = new CollectionReference(tm.collection2.db, tm.collection2.collection, tm.collection2.alias);

		} else if (tm.collection1.alias != null && tm.collection2.alias == null) {
			cr1 = new CollectionReference(tm.collection1.db, tm.collection1.collection, tm.collection1.alias);
			cr2 = new CollectionReference(tm.collection2.db, tm.collection2.collection);

		}

		List<TrajectoryPartition> partitions = tm.partitions;
		List<TrajectoryPartitionCondition> partitionConditions= new ArrayList<>();

		boolean keepOthers = false;
		if (others == 1) {
			keepOthers = false;
		}
		if (others == 0) {
			keepOthers = true;
		}
		if (others == -1) {
			keepOthers = false;
		}

		for (TrajectoryPartition partition: partitions) {
			TrajectoryPartitionCondition partitionCondition;
			// selectionConditionPartition
			TreeCondition tcp= new TreeCondition("Partition");
			List<ICondition> selectionConditionPartition= new ArrayList<>();
			tcp.parser2Engine(partition.selectionCondition);
			selectionConditionPartition.add(tcp);

			List<PartitionMatching> matchings= partition.matchings;
			List<PartitionMatchingCondition> matchingConditions = new ArrayList<>();

			for (PartitionMatching matching: matchings) {
				PartitionMatchingCondition matchingCondition;
				//current matching
				Field fieldMatching = matching.matching;
				Field fieldWRT= matching.wrt;
				FieldReference matchingTarget= new FieldReference(cr1.getAlias(),fieldMatching.toString());
				FieldReference WRTinput= new FieldReference(cr2.getAlias(),fieldWRT.toString());
				FieldName into = FieldName.fromString(matching.into.toString());
				EUnitOfMeasure unit = evaluateMeasureUnit(matching.unit);
				double threshold= matching.value;

				//EC NUOVO. clausola Adding field To Input
				Field pathToInput = matching.pathToInput;

				List<ICondition> selectionConditionMatching=new ArrayList<>();

				if(matching.hasWhereCondition()) {
					TreeCondition tcm= new TreeCondition("Matching");
					tcm.parser2Engine(matching.whereCondition);
					selectionConditionMatching.add(tcm);

				}
				double min_similarity=0;
				if(matching.hasSimilarity()) {
					min_similarity=matching.similarity;
				}

				//EC NUOVO AGGIUNTO PARAMETRO pathToInput
				matchingCondition = new PartitionMatchingCondition(matchingTarget,WRTinput,selectionConditionMatching,into ,unit ,threshold,min_similarity,pathToInput);
				matchingConditions.add(matchingCondition);
			}


			partitionCondition = new TrajectoryPartitionCondition(selectionConditionPartition,matchingConditions);
			partitionConditions.add(partitionCondition);

		}

		return new TrajectoryMatchingCommand(cr1,cr2,partitionConditions,keepOthers);
	}

    private static JoinCondition evaluateJoinCondition(NonFuzzyFunction on) {
        JoinCondition jc = null;

        if (on.type == 0) {
            jc = new DistanceJoinCondition(evaluateMeasureUnit(on.unit),evaluateOperator(on.comparator),on.distance);
        } else if (on.type == 1) {
            jc = new AreaJoinCondition(evaluateMeasureUnit(on.unit),evaluateOperator(on.comparator),on.area);
        } else if (on.type == 2) {
        	if(on.delta == 0) {
        		jc = new OrientationJoinCondition(evaluateSide(on.from),evaluateOrientation(on.orientation));
        	} else {
        		jc = new OrientationJoinCondition(evaluateSide(on.from),evaluateOrientation(on.orientation),on.delta);
        	}
        } else if (on.type == 3) {
            jc = new IncludedJoinCondition(evaluateSide(on.side));
        } else if (on.type == 4) {
            jc = new IncludedJoinCondition(EFrom.LEFT);
        } else if (on.type == 5) {
            jc = new IncludedJoinCondition(EFrom.RIGHT);
        } else if (on.type == 6) {
            jc = new MeetJoinCondition();
        } else if (on.type == 7) {
            jc = new IntersectJoinCondition();
        }

        return jc;
    }

    private static EUnitOfMeasure evaluateMeasureUnit(String unit) {
        EUnitOfMeasure measureUnit = null;
        if (unit.equals("M")) {
            measureUnit = EUnitOfMeasure.METERS;
        } else if (unit.equals("KM")) {
            measureUnit = EUnitOfMeasure.KILOMETERS;
        } else if (unit.equals("ML")) {
            measureUnit = EUnitOfMeasure.MILES;
        }
        return measureUnit;
    }


    private static EFrom evaluateSide(String side) {
        EFrom fromSide = null;
        if (side.equals("LEFT")) {
            fromSide = EFrom.LEFT;
        } else if (side.equals("RIGHT")) {
            fromSide = EFrom.RIGHT;
        }
        return fromSide;
    }

	private static EOperator evaluateOperator(String comparator) {
		EOperator operator;

		if (comparator.equals("=")) {
			operator = EOperator.EQUALS;
		} else if (comparator.equals(">")) {

			operator = EOperator.GREATER_THAN;
		} else if (comparator.equals(">=")) {

			operator = EOperator.GREATER_EQUAL;
		} else if (comparator.equals("<")) {

			operator = EOperator.LESS_THAN;
		} else if (comparator.equals("<=")) {

			operator = EOperator.LESS_EQUAL;
		} else if (comparator.equals("!=")) {

			operator = EOperator.NOT_EQUALS;
		} else {
			operator = null;
		}

		return operator;

	}

	private static EOrientation evaluateOrientation(String orientation) {
		switch (orientation) {
		case "N":
			return EOrientation.N;
		case "NNE":
			return EOrientation.NNE;
		case "NE":
			return EOrientation.NE;
		case "ENE":
			return EOrientation.ENE;
		case "E":
			return EOrientation.E;
		case "ESE":
			return EOrientation.ESE;
		case "SE":
			return EOrientation.SE;
		case "SSE":
			return EOrientation.SSE;
		case "S":
			return EOrientation.S;
		case "SSW":
			return EOrientation.SSW;
		case "SW":
			return EOrientation.SW;
		case "WSW":
			return EOrientation.WSW;
		case "W":
			return EOrientation.W;
		case "WNW":
			return EOrientation.WNW;
		case "NW":
			return EOrientation.NW;
		case "NNW":
			return EOrientation.NNW;
		}
		return null;

	}

	private static IGeometryOperation evaluateGeometryOperation(int geometryOp) {
		IGeometryOperation geometryOperation = null;
		// public static int GEOMETRY_UNDEFINED = -1;
		// public static int GEOMETRY_ALL = 0;
		// public static int GEOMETRY_RIGHT = 1;
		// public static int GEOMETRY_LEFT = 2;
		// public static int GEOMETRY_INTERSECTION = 3;

		if (geometryOp == 0) {
			geometryOperation = new AllOperation();
		} else if (geometryOp == 1) {
			geometryOperation = new RightOperation();
		} else if (geometryOp == 2) {
			geometryOperation = new LeftOperation();
		} else if (geometryOp == 3) {
			geometryOperation = new IntersectionOperation();
		}

		return geometryOperation;
	}
}