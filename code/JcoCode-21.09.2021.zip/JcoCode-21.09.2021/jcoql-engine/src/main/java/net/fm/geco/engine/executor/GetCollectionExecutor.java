package net.fm.geco.engine.executor;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.mongodb.utils.DocumentUtils;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.GetCollectionCommand;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;

@Executor(GetCollectionCommand.class)
public class GetCollectionExecutor implements IExecutor<GetCollectionCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public GetCollectionExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}

	@Override
	public void execute(Pipeline pipeline, GetCollectionCommand command) throws ExecuteProcessException {
		if (command.getType() == GetCollectionCommand.DB_TYPE) {
			if (command.getDbName() != null) {
				IDatabase database = databaseRegistry.getDatabase(command.getDbName());
				if (database == null) {
					throw new ExecuteProcessException("[GET COLLECTION]: Invalid database " + command.getDbName());
				}
	
				IDocumentCollection collection = database.getCollection(command.getCollectionName());
				pipeline.addCollection(collection);
			} else {
				// devo prendere la collezione temporanea
				IDocumentCollection collection = pipeline.getCollection(command.getCollectionName());
				pipeline.addCollection(collection);
			}
		}
		// PF. Get Collection from URL
		else {   
			IDocumentCollection collection = getCollectionFromWeb(command.getUrlString());
			pipeline.addCollection(collection);
		}
	}

    private IDocumentCollection getCollectionFromWeb (String urlSt) {
        int timeout = 5000;

        urlSt = urlSt.replace(" ", "%20");
        urlSt = urlSt.replace(">", "%3E");
        urlSt = urlSt.replace("<", "%3C");
        try {
            RequestConfig config = RequestConfig.custom()
            		.setConnectTimeout(timeout)
            		.setConnectionRequestTimeout(timeout)
            		.setSocketTimeout(timeout).build();
            CloseableHttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(config).build();

            HttpGet request = new HttpGet(urlSt);

            // add request header
            String USER_AGENT = "Mozilla/5.0";
            request.addHeader("User-Agent", USER_AGENT);

            HttpResponse response = client.execute(request); // conn= response
            
            String strCurrentLine;
            StringBuffer outStBuf = new StringBuffer();
            BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            while ((strCurrentLine = rd.readLine()) != null) {
            	outStBuf.append(strCurrentLine+"\n");
            }
            
            String outSt = outStBuf.toString().trim();
	    	if (outSt.startsWith("[") && outSt.endsWith("]"))
	    		outSt = "{ \"data\" : "+outSt+" }";

	    	rd.close();
	    	client.close();

	    	List<DocumentDefinition> list = new ArrayList<>();
			Document bson = Document.parse(outSt);
			list.add(DocumentUtils.mapDocumentDefinitionFromBson(bson));
			IDocumentCollection collection = new SimpleDocumentCollection("fromWeb", list);
			return collection;

        } catch (Exception e) {
        	e.printStackTrace();
        }
	
        return null;
    }



}
