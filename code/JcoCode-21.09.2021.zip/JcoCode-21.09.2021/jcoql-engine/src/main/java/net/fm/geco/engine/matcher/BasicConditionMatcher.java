package net.fm.geco.engine.matcher;

import java.util.Date;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.EOperator;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.expression.BasicExpression;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.IdValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class BasicConditionMatcher implements IMatcher{

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {
		
		BasicCondition bc = (BasicCondition) condition;
		BasicExpression be = (BasicExpression)bc.getExpression();

		/* Caso 3>2 esempio */
		if(be.getLeft() instanceof SimpleValue && be.getRight() instanceof SimpleValue){
			SimpleValue left = (SimpleValue)be.getLeft();
			SimpleValue right = (SimpleValue)be.getRight();
			
			return evaluate(left,be.getOperator(),right,pipeline);
		}
		
		/* Caso .a = 3 o .a = true*/	
		else if(be.getLeft() instanceof FieldValue && be.getRight() instanceof SimpleValue){
			FieldValue left = (FieldValue)be.getLeft();
			SimpleValue right = (SimpleValue)be.getRight();
			
			return evaluate(left,be.getOperator(),right,pipeline);
		}

		/* Caso   3=.a o  true= .a*/
		else if(be.getLeft() instanceof SimpleValue && be.getRight() instanceof FieldValue){
			SimpleValue left = (SimpleValue)be.getLeft();
			FieldValue right = (FieldValue)be.getRight();

			return evaluate(left,be.getOperator(),right,pipeline);			
		}
		
		/* Caso .a = .pippo */
		else if(be.getLeft() instanceof FieldValue && be.getRight() instanceof FieldValue){
			FieldValue left = (FieldValue)be.getLeft();
			FieldValue right = (FieldValue)be.getRight();
			
			return evaluate(left,be.getOperator(),right,pipeline);
		}

		// caso ID > 0
		else if(be.getLeft() instanceof IdValue && be.getRight() instanceof SimpleValue) {
			return evaluate(be.getLeft().getStringValue(), be.getOperator(), (SimpleValue)be.getRight(), pipeline);
		}

		// ID > FieldValue
		else if(be.getLeft() instanceof IdValue && be.getRight() instanceof FieldValue) {

			String left = be.getLeft().getStringValue();
			FieldValue right = (FieldValue)be.getRight();
			return evaluate(left, be.getOperator(), right, pipeline);
		}

		// value > ID
		else if(be.getLeft() instanceof SimpleValue && be.getRight() instanceof IdValue) {
			String right = be.getLeft().getStringValue();
			return evaluate((SimpleValue)be.getLeft(), be.getOperator(), right, pipeline);
		}

		// field > ID
		else if(be.getLeft() instanceof FieldValue && be.getRight() instanceof IdValue) {
			String right = be.getRight().getStringValue();
			FieldValue left = (FieldValue)be.getLeft();
			return evaluate(left, be.getOperator(), right, pipeline);
		}

		// ID > ID
		else if(be.getLeft() instanceof IdValue && be.getRight() instanceof IdValue) {
			String left = be.getLeft().getStringValue();
			String right = be.getRight().getStringValue();
			return evaluate(left, be.getOperator(), right, pipeline);
		}

		throw new RuntimeException("Error: The Basic Expression contains undefined types");
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		if(matches(condition, pipeline)) {
			return 1;
		} else {
			return 0;
		}
	}


	private boolean evaluate(SimpleValue left, EOperator operator, SimpleValue right,Pipeline pipeline){
		

						
			/* Booleano e booleano*/
			if(left.getType() == EValueType.BOOLEAN && right.getType() == EValueType.BOOLEAN){
				
				
				if(operator == EOperator.EQUALS){
	
					
					return ((Boolean)left.getValue())==((Boolean)right.getValue());
					
				}else if(operator == EOperator.NOT_EQUALS){
					
					return !((Boolean)left.getValue())==((Boolean)right.getValue());
					
					
				}
				else {
					throw new RuntimeException("Operation undefined for booleans");
				}
				
			}else if(left.getType() == EValueType.INTEGER && right.getType() == EValueType.INTEGER){
				
	
				return checkResult(left.getValue(), operator, right.getValue());
						
			
		}else if(left.getType() == EValueType.DATE && right.getType() == EValueType.DATE)	{
			
				
				return checkResult(left.getValue(), operator, right.getValue());
			
			
		}else if(left.getType() == EValueType.INTEGER && right.getType() == EValueType.DECIMAL){
			
			
			return checkResult(left.getValue(), operator, right.getValue());
					
			
		}else if(left.getType() == EValueType.DECIMAL && right.getType() == EValueType.INTEGER){
			
			
			return checkResult(left.getValue(), operator, right.getValue());
					
			
		}else if(left.getType() == EValueType.DECIMAL && right.getType() == EValueType.DECIMAL){
			
			
			return checkResult(left.getValue(), operator, right.getValue());
					
			
		}else if(left.getType() == EValueType.STRING && right.getType() == EValueType.STRING){
			
			
			if(operator == EOperator.EQUALS){
				
				return ((String)left.getValue()).equals((String)right.getValue());
			}else if(operator == EOperator.NOT_EQUALS){
				return !((String)left.getValue()).equals((String)right.getValue());

			}
			else {
				return false;
			}	
			
		}else if(left.getType() == EValueType.NULL && right.getType() == EValueType.NULL){
			
			
			if(operator == EOperator.EQUALS){
				
				return ((left.getValue() == null)&& (right.getValue() == null));
				
				
			}else if(operator == EOperator.NOT_EQUALS){
				
				return !((left.getValue() == null)&& (right.getValue() == null));
				
				
			}else{
				throw new RuntimeException("Operation undefined for null type");

				
			}

		}else
			return false;
		
	}

	
	private boolean evaluate(FieldValue left, EOperator operator, SimpleValue right, Pipeline pipeline){
		FieldReference f = left.getFieldReference();

		// PF. � qua l'errore
		// PF prima i commenti nelle due righe seguenti erano invertite .. e non funzionava
		DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
		//DocumentDefinition document = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());

		if(document.getValue(f.getFieldName()) != null && document.getValue(f.getFieldName()) instanceof SimpleValue){
			Value value = document.getValue(f.getFieldName());
			return 	evaluate((SimpleValue)value, operator, right, pipeline);
		} else {
			if(pipeline.getFuzzyOperatorParameters() != null) {
				DocumentDefinition document2 = pipeline.getFuzzyOperatorParameters();
				Value value2 = document2.getValue(f.getFieldName());
				if (value2 != null && value2 instanceof SimpleValue) {
					return evaluate((SimpleValue) value2, operator, right, pipeline);
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	}
	
	private boolean evaluate(SimpleValue left, EOperator operator, FieldValue right,Pipeline pipeline){

		FieldReference f = right.getFieldReference();
		DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

		if(document.getValue(f.getFieldName()) != null && document.getValue(f.getFieldName()) instanceof SimpleValue){
			Value value = document.getValue(f.getFieldName());
			return 	evaluate(left, operator, (SimpleValue)value, pipeline);
		} else {
			if(pipeline.getFuzzyOperatorParameters() != null) {
				DocumentDefinition document2 = pipeline.getFuzzyOperatorParameters();
				if (document2.getValue(f.getFieldName()) != null && document2.getValue(f.getFieldName()) instanceof SimpleValue) {
					Value value2 = document2.getValue(f.getFieldName());
					return evaluate(left, operator, (SimpleValue) value2, pipeline);
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	}

	/* ** ** ** ** ** ** ** ** */
	// id, value
	private boolean evaluate(String left, EOperator operator, SimpleValue right, Pipeline pipeline) {

		//DocumentDefinition document1 = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());
		Value value1 = pipeline.getJsFunctionParametersMap().get(left);
		if(right != null && value1 instanceof SimpleValue){
			return 	evaluate((SimpleValue)value1, operator, right, pipeline);
		} else {
			return false;
		}
	}

	// id, FieldValue
	private boolean evaluate(String left, EOperator operator, FieldValue right, Pipeline pipeline) {

		//DocumentDefinition document1 = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());
		Value value1 = pipeline.getJsFunctionParametersMap().get(left);

		FieldReference f = right.getFieldReference();
		DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
		Value value2 = document.getValue(f.getFieldName());

		if(value1 instanceof SimpleValue && value2 != null){
			return 	evaluate((SimpleValue)value1, operator, (SimpleValue)value2, pipeline);
		} else {
			return false;
		}
	}

	// value, id
	private boolean evaluate(SimpleValue left, EOperator operator, String right, Pipeline pipeline) {
		//DocumentDefinition document2 = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());
		Value value2 = pipeline.getJsFunctionParametersMap().get(right);

		if(left != null && value2 instanceof SimpleValue){
			return 	evaluate(left, operator, (SimpleValue)value2, pipeline);
		} else {
			return false;
		}
	}

	// field, num
	private boolean evaluate(FieldValue left, EOperator operator, String right, Pipeline pipeline) {
		//DocumentDefinition document2 = (DocumentDefinition) pipeline.get(pipeline.getCurrentCollectionName());
		Value value2 = pipeline.getJsFunctionParametersMap().get(right);

		FieldReference f = left.getFieldReference();
		DocumentDefinition document1 = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
		Value value1 = document1.getValue(f.getFieldName());

		if(value1 instanceof SimpleValue && value2 instanceof SimpleValue){
			return 	evaluate((SimpleValue)value1, operator, (SimpleValue)value2, pipeline);
		} else {
			return false;
		}
	}

	
	// id id
	private boolean evaluate(String left, EOperator operator, String right, Pipeline pipeline) {
		Value value1 = pipeline.getJsFunctionParametersMap().get(left);
		Value value2 = pipeline.getJsFunctionParametersMap().get(right);

		if(value1 instanceof SimpleValue && value2 instanceof SimpleValue){
			return 	evaluate((SimpleValue) value1, operator, (SimpleValue) value2, pipeline);
		} else {
			return false;
		}
	}

	/* ** ** ** ** ** ** ** ** */

	
	private boolean evaluate(FieldValue left, EOperator operator, FieldValue right,Pipeline pipeline){
		FieldReference f1 = left.getFieldReference();
		FieldReference f2 = right.getFieldReference();
		
		DocumentDefinition document1 = (DocumentDefinition) pipeline.get(f1.getCollectionAlias());
		DocumentDefinition document2 = (DocumentDefinition) pipeline.get(f2.getCollectionAlias());

		Value value1 = document1.getValue(f1.getFieldName());
		Value value2 = document2.getValue(f2.getFieldName());
		
		if(value1 != null && value1 instanceof SimpleValue && value2 != null && value2 instanceof SimpleValue){
			return 	evaluate((SimpleValue)value1, operator, (SimpleValue)value2, pipeline);
		} else {
			return false;
		}
	}
	
	private boolean checkResult(Object left, EOperator operator, Object right){
		
		double result;
		
		if(left instanceof Long && right instanceof Long ){
			
			result = (Long)left - (Long)right;
			
		}else if(left instanceof Long && right instanceof Double){
			
			result = ((Long)left).doubleValue() - (Double)right;
			
		}else if(left instanceof Double && right instanceof Long){
			
			result = (Double)left - ((Long)right).doubleValue();
			
		}else if(left instanceof Date && right instanceof Date){
			
			result = ((Date)left).getTime() - ((Date)right).getTime();			
			
		}else{
			
			result = (Double)left - (Double)right;
			
		}
			
		if(result > 0 && operator == EOperator.GREATER_THAN)
			return true;
		else if(result == 0 && operator == EOperator.EQUALS)
			return true;
		else if(result >= 0 && operator == EOperator.GREATER_EQUAL)
			return true;
		else if(result < 0 && operator == EOperator.LESS_THAN)
			return true;
		else if(result <= 0 && operator == EOperator.LESS_EQUAL)
			return true;
		else if(result != 0 && operator == EOperator.NOT_EQUALS)
			return true;
		else
			return false;
						
	}
	
}
