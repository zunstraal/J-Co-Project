package net.fm.geco.engine.executor.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.condition.UnpackCondition;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class SynchronizedExpandCycle extends Thread {

	private int id, nThreads;
	private LinkedBlockingQueue<DocumentDefinition> queue;

	private UnpackCondition unpack;
	private List<Value> listValues; 
	private List<FieldDefinition> outputList;

	public SynchronizedExpandCycle(int id, int nThread, LinkedBlockingQueue<DocumentDefinition> queue, UnpackCondition unpack, List<Value> listValues, List<FieldDefinition> outputList) {
		this.id = id;
		this.nThreads = nThread;
		this.queue = queue;
		setPriority(10);

		this.unpack = unpack; 
		this.listValues = listValues;
		this.outputList = outputList;
	}

	
    @Override
    public void run() {
    	// fundamental
    	int index  = id;   				
    	
    	while (index < listValues.size()) {
			Value v = listValues.get(index);

//			GenerateCommand generate = unpack.getGenerate();
//			GenerateCommandEvaluator evaluator = new GenerateCommandEvaluator();

			List<FieldDefinition> arrayElements = new ArrayList<>();
			arrayElements.add(new FieldDefinition("position", new SimpleValue(index)));
			arrayElements.add(new FieldDefinition("item", v));
			DocumentValue arrayField = new DocumentValue(new DocumentDefinition(arrayElements));
			FieldDefinition fd = new FieldDefinition(unpack.getOutputField().getLastLevelName(), arrayField);
			// build the array field hierarchy (if existing) es .a.b.c
			for (int l=unpack.getOutputField().getLevel()-2; l>=0; l--) {
				arrayElements = new ArrayList<>();
				arrayElements.add(fd);
				arrayField = new DocumentValue(new DocumentDefinition(arrayElements));
				fd = new FieldDefinition(unpack.getOutputField().getLevelName(l), arrayField);
			}
			outputList.add(fd);
			DocumentDefinition newDoc = new DocumentDefinition(outputList);

			/*	PF. Generatae Action depreacared on 07.05.2021
			if (generate != null) {
				Pipeline p2 = new Pipeline();
				p2.add(newDoc, "Expand");
				newDoc = evaluator.evaluate(p2, generate);											
			}
*/
			if(newDoc != null) {
				try {
					queue.put(newDoc);
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
	            	throw new ExecuteProcessException("[SynchronizedFilterCycle]: terminated");
				}
			}

			// fundamental
			index += nThreads;  
    	}
    }


}
