package net.fm.geco.engine.matcher;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.FieldValueCondition;
import net.fm.geco.model.condition.FuzzyOperatorCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.IdCondition;
import net.fm.geco.model.condition.IfFailsCondition;
import net.fm.geco.model.condition.KnownCondition;
import net.fm.geco.model.condition.UnknownCondition;
import net.fm.geco.model.condition.ValueTypeCondition;
import net.fm.geco.model.condition.WithinFuzzySetsCondition;
import net.fm.geco.model.condition.tree.OperationCondition;
import net.fm.geco.model.condition.tree.TreeCondition;

public class IfFailsConditionMatcher implements IMatcher {
    @Override
    public boolean matches(ICondition condition, Pipeline pipeline) throws ScriptException {
        return false;
    }

    @Override
    public double fuzzyMatches(ICondition condition, Pipeline pipeline) throws ScriptException {

        IfFailsCondition c = (IfFailsCondition) condition;
        Double defaultValue = Double.parseDouble(c.getDefaultValue());

        double match = -1.0;
        double result;

        for(ICondition icond  : c.getConditions()) {
            IMatcher matcher = getMatcher(icond);
            if(matcher != null) {
                result = matcher.fuzzyMatches(icond, pipeline);
                if(result != -1.0) {
                    match = result;
                } else {
                    match = defaultValue;
                }
            }
        }

        return match;
    }

    private IMatcher getMatcher(ICondition condition) {

        IMatcher matcher = null;
        if (condition instanceof FieldPresenceCondition) {
            matcher = new FieldPresenceConditionMatcher();
        } else if (condition instanceof FieldValueCondition) {
            matcher = new FieldValueConditionMatcher();
        }else if(condition instanceof BasicCondition){
            matcher = new BasicConditionMatcher();
        }else if(condition instanceof ValueTypeCondition){
            matcher = new ValueTypeConditionMatcher();
        }else if(condition instanceof OperationCondition){
            matcher = new OperationConditionMatcher();
        } else if(condition instanceof WithinFuzzySetsCondition) {
            matcher = new WithinFuzzySetsConditionMatcher();
        } else if(condition instanceof KnownCondition) {
            matcher = new KnownConditionMatcher();
        } else if(condition instanceof UnknownCondition) {
            matcher = new UnknownConditionMatcher();
        } else if(condition instanceof IdCondition) {
            matcher = new IdConditionMatcher();
        } else if(condition instanceof FuzzyOperatorCondition) {
            matcher = new FuzzyOperatorConditionMatcher();
        } else if(condition instanceof IfFailsCondition) {
            matcher = new IfFailsConditionMatcher();
        } else if(condition instanceof TreeCondition){
            matcher = new TreeConditionMatcher();
        }

        return matcher;

    }

}
