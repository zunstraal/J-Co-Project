package net.fm.geco.engine.parser.utils.model;

import java.util.List;
import java.util.ListIterator;

public class FieldsStructureTree {

	private FieldsStructureNode root;
	/* Key contiene il nome del campo più esterno */
	private String key;

	/**
	 * La chiave è il field di partenza, viene inserito qui con lo scopo di
	 * rendere più facile la ricerca di un albero che contiene il campo base
	 * comune che poi si deve modificare
	 *
	 **/
	public FieldsStructureTree(String key) {

		this.root = new FieldsStructureNode(key);
		this.key = key;

	}

	public String getKey() {

		return key;
	}

	public FieldsStructureNode getRoot() {
		return root;

	}

	/**
	 *
	 * Metodo che accetta la lista (di stringhe) di FIELDS date dal parser e il
	 * FIELDREFERENCE (dato dalla concatenazione di tutti i field) e che
	 * modifica l'albero corrente (sui cui viene lanciato il metodo) a seconda
	 * di quello che gli è arrivato
	 *
	 * Se questo metodo viene lanciato si sa solo che la chiave dell'albero
	 * corrente è pari al fieldList.get(0) (dato dal parser) Chi si occupa di
	 * trovare questo albero (se esiste già) o di crearne uno nuovo è la classe
	 * OutputFieldsModel
	 *
	 **/
	public void FieldList2Tree(List<String> fieldList, String fieldReference) {

		/*
		 * Si controlla ancora (non fa mai male fare un check in più) che sia stato
		 * lanciato il metodo sull' albero che ha come radice lo stesso primo
		 * campo base, ovvero il fieldList.get(0)
		 */
		if (!fieldList.get(0).equals(key)) {
			throw new RuntimeException("Incompatible data for the conversion");

		} else {

			/*
			 * ------- Da qui in poi comincia l'algoritmo di modifica
			 * dell'albero ------
			 */

			/*
			 * Se il campo che è arrivato è unico (esempio ".occhio") si sa che
			 * nell'albero di chiave ".occhio" deve starci solo questo campo.
			 * Per questo, se ci fossero altri campi, si sovrascrive la radice
			 * direttamente con questo campo.
			 *
			 * Esempio di sovrascrittura:
			 *
			 * 1) Dopo un primo passaggio si ha un albero con chiave ".occhio"
			 * che rappresenta ".occhio.malocchio.a"
			 * 2) Arriva ".occhio"
			 * 3) OutputFieldsModel cerca e trova un albero con chiave ".occhio"
			 * 4) Viene lanciato questo metodo all'albero con questa chiave
			 * passandogli appunto come fieldList il ".occhio"
			 * 5) A questo punto, vedendo che fieldList.size() è pari a 1, si sovrascrive la
			 * radice (che diventa nodo foglia) proprio con solo ".occhio" così
			 * si possono sovrascrivere tutti gli annidamenti figli che non
			 * sarebbero più necessari dal momento che si vuole ".occhio" (che
			 * include anche ".occhio.malocchio.a")
			 *
			 */
			if (fieldList.size() == 1) {
				this.root = new FieldsStructureNode(key, fieldReference);

			} else {

				/*
				 * Caso duale rispetto a prima: Prima si controlla che
				 * l'elemento radice dell'albero con la stessa chiave base non
				 * sia foglia: nel caso lo fosse sarebbe inutile proseguire
				 * perchè in automatico si avrebbero tutti gli elementi a
				 * partire dalla radice. Esempio:
				 *
				 * Ho l'albero: ".occhio"
				 *
				 * e arriva: ".occhio.malocchio.a"
				 *
				 * Non bisogna proseguire perchè avendo già ".occhio" includo
				 * automaticamente tutto quello che c'è all'interno per cui non
				 * avrebbe senso sovrascrivere ".occhio" con ".occhio.malocchio"
				 *
				 * Indice viene usato un indice per sapere a che punto della
				 * lista si è arrivati e per arrivare al caso base ovvero quello
				 * in cui l'indice è arrivato alla dimensione della fieldList
				 */

				if (!this.root.isLeaf())
					FieldList2Tree(fieldList, root, fieldReference, 1);

			}

		}

	}

	private void FieldList2Tree(List<String> fieldList, FieldsStructureNode actualNode, String fieldReference,
			int index) {

		/* Da qui parte la parte ricorsiva */
		/*
		 * Si hanno
		 * - un nodo che, una volta assegnato correttamente, verrà
		 * passato al metodo stesso per implementare la ricorsione
		 * - un booleano che indica se un nodo è foglia
		 * - un booleano che indica se è stato trovato un certo nodo
		 * - l'iteratore per iterare sui nodi figli
		 * - un nodo temporaneo di appoggio
		 *
		 */
		FieldsStructureNode node = null;
		boolean foundLeaf = false;
		boolean found = false;
		ListIterator<FieldsStructureNode> litr;
		FieldsStructureNode tempNode;

		/*
		 * CASO BASE: Si è arrivati all'ultimo elemento dell'array di campi e si
		 * deve salvare il fieldReference. Bisogna fare una serie di controlli
		 *
		 */

		if (index == fieldList.size() - 1) {

			litr = actualNode.getChildren().listIterator();

			/*
			 * Si itera sui figli del nodo attuale, quello che, eventualmente,
			 * dovrà avere come figlio il fieldReference corrente
			 */

			while (litr.hasNext()) {

				tempNode = litr.next();

				/*
				 * Se esiste già un nodo (interno o foglia) che si chiama allo
				 * stesso modo preleva questo nodo e setta i due flag nel modo
				 * definitio poi esci dal ciclo
				 */
				if (tempNode.getField().equals(fieldList.get(index).substring(1, fieldList.get(index).length()))) {
					node = tempNode;
					found = true;
					foundLeaf = node.isLeaf();
					break;
				}

			}

			/*
			 * Se il nodo trovato non è foglia allora va sostituito, quindi
			 * prima rimosso e poi riaggiunto Esempio:
			 *
			 * 1) L'albero aveva ".occhio.malocchio.a"
			 * 2) Arriva ".occhio.malocchio"
			 * 3) Si arriva quindi ad accedere, nell'albero
			 * del primo passo, al nodo ".malocchio"
			 * 4) Sapendo però che il nuovo ".malocchio" deve diventare
			 * foglia (si è qui nel CASO BASEinfatti) e vedendo che quello esistente non lo
			 * è lo si rimpiazza completamente sovrascrivendolo
			 */
			if (found && !foundLeaf) {
				actualNode.getChildren().remove(node);
				actualNode.addChild(new FieldsStructureNode(fieldList.get(index), fieldReference));
			}

			/*
			 * Per esclusione dei casi precedenti, se non viene trovato nessun
			 * nodo uguale si aggiunge e basta quello nuovo, altrimenti non si
			 * aggiunge perchè esiste già ed è foglia
			 */

			if (!found )
				actualNode.addChild(new FieldsStructureNode(fieldList.get(index), fieldReference));

		} else {

			/*
			 * CASO NON BASE, si sta lavorando su un field che è interno (non è
			 * l'ultimo)
			 */
			litr = actualNode.getChildren().listIterator();

			/* Si itera sui figli del nodo corrente */
			while (litr.hasNext()) {

				tempNode = litr.next();

				/*
				 * ------ Qui è dove si decide il "percorso giusto" se i campi annidati esistono già --------
				 */

				/*
				 * Se viene trovato un nodo con field pari allo stesso field che
				 * si sta analizzando si settano in modo opportuno i flag e il
				 * nodo, dopodichè si esce dal ciclo
				 *
				 */
				if (tempNode.getField().equals(fieldList.get(index).substring(1, fieldList.get(index).length()))) {
					node = tempNode;
					found = true;
					foundLeaf = node.isLeaf();
					break;
				}

			}

			/*
			 * se non ha trovato un nodo equivalente al campo che si sta
			 * analizzando, si prosegue per per "la nuova strada", aggiungendo
			 * semplicemente il campo corrente come figlio del nodo corrente
			 */
			if (!found)
				node = actualNode.addChild(new FieldsStructureNode(fieldList.get(index)));

			/*
			 * Altrimenti vuol dire che è stato trovato un nodo che ha lo stesso
			 * campo. Ci sono però due casi:
			 */

			/*
			 * Nel caso abbia trovato un nodo foglia non deve proseguire perchè
			 * tanto verrebbe sovrascritto!!
			 *
			 * Esempio:
			 *
			 * 1) L'albero ha occhio.malocchio
			 * 2) Inserisco occhio.malocchio.a
			 *
			 * Non bisogna in questo caso continuare con l'inserimento di ".a"
			 * perchè ".malocchio" sovrascrive tutto quello che c'è dopo. E' a
			 * questo che serve il flag foundLeaf
			 */
			if (!foundLeaf)
				FieldList2Tree(fieldList, node, fieldReference, index + 1);

			/*
			 * Ricordo che quest'ultimo node può essere:
			 *
			 * - un nodo già esistente (con lo stesso field) e prelevato dalla
			 * lista di figli su cui si continua (node = tempNode)
			 *
			 * - un nodo nuovo creato come figlio del nodo corrente dell'albero
			 * visto che non ne è stato trovato nessun altro con lo stesso field
			 * (node = actualNode.addChild(...))
			 *
			 */
		}

	}

	public String printTree() {

		return printTree(this.root, 0);
	}



	private String printTree(FieldsStructureNode actualNode, int level) {
		String st = "";

		for (int i = 0; i < level; i++) {
			st += "\t";
		}
		
		st += actualNode.getField();
		if (!actualNode.isLeaf()) {

			for (FieldsStructureNode child : actualNode.getChildren()) {
				st += printTree(child, level + 1);
			}
		}
		return st;
	}

}
