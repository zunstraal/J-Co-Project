package net.fm.geco.engine.executor;

import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.byZun.ZunWarningTracker;
import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.executor.utils.SynchronizedDuplicateRemover;
import net.fm.geco.engine.executor.utils.SynchronizedJoinCycle;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.JoinCommand;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;

@Executor(JoinCommand.class)
public class JoinExecutor implements IExecutor<JoinCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public JoinExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}

	@Override
	public void execute(Pipeline pipeline, JoinCommand command) throws ExecuteProcessException {
//		PF
		LinkedBlockingQueue<DocumentDefinition> queue = new LinkedBlockingQueue<DocumentDefinition>();
		SynchronizedDuplicateRemover sdr = new SynchronizedDuplicateRemover(queue, command.isRemoveDuplicates());
		sdr.start();
//		PF	end

		final SimpleDocumentCollection outCollection;
		final IDocumentCollection leftCollection;
		final IDocumentCollection rightCollection;

		IDatabase database;

		String dbNameLeft = command.getLeftCollection().getDatabaseName();
		String dbNameRight = command.getRightCollection().getDatabaseName();

		if(dbNameLeft!=null){

			database = databaseRegistry.getDatabase(dbNameLeft);
			if (database == null) {
				throw new ExecuteProcessException("[JOIN] Invalid database " + dbNameLeft);
			}
			leftCollection = database.getCollection(command.getLeftCollection().getCollectionName());

		}else{
			leftCollection = pipeline.getCollection(command.getLeftCollection().getCollectionName());

		}

		if(dbNameRight!=null){

			database = databaseRegistry.getDatabase(dbNameRight);
			if (database == null) {
				throw new ExecuteProcessException("[JOIN]: Invalid database " + dbNameRight);
			}
			rightCollection = database.getCollection(command.getRightCollection().getCollectionName());

		}else{
			rightCollection = pipeline.getCollection(command.getRightCollection().getCollectionName());

		}

		if(leftCollection != null && rightCollection != null) {
			List<DocumentDefinition> leftDocs = leftCollection.getDocument();
			List<DocumentDefinition> rightDocs = rightCollection.getDocument();

			sdr.setDimensions(leftDocs.size(), rightDocs.size());
			
			for (DocumentDefinition ld : leftDocs) {				
				// PF threads declaration
				SynchronizedJoinCycle[] threads;
				int nThreads = 1;
				//PF per il filter uso tutti i processori fisici meno uno
				if (Constants.getInstance().getNProcessors() > 1)
					nThreads = Constants.getInstance().getNProcessors()-1;

				// PF threads creation
				threads = new SynchronizedJoinCycle[nThreads];
				for (int i=0; i<nThreads; i++)
					threads[i] = new SynchronizedJoinCycle(i, nThreads, pipeline, ld, rightDocs, queue, command);

				// PF threads launching
				for (int i=0; i<nThreads; i++)
					threads[i].start();

				// PF thread synchro
				for (int i=0; i<nThreads; i++)
					try {
						threads[i].join();
					} catch (InterruptedException e) {
						throw new ExecuteProcessException("[JOIN]: Failed Thread Sychronization");
					}
			}
		}

		// GET the final collection and return it
		sdr.interrupt();
		try {
			sdr.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ExecuteProcessException("[FILTER]: Failed Remover Thread Sychronization");
		}
		List<DocumentDefinition> outDocs = sdr.getDocs();

		outCollection = new SimpleDocumentCollection("Join", outDocs);
		pipeline.addCollection(outCollection);
	}

}
