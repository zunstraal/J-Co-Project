package net.fm.geco.engine.matcher.join;


import org.locationtech.jts.geom.Geometry;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.value.GeoJsonValue;

public class IntersectJoinMatcher implements IMatcher {
	
	public IntersectJoinMatcher() {
		super();
	}

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {
		GeoJsonValue lgj = (GeoJsonValue) pipeline.get(Constants.LEFT_DOCUMENT_ALIAS);
		GeoJsonValue rgj = (GeoJsonValue) pipeline.get(Constants.RIGHT_DOCUMENT_ALIAS);
		
		Geometry lg = lgj.getGeometry();
		Geometry rg = rgj.getGeometry();

		return lg.intersects(rg);
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		return 0;
	}

}
