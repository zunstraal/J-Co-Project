package net.fm.geco.engine.parser.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import geco.model.util.Field;
import geco.model.util.GenerateAction;
import geco.model.util.GeometricOption;
import geco.model.util.ObjectStructure;
import geco.model.util.OutputFieldSpec;
import geco.model.util.Value;
import net.fm.geco.engine.parser.utils.model.FieldsStructureNode;
import net.fm.geco.engine.parser.utils.model.FieldsStructureTree;
import net.fm.geco.engine.parser.utils.model.OutputFieldsModel;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.GeometryDefinition;
import net.fm.geco.model.builder.DocumentDefinitionBuilder;
import net.fm.geco.model.command.EGeometryAction;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.SimpleValue;

public class GenerateCommandCreator {
	private GenerateCommand generateCommand;
	private GenerateAction generateAction;
	private GeometricOption geometricOption;
	private String alias;
	private DocumentDefinitionBuilder builder;
	boolean shift;

	public GenerateCommandCreator(GenerateAction generateAction, String alias) {
		if (alias.equals(""))
			throw new RuntimeException("Invalid alias name for this constructor");

		this.shift = false;
		this.generateCommand = null;
		this.generateAction = generateAction;
		this.builder = new DocumentDefinitionBuilder();
		this.geometricOption = null;
		this.alias = alias + ".";
		if (generateAction != null && generateAction.getGenerateActionType() != GenerateAction.UNDEFINED) {
			generateCommand = action2Command(generateAction);
		}
	}


	public GenerateCommandCreator(GenerateAction generateAction) {
		this.shift = true;
		this.generateCommand = null;
		this.generateAction = generateAction;
		this.alias = "";
		this.builder = new DocumentDefinitionBuilder();
		this.geometricOption = null;

		if (generateAction != null && generateAction.getGenerateActionType() != GenerateAction.UNDEFINED) {
			generateCommand = action2Command(generateAction);
		}
	}


	public GenerateCommand getGenerateCommand() {
		return this.generateCommand;
	}


	// EC: AGGIUNTE MODIFICHE PER LA PATH NOTATION
	private GenerateCommand action2Command(GenerateAction action) {
		DocumentDefinition doc = null;
		GenerateCommand cmd = null;

		if (action.objectStructure != null) {
			setDocumentBuilder(action.objectStructure);
			doc = builder.build();
		}

		geometricOption = generateAction.geometricOption;

		if (geometricOption != null) {
			if (geometricOption.getType() == GeometricOption.KEEPING) {
				cmd = new GenerateCommand(doc, EGeometryAction.KEEP, null);
			} else if (geometricOption.getType() == GeometricOption.DROPPING) {
				cmd = new GenerateCommand(doc, EGeometryAction.DROP, null);
			} else if (geometricOption.getType() == GeometricOption.UNDEFINED)  {
				cmd = new GenerateCommand(doc, EGeometryAction.KEEP, null);
			} else {
				GeometryDefinition geometryDefinition = setGeometryDefinition(geometricOption);
				cmd = new GenerateCommand(doc, EGeometryAction.GENERATE, geometryDefinition);
			}
		} else {
			cmd = new GenerateCommand(doc, EGeometryAction.KEEP, null);
		}

		return cmd;

	}

	// NUOVO EC Da lista di stringhe ad un' unica stringa
	private String toStringListField(List<String> s) {
		String result = "";

		for (int i = 0; i < s.size(); i++)
			result += s.get(i);

		return result;
	}

	// NUOVO EC
	private void setDocumentBuilder(ObjectStructure objectStructure) {
		List<OutputFieldSpec> outputFieldSpec = objectStructure.outputList;

		OutputFieldSpec def = null;

		// String = path del campo, escluso l'ultimo pezzo che � quello pi� in
		// profondit� (verr� memorizzato invece nell ObjectStructure)
		// ObjectStructure = struttura dati annidata che conterr� almeno un altro campo
		Map<String, ObjectStructure> localMap = new TreeMap<String, ObjectStructure>();
		// PF - added to track single elements
		Map<String, ObjectStructure> singleLocalMap = new TreeMap<String, ObjectStructure>();

		for (int i = 0; i < outputFieldSpec.size(); i++) {
			def = outputFieldSpec.get(i);

			// se path ha un unico campo, risolvo come nella versione vecchia
			if (def.fieldRef.fields.size() == 1) {
				ObjectStructure singleField = new ObjectStructure(def);
				setDocumentBuilderSingle(singleField);
				// PF - keep track of singles
				singleLocalMap.put(def.fieldRef.toString(), singleField);
			}

			else {
				/*
				 * due path ammissibili con stessa radice differiscono solo per l'ultima stringa
				 * del field ex: .a.b.c.d .a.b.c.e vanno bene e hanno in comune la stringa
				 * ".a.b.c"
				 *
				 */
				List<String> listField = def.fieldRef.fields;
				String lastField = listField.get(listField.size() - 1);
				listField.remove(listField.size() - 1);

				// Controllo se esiste gi� o meno uno oggetto con lo stesso path
				// controllare se � necessaria o meno il ciclo for ????
				Boolean found = false;
				for (int j = 0; j < localMap.size(); j++) {
					if (localMap.containsKey(toStringListField(listField))) {
						found = true;
						break;
					}
				}

				// se ho trovato una radice gi� esistente, aggiorno e aggiungo la struttura dati
				// a cui fa riferimento
				if (found) {
					Field fTemp = new Field();
					fTemp.addField(lastField);
					OutputFieldSpec Otemp = new OutputFieldSpec(fTemp);

					if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF)
						Otemp.setFieldSpec(def.valueField);
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_CONSTANT)
						Otemp.setFieldSpec(def.value);
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_OBJECT_STRUCTURE)
						Otemp.setFieldSpec(def.valueObjectStructure);
// PF - check if it is useful .... pare che tutto questa parte non serva a nulla...
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_ROOTABLE_OBJECT_STRUCTURE) {
						Otemp.setFieldSpec(def.valueField);
					}
// PF - ELSE added to handle COUNT case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_COUNT_FIELD_REF) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_STRING case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_STRING) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_INT case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_INT) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);					
					}
// PF - ELSE added to handle TO_FLOAT case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_FLOAT) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_BOOL case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_BOOL) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_SERIALIZE case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_SERIALIZE_FIELD_REF) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TRANSLATE case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_TRANSLATE) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}

					ObjectStructure objTemp = localMap.get(toStringListField(listField));
					objTemp.addOutputFieldSpec(Otemp);

					localMap.replace(toStringListField(listField), objTemp);

				} 
				else {
					Field fTemp = new Field();
					fTemp.addField(lastField);
					OutputFieldSpec Otemp = new OutputFieldSpec(fTemp);

					if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF)
						Otemp.setFieldSpec(def.valueField);
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_CONSTANT)
						Otemp.setFieldSpec(def.value);
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_OBJECT_STRUCTURE)
						Otemp.setFieldSpec(def.valueObjectStructure);
// PF - verify if it is useful ... pare che non serva a nulla
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_ROOTABLE_OBJECT_STRUCTURE) {
						Otemp.setFieldSpec(def.valueField);
					}
// PF - ELSE added to handle COUNT case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_COUNT_FIELD_REF) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_STRING case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_STRING) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_INT case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_INT) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);					
					}
// PF - ELSE added to handle TO_FLOAT case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_FLOAT) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_BOOL case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_BOOL) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TO_SERIALIZE case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_SERIALIZE_FIELD_REF) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}
// PF - ELSE added to handle TRANSLATE case
					else if (def.getOutputFieldSpecType() == OutputFieldSpec.VALUE_TRANSLATE) {
						Otemp.setFieldSpec(def.builInFunctionFieldRef);
					}

					ObjectStructure objTemp = new ObjectStructure(Otemp);

// PF - added to handle Rootable singles
					ObjectStructure oldObj;
					if (	((oldObj = singleLocalMap.get(toStringListField(listField))) != null) &&
							(	(oldObj.outputList.get(0).getOutputFieldSpecType() == OutputFieldSpec.VALUE_OBJECT_STRUCTURE) ||
								(oldObj.outputList.get(0).getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF))) {
						Field fr = new Field();
						// PF - TODO - field name doesn't care, we care it is Rootable!
						fr.addField(".#####../" + toStringListField(listField).substring(1));
						oldObj.outputList.get(0).fieldRef = fr;
						oldObj.outputList.get(0).setObjectStructureRootable();
						objTemp.addOutputFieldSpec(oldObj.outputList.get(0));
					}
// PF END

					localMap.put(toStringListField(listField), objTemp);
				}
			}
		}

		// dopo aver analizzato tutti i parametri passati alla generate e creato le
		// eventuali sottostruttre dati, le analizzo una ad una
		for (Map.Entry<String, ObjectStructure> entry : localMap.entrySet()) {
			// devo convertire la stringa contenuta nel Map in una lista di stringhe. Il
			// costruttore del Field necessita della lista e non della singola stringa

			List<String> listFieldFromMap = new ArrayList<>();

			String key = entry.getKey(); // .a.b.c.d
			String[] fieldArray = key.split("\\."); // abcd

			// elimino la prima cella perche contiene la stringa vuota
			String[] fieldArray2 = Arrays.copyOfRange(fieldArray, 1, fieldArray.length);

			for (String s : fieldArray2) {
				listFieldFromMap.add("." + s); // .a.b.c.d
			}

			Field ffTemp = new Field();
			ffTemp.fields = listFieldFromMap;
			OutputFieldSpec o1 = new OutputFieldSpec(ffTemp);
			o1.setFieldSpec(entry.getValue());
			ObjectStructure finalObj = new ObjectStructure(o1);

			setDocumentBuilderSingle(finalObj);
		}

	}


	private void setDocumentBuilderSingle(ObjectStructure objectStructure) {
		List<OutputFieldSpec> outputFieldSpec = objectStructure.outputList;

		OutputFieldsModel ofm = new OutputFieldsModel(objectStructure, shift);

		OutputFieldSpec ofdDef;

		/* Trattazione di tutti gli elementi creati nel OutputFieldsModel */

		List<FieldsStructureTree> treeList = ofm.getTreeList();

		if (!treeList.isEmpty()) {
			for (int i = 0; i < treeList.size(); i++) {
				FieldsStructureNode root = treeList.get(i).getRoot();
				setBuilder(root);
			}

		}

		for (int i = 0; i < outputFieldSpec.size(); i++) {
			ofdDef = outputFieldSpec.get(i);

			// EC NUOVO CONDIZIONE IF
			if (ofdDef.fieldRef.fields.size() > 1) {
				this.builder = this.builder.withField().fromDocument(ofdDef.fieldRef);
				OutputFieldSpec outputFieldSpecTemp = ofdDef;
				outputFieldSpecTemp.fieldRef.fields.remove(0);
				ObjectStructure objectStructureTemp = new ObjectStructure(outputFieldSpecTemp);
				setDocumentBuilderSingle(objectStructureTemp);
				this.builder = this.builder.buildField().add();
			}

			// sostituito il paramentro String id con FieldRef
			else {

				if (ofdDef.getOutputFieldSpecType() ==  OutputFieldSpec.VALUE_FIELD_REF) {
					this.builder.withField();  // PF - what's for???
					this.builder = this.builder.withField().fromFieldReference(ofdDef.fieldRef, new FieldReference(alias + ofdDef.valueField.toString().substring(1))).add();
				} 
				else if (ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_MEMBERSHIP_OF) {
					this.builder.withField();  // PF - what's for???
					this.builder = this.builder.withField().fromFieldReference(ofdDef.fieldRef, new FieldReference(alias + ofdDef.getFuzzyset().substring(1))).add();
				} 
				else if (ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_ROOTABLE_OBJECT_STRUCTURE) {
					this.builder.withField();  // PF - what's for???
					this.builder = this.builder.withField().fromRootableFieldReference(ofdDef.fieldRef, new FieldReference(alias + ofdDef.valueField.toString().substring(1))).add();
				} 
				else if (ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_CONSTANT) {
					this.builder.withField().fromValue(ofdDef.fieldRef, evaluateValue(ofdDef.value)).add();
				} 
				else if (ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_OBJECT_STRUCTURE) {
					this.builder = this.builder.withField().fromDocument(ofdDef.fieldRef);
					setDocumentBuilder(ofdDef.valueObjectStructure);
					this.builder = this.builder.buildField().add();
				} 
				// PF - Next Elses to handle built-in functions
				else if (ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_COUNT_FIELD_REF 		||
						 ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_INT		|| 
						 ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_FLOAT	||
						 ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_STRING	||
						 ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_FIELD_REF_TO_BOOL	||
						 ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_SERIALIZE_FIELD_REF	) 	{
					Field f = ofdDef.fieldRef;
					FieldReference fr = new FieldReference(alias + ofdDef.builInFunctionFieldRef.toString().substring(1));
					int ofsType = ofdDef.getOutputFieldSpecType();
					this.builder = this.builder.withField().fromBuiltInFunctionFieldReference(f, fr, ofsType).add();
				}
				// PF - Next Elses to handle built-in functions
				else if (ofdDef.getOutputFieldSpecType() == OutputFieldSpec.VALUE_TRANSLATE) {
					Field f = ofdDef.fieldRef;
					FieldReference fr = new FieldReference(alias + ofdDef.builInFunctionFieldRef.toString().substring(1));
					int ofsType = ofdDef.getOutputFieldSpecType();
					this.builder = this.builder.withField().fromBuiltInFunctionFieldReference(f, fr, ofsType, ofdDef.getDictionary(), ofdDef.isCaseSensitive(), ofdDef.getDefaultTranslation()).add();
				}
			}
		} // Fine for

	}


	private void setBuilder(FieldsStructureNode node) {
		if (node.isLeaf()) {
			this.builder = this.builder.withField().fromFieldReference(node.getField(),
					new FieldReference(alias + node.getFieldReference().substring(1))).add();

		} else {

			this.builder = this.builder.withField().fromDocument(node.getField());

			for (FieldsStructureNode actualNode : node.getChildren()) {
				setBuilder(actualNode);
			}

			this.builder = this.builder.buildField().add();

		}

	}

	private GeometryDefinition setGeometryDefinition(GeometricOption geometricOption) {

		GeometryDefinition geometryDef = null;

		if (geometricOption.getType() == GeometricOption.FIELD_REF) {

			FieldReference source = new FieldReference(alias + geometricOption.fieldRef.toString().substring(1));
			geometryDef = new GeometryDefinition(source, 2);

		} else if (geometricOption.getType() == GeometricOption.POINT) {

			FieldReference latitude;
			FieldReference longitude;

			latitude = new FieldReference(alias + geometricOption.latitude.toString().substring(1));
			longitude = new FieldReference(alias + geometricOption.longitude.toString().substring(1));

			geometryDef = new GeometryDefinition(latitude, longitude);

		} else if (geometricOption.getType() == GeometricOption.AGGREGATE) {

			geometryDef = new GeometryDefinition(
					new FieldReference(alias + geometricOption.aggregate.toString().substring(1)), 1);

		} else if (geometricOption.getType() == GeometricOption.TO_POLYLINE) {

			geometryDef = new GeometryDefinition(
					new FieldReference(alias + geometricOption.fieldRef.toString().substring(1)), 3);
		}

		return geometryDef;

	}

	private SimpleValue evaluateValue(Value v) {
		SimpleValue sv = null;

		// Int
		if (v.type == Value.INT) {
			sv = new SimpleValue(Integer.parseInt(v.value));
		}
		// float
		if (v.type == Value.FLOAT) {
			sv = new SimpleValue(Double.parseDouble(v.value));
		}
		// string
		if (v.type == Value.QUOTED) {
			String s = v.value.substring(1, v.value.length() - 1);
			sv = new SimpleValue(s);
			// boolean
		}
		if (v.type == Value.BOOLEAN) {

			if (v.value.equals("TRUE"))
				sv = new SimpleValue(true);
			else if (v.value.equals("FALSE"))
				sv = new SimpleValue(false);
		}

		return sv;
	}

}