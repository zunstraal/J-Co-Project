package net.fm.geco.engine.evaluator;

import javax.script.ScriptException;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.join.AreaJoinConditionMatcher;
import net.fm.geco.engine.matcher.join.DistanceJoinMatcher;
import net.fm.geco.engine.matcher.join.IncludedJoinMatcher;
import net.fm.geco.engine.matcher.join.IntersectJoinMatcher;
import net.fm.geco.engine.matcher.join.MeetJoinMatcher;
import net.fm.geco.engine.matcher.join.OrientationJoinConditionMatcher;
import net.fm.geco.model.condition.join.AreaJoinCondition;
import net.fm.geco.model.condition.join.DistanceJoinCondition;
import net.fm.geco.model.condition.join.IncludedJoinCondition;
import net.fm.geco.model.condition.join.IntersectJoinCondition;
import net.fm.geco.model.condition.join.JoinCondition;
import net.fm.geco.model.condition.join.MeetJoinCondition;
import net.fm.geco.model.condition.join.OrientationJoinCondition;
import net.fm.geco.model.value.GeoJsonValue;

public class JoinConditionEvaluator {
	
	private final JoinCondition joinCondition;
	private final IMatcher joinMatcher;
	
	public JoinConditionEvaluator(JoinCondition joinCondition) {
		super();
		this.joinCondition = joinCondition;
		this.joinMatcher = getJoinMatcher(joinCondition);
	}
	
	//l'evaluate aggiunge alla pipeline le due geometrie
	// sarà poi il matcher a verificare se matchano (e.g on distance)
	public boolean evaluate(GeoJsonValue d1, GeoJsonValue d2) throws ScriptException {
		final Pipeline pipeline = new Pipeline();
		pipeline.add(d1, Constants.LEFT_DOCUMENT_ALIAS);
		pipeline.add(d2, Constants.RIGHT_DOCUMENT_ALIAS);

		if(joinCondition!= null) {
			return joinMatcher.matches(joinCondition, pipeline);
		} else {
			return true;
		}
	}

	private IMatcher getJoinMatcher(JoinCondition joinCondition) {
		IMatcher matcher = null;
		if(joinCondition instanceof IntersectJoinCondition) {
			matcher = new IntersectJoinMatcher();	
		} else if(joinCondition instanceof AreaJoinCondition) {
			matcher = new AreaJoinConditionMatcher();
		} else if(joinCondition instanceof DistanceJoinCondition) {
			matcher = new DistanceJoinMatcher();
		} else if(joinCondition instanceof IncludedJoinCondition) {
			matcher = new IncludedJoinMatcher();
		} else if(joinCondition instanceof MeetJoinCondition) {
			matcher = new MeetJoinMatcher();
		} else if(joinCondition instanceof OrientationJoinCondition) {
			matcher = new OrientationJoinConditionMatcher();
		}
		return matcher;
	}

}
