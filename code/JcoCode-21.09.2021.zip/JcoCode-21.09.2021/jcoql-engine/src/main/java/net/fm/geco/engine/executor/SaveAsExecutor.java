package net.fm.geco.engine.executor;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;

//import net.fm.geco.engine.IDatabase;
//import net.fm.geco.engine.IDocumentCollection;
import net.fm.geco.engine.Pipeline;
//import net.fm.geco.engine.SimpleDocumentCollection;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.json.JSONHandler;
import net.fm.geco.engine.mongodb.utils.DocumentUtils;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.SaveAsCommand;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;

@Executor(SaveAsCommand.class)
public class SaveAsExecutor implements IExecutor<SaveAsCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public SaveAsExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}


	@Override
	public void execute(Pipeline pipeline, SaveAsCommand command) throws ExecuteProcessException {
		IDocumentCollection outCollection = null;
		IDocumentCollection collection = pipeline.getCurrentCollection();

		if(collection == null) {
			//PF
	    	String outSt = "{ }";
	    	List<DocumentDefinition> list = new ArrayList<>();
			Document bson = Document.parse(outSt);
			list.add(DocumentUtils.mapDocumentDefinitionFromBson(bson));
			outCollection = new SimpleDocumentCollection(command.getCollectionName(), list);
		} 
		else {
			outCollection = new SimpleDocumentCollection(command.getCollectionName(), collection.getDocument());
		}

		if (command.getDbName() != null) {
			IDatabase database = databaseRegistry.getDatabase(command.getDbName());
			database.addCollection(outCollection);			
			
		} 
		// PF. Extends SAVE AS to run as SET INTERMEDIATE
		else {
			JSONHandler j = new JSONHandler();
			String fileName = j.createFile(outCollection, command.getCollectionName());
			pipeline.addFiles(command.getCollectionName(), fileName);			
		}
			
		pipeline.addCollection(outCollection);

	}

}
