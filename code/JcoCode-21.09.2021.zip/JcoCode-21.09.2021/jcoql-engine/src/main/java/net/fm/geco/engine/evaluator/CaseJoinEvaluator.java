package net.fm.geco.engine.evaluator;

import java.util.ArrayList;
import java.util.List;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.FieldPresenceConditionMatcher;
import net.fm.geco.engine.matcher.FieldValueConditionMatcher;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.TreeConditionMatcher;
import net.fm.geco.model.Case;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.builder.DocumentDefinitionBuilder;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.FieldValueCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.WhereCondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.value.DocumentValue;

//PF. TODO - 10.07.2021 - VALUTARE SE ELIMINARE QUESTA CLASSE DOPO AVER RISTRUTTURATO IL JOIN
public class CaseJoinEvaluator {

	public List<DocumentDefinition> evaluate(Pipeline pipeline, Case caseFilter, List<String> alias) throws ScriptException {
		//DocumentDefinition outDoc = null;
		List<DocumentDefinition> outDocs = new ArrayList<>(2);

		for (WhereCondition whereCondition : caseFilter.getWhereConditions()) {
//			ZunWarningTracker.getInstance().addWarning("JOIN WHERE CONDITIONS:\n" +whereCondition.toString());

			if (checkConditions(whereCondition, pipeline)) {
				GenerateCommand generate = whereCondition.getGenerate();
				if (generate != null) {
					GenerateCommandEvaluator evaluator = new GenerateCommandEvaluator();
					outDocs.add(evaluator.evaluate(pipeline, generate));

				} else {

					int size;

					if (alias == null)
						size = 1;
					else
						size = alias.size();

					if (size == 1) {

						final Object currentObj = pipeline.get(pipeline.getCurrentCollectionName());
						if (currentObj instanceof DocumentDefinition) {
							outDocs.add((DocumentDefinition) currentObj);
						} else {

							outDocs.add(pipeline.getAsDocument());
						}

					} else if (size == 2) {

						final Object leftObj = pipeline.get(alias.get(0));
						DocumentDefinition ld;
						if (leftObj instanceof DocumentDefinition) {
							ld = (DocumentDefinition) leftObj;
						} else {
							ld = pipeline.getAsDocument();
						}

						final Object rightObj = pipeline.get(alias.get(1));
						DocumentDefinition rd;
						if (rightObj instanceof DocumentDefinition) {
							rd = (DocumentDefinition) rightObj;
						} else {
							rd = pipeline.getAsDocument();
						}

						outDocs.add(DocumentDefinitionBuilder.create().withField()
								.fromDocument(alias.get(0), new DocumentValue(ld)).add().withField()
								.fromDocument(alias.get(1), new DocumentValue(rd)).add().build());

					} else
						throw new RuntimeException("More than two objects found in the pipeline");

				}

			} else if (caseFilter.isKeepOthers()) {
				int size;

				if (alias == null)
					size = 1;
				else
					size = alias.size();

				if (size == 1) {

					final Object currentObj = pipeline.get(pipeline.getCurrentCollectionName());
					if (currentObj instanceof DocumentDefinition) {
						outDocs.add((DocumentDefinition) currentObj);
					} else {

						outDocs.add(pipeline.getAsDocument());
					}

				} else if (size == 2) {

					final Object leftObj = pipeline.get(alias.get(0));
					DocumentDefinition ld;
					if (leftObj instanceof DocumentDefinition) {
						ld = (DocumentDefinition) leftObj;
					} else {
						ld = pipeline.getAsDocument();
					}

					final Object rightObj = pipeline.get(alias.get(1));
					DocumentDefinition rd;
					if (rightObj instanceof DocumentDefinition) {
						rd = (DocumentDefinition) rightObj;
					} else {
						rd = pipeline.getAsDocument();
					}

					outDocs.add(ld);
					outDocs.add(rd);

				} else
					throw new RuntimeException("More than two objects found in the pipeline");
			}
		}
		return outDocs;
	}

	private boolean checkConditions(WhereCondition whereCondition, Pipeline pipeline) throws ScriptException {
		boolean withMatches = true;

		List<ICondition> withConditions = whereCondition.getConditions();
		if (withConditions != null) {
			for (ICondition c : withConditions) {
				IMatcher matcher = getMatcher(c);

				if (matcher != null && !matcher.matches(c, pipeline)) {
					withMatches = false;
				}
			}
		}
		return withMatches;
	}

	
	private IMatcher getMatcher(ICondition condition) {
		IMatcher matcher = null;

		if (condition instanceof FieldPresenceCondition) {
			matcher = new FieldPresenceConditionMatcher();
		} 
		else if (condition instanceof FieldValueCondition) {
			matcher = new FieldValueConditionMatcher();
		} 
		else if (condition instanceof TreeCondition) {
			matcher = new TreeConditionMatcher();
		}
		return matcher;
	}

}
