package net.fm.geco.engine.matcher;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.ValueTypeCondition;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.Value;

public class ValueTypeConditionMatcher implements IMatcher{

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {
		ValueTypeCondition c = (ValueTypeCondition) condition;
		
		if(c.getValue() instanceof FieldValue){
			
			FieldReference f = ((FieldValue)c.getValue()).getFieldReference();
			DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
			Value value = document.getValue(f.getFieldName());


			if(value!= null){
				
				if(c.getType() == EValueType.NUMBER){

					return (value.getType() == EValueType.DECIMAL) || (value.getType() == EValueType.INTEGER);
				} else if(c.getType() == EValueType.COMPLEX) {

					return (value.getType() == EValueType.ARRAY) || (value.getType() == EValueType.DOCUMENT) || (value.getType() == EValueType.GEOMETRY);
				} else if(c.getType() == EValueType.SIMPLE) {

					return (value.getType() == EValueType.NULL) || (value.getType() == EValueType.STRING
							|| (value.getType() == EValueType.BOOLEAN) || (value.getType() == EValueType.FIELD)
							|| (value.getType() == EValueType.INTEGER)|| (value.getType() == EValueType.DECIMAL));
				} else {
					return value.getType() == c.getType();
				}
			}else{

				return false;
			}
			
		}else {
			throw new RuntimeException("FieldValue not found");
		}
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		if(matches(condition, pipeline)) {
			return 1;
		} else {
			return 0;
		}
	}


}
