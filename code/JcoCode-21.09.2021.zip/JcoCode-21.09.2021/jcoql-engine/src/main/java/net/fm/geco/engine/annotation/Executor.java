package net.fm.geco.engine.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.springframework.stereotype.Component;

import net.fm.geco.model.command.ICommand;

@Component
@Retention(RetentionPolicy.RUNTIME)
public @interface Executor {
	Class<? extends ICommand> value();
	boolean overrideStandard() default false;
}
