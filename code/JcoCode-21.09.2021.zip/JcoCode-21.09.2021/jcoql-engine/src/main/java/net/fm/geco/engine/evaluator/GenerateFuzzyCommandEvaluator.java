package net.fm.geco.engine.evaluator;

import java.util.ArrayList;
import java.util.List;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.command.GenerateFuzzyCommand;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.SimpleValue;

public class GenerateFuzzyCommandEvaluator {

    public DocumentDefinition evaluate(Pipeline pipeline, GenerateFuzzyCommand generateFuzzy) {

        DocumentDefinition outDoc = null;

        DocumentDefinition fuzzyDoc;
        List<FieldDefinition> listFuzzySets;
        List<FieldDefinition> listFields;

        DocumentDefinition doc = pipeline.getAsDocument();

        if(doc.getValue("Generate Fuzzy") != null) {
            DocumentDefinition initialDoc = new DocumentDefinition(((DocumentValue) doc.getValue("Generate Fuzzy")).getFields());
            if (generateFuzzy.getFoUsingCond() != null) {

                FuzzyOperatorEvaluator foe = new FuzzyOperatorEvaluator();

                // calcolare il valore di membership
                SimpleValue membership = foe.evaluate(pipeline, generateFuzzy.getFoUsingCond());

                if (membership != null && !membership.getStringValue().equals("-1") && !membership.getStringValue().equals("2.0")) {
                    // se esiste già il campo ~fuzzysets
                    if (initialDoc.getValue(Constants.FUZZY_FIELD_NAME) != null) {
                        // aggiungo nuovo fuzzy set
                        fuzzyDoc = new DocumentDefinition(((DocumentValue) initialDoc.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
                        fuzzyDoc.addField(new FieldDefinition(generateFuzzy.getNameFuzzySet(), membership));
                        listFields = new ArrayList<>();
                        for (FieldDefinition notFuzzyObj : initialDoc.getFields()) {
                            if (!notFuzzyObj.getName().equals(Constants.FUZZY_FIELD_NAME)) {
                                listFields.add(notFuzzyObj);
                            }
                        }
                        outDoc = new DocumentDefinition(listFields);
                        outDoc.addField(new FieldDefinition(Constants.FUZZY_FIELD_NAME, new DocumentValue(fuzzyDoc)));
                        // verificare le condizioni di errore!!!!
                    } else if(membership.getStringValue().equals("-1.0") || membership.getStringValue().equals("2.0")) {
                        // se il valore è un valore di errore non aggiungo nulla al documento
                        outDoc = initialDoc;
                    } else {
                        // se non esiste il campo ~fuzzysets lo crea e aggiunge i nuovi fuzzy sets
                        listFuzzySets = new ArrayList<>();
                        listFuzzySets.add(new FieldDefinition(generateFuzzy.getNameFuzzySet(), membership));
                        DocumentValue docValue = new DocumentValue(listFuzzySets);
                        outDoc = initialDoc;
                        outDoc.addField(new FieldDefinition(Constants.FUZZY_FIELD_NAME, docValue));
                    }
                } else {
                    outDoc = initialDoc;
                }
            } else {
                outDoc = initialDoc;
            }
        }
        return outDoc;
    }
}
