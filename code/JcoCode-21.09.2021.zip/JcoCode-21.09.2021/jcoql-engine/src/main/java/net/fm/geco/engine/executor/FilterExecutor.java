package net.fm.geco.engine.executor;

import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import javax.script.ScriptException;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.executor.utils.SynchronizedDuplicateRemover;
import net.fm.geco.engine.executor.utils.SynchronizedFilterCycle;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.FilterCommand;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;


@Executor(FilterCommand.class)
public class FilterExecutor implements IExecutor<FilterCommand> {

	@Override
	public void execute(Pipeline pipeline, FilterCommand command) throws ExecuteProcessException, ScriptException {
		IDocumentCollection collection = pipeline.getCurrentCollection();

		LinkedBlockingQueue<DocumentDefinition> queue = new LinkedBlockingQueue<DocumentDefinition>();
		SynchronizedDuplicateRemover sdr = new SynchronizedDuplicateRemover(queue, command.isRemoveDuplicates());
		sdr.start();		
		sdr.setDimensions(collection.getDocument().size());
		sdr.setInfomer(collection.getDocument().size(), 20);

		// PF threads declaration
		SynchronizedFilterCycle[] threads;
		int nThreads = 1;
		//PF per il filter uso tutti i processori fisici meno uno
		if (Constants.getInstance().getNProcessors() > 1)
			nThreads = Constants.getInstance().getNProcessors()-1;
		nThreads=8;
		// PF threads creation
		threads = new SynchronizedFilterCycle[nThreads];
		for (int i=0; i<nThreads; i++)
			threads[i] = new SynchronizedFilterCycle(i, nThreads, pipeline, queue, command);

		// PF threads launching
		for (int i=0; i<nThreads; i++)
			threads[i].start();

		// PF thread synchro
		for (int i=0; i<nThreads; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
				throw new ExecuteProcessException("[FILTER]: Failed Thread Sychronization");
			}
		}
		
		// GET the final collection and return it
		sdr.interrupt();
		try {
			sdr.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ExecuteProcessException("[FILTER]: Failed Remover Thread Sychronization");
		}
		List<DocumentDefinition> outDocs = sdr.getDocs();

		SimpleDocumentCollection outCollection = new SimpleDocumentCollection("Filter", outDocs);
		pipeline.addCollection(outCollection);
		
	}
		
}