package net.fm.geco.engine.matcher;

import java.util.List;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.FieldValueCondition;
import net.fm.geco.model.condition.FuzzyOperatorCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.IdCondition;
import net.fm.geco.model.condition.IfFailsCondition;
import net.fm.geco.model.condition.KnownCondition;
import net.fm.geco.model.condition.UnknownCondition;
import net.fm.geco.model.condition.ValueTypeCondition;
import net.fm.geco.model.condition.WithinFuzzySetsCondition;
import net.fm.geco.model.condition.tree.EBooleanType;
import net.fm.geco.model.condition.tree.OperationCondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.condition.tree.TreeNode;

public class TreeConditionMatcher implements IMatcher {

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) throws ScriptException {
		TreeCondition tc = (TreeCondition) condition;
		return evaluate(tc.getRoot(), pipeline);
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) throws ScriptException {
		TreeCondition tc = (TreeCondition) condition;
		return fuzzyEvaluate(tc.getRoot(), pipeline);
	}

	private double fuzzyEvaluate(TreeNode node, Pipeline pipeline) throws ScriptException {
		double matches;

		if (node.getType() == EBooleanType.NULL) {
			matches = 0;
			List<ICondition> conditionList = node.getConditionList();
			for (ICondition condition : conditionList) {
				IMatcher matcher = getMatcher(condition);
				if (matcher != null) {
					matches = matcher.fuzzyMatches(condition, pipeline);
				}
			}
			return matches;

		} else if (node.getType() == EBooleanType.AND) {
			matches = 1;

			List<TreeNode> children = node.getChildren();

			for (TreeNode n : children) {
				if(matches > fuzzyEvaluate(n, pipeline)) {
					matches = fuzzyEvaluate(n, pipeline);
				}
			}
			return matches;

		} else if (node.getType() == EBooleanType.OR) {
			matches = 0;
			List<TreeNode> children = node.getChildren();
			for (TreeNode n : children) {
				if(matches < fuzzyEvaluate(n, pipeline)) {
					matches = fuzzyEvaluate(n, pipeline);
				}
			}
			return matches;

		} else if(node.getType() == EBooleanType.NOT) {
			matches = 0;
			List<TreeNode> children = node.getChildren();
			for (TreeNode n : children) {
				matches = fuzzyEvaluate(n, pipeline) * (-1) + 1;
			}
			return matches;

		} else {

			if(!evaluate(node.getChildAt(0), pipeline)) {
				return 1;
			} else {
				return 0;
			}
		}
	}

	private boolean evaluate(TreeNode node, Pipeline pipeline) throws ScriptException {

		boolean matches;

		if (node.getType() == EBooleanType.NULL) {
			matches = true;
			List<ICondition> conditionList = node.getConditionList();

			for (ICondition condition : conditionList) {
				IMatcher matcher = getMatcher(condition);
				if (matcher != null) {
					if (node.getConditionType() == TreeNode.UNDEFINED 
							|| node.getConditionType() == TreeNode.WITH
							|| node.getConditionType() == TreeNode.WITHIN 
							|| node.getConditionType() == TreeNode.KNOWN
							|| node.getConditionType() == TreeNode.ID) {
						if (!matcher.matches(condition, pipeline))
							matches = false;

					} else {
						if (matcher.matches(condition, pipeline))
							matches = false;
					}
				}
			}
			return matches;

		} else if (node.getType() == EBooleanType.AND) {
			matches = true;

			List<TreeNode> children = node.getChildren();

			for (TreeNode n : children) {

				if (!(evaluate(n, pipeline))) {
					matches = false;
				}

			}
			return matches;

		} else if (node.getType() == EBooleanType.OR) {
			matches = false;

			List<TreeNode> children = node.getChildren();

			for (TreeNode n : children) {

				if (evaluate(n, pipeline)) {
					matches = true;
				}
			}
			return matches;

		} else if(node.getType() == EBooleanType.NOT) {

			matches = false;

			List<TreeNode> children = node.getChildren();

			for (TreeNode n : children) {

				if (evaluate(n, pipeline)) {
					matches = false;
				} else {
					matches = true;
				}
			}
			return matches;
		} else {

			return !evaluate(node.getChildAt(0),pipeline);
		}
	}

	private IMatcher getMatcher(ICondition condition) {
		IMatcher matcher = null;
		if (condition instanceof FieldPresenceCondition) {
			matcher = new FieldPresenceConditionMatcher();
		} else if (condition instanceof FieldValueCondition) {
			matcher = new FieldValueConditionMatcher();
		}else if(condition instanceof BasicCondition){
			matcher = new BasicConditionMatcher();
		}else if(condition instanceof ValueTypeCondition){
			matcher = new ValueTypeConditionMatcher();
		}else if(condition instanceof OperationCondition){
			matcher = new OperationConditionMatcher();
		} else if(condition instanceof WithinFuzzySetsCondition) {
			matcher = new WithinFuzzySetsConditionMatcher();
		} else if(condition instanceof KnownCondition) {
			matcher = new KnownConditionMatcher();
		} else if(condition instanceof UnknownCondition) {
			matcher = new UnknownConditionMatcher();
		} else if(condition instanceof IdCondition) {
			matcher = new IdConditionMatcher();
		} else if(condition instanceof FuzzyOperatorCondition) {
			matcher = new FuzzyOperatorConditionMatcher();
		} else if(condition instanceof IfFailsCondition) {
			matcher = new IfFailsConditionMatcher();
		}

		return matcher;

	}

}
