package net.fm.geco.engine.executor;

import java.util.List;
import java.util.StringJoiner;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

//import net.fm.geco.engine.IDocumentCollection;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.LogCommand;
import net.fm.geco.model.engine.IDocumentCollection;

@Executor(LogCommand.class)
public class LogCommandExecutor implements IExecutor<LogCommand> {
//	private final Logger logger = LoggerFactory.getLogger(LogCommandExecutor.class);

	@Override
	public void execute(Pipeline pipeline, LogCommand command) throws ExecuteProcessException {
		IDocumentCollection collection = pipeline.getCurrentCollection();
		if(collection != null) {
			List<DocumentDefinition> documents = collection.getDocument();
			if(documents != null) {
				StringJoiner joiner = new StringJoiner(",");
				for(DocumentDefinition document : documents) {
					joiner.add(document.toString());
				}
// PS LOGGER 	ripristinare? System.out.println(joiner.toString());
			}
		}
	}

}
