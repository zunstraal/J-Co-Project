package net.fm.geco.engine.executor.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import javax.script.ScriptException;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.evaluator.AddFieldsEvaluator;
import net.fm.geco.engine.evaluator.CaseEvaluator;
import net.fm.geco.engine.evaluator.GeometryEvaluator;
import net.fm.geco.engine.evaluator.JoinConditionEvaluator;
import net.fm.geco.engine.evaluator.SetFuzzySetsEvaluator;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.Case;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.NoFuzzyFunction;
import net.fm.geco.model.command.SpatialJoinCommand;
import net.fm.geco.model.operation.IGeometryOperation;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.GeoJsonValue;

public class SynchronizedSpatialJoinCycle extends Thread {

	private int id, nThreads;
	private DocumentDefinition ld;
	private ArrayList<DocumentDefinition> rightDocs;
	private LinkedBlockingQueue<DocumentDefinition> queue;
	private SpatialJoinCommand command;

	public SynchronizedSpatialJoinCycle(int id, int nThread, DocumentDefinition ld, List<DocumentDefinition> rightDocs,
										LinkedBlockingQueue<DocumentDefinition> queue, SpatialJoinCommand command) {
		this.id = id;
		this.nThreads = nThread;
		this.ld = ld;
		this.rightDocs = (ArrayList<DocumentDefinition>) rightDocs;
		this.queue = queue;
		this.command = command;
		setPriority(10);
	}

	
    @Override
    public void run() {
    	// fundamental
    	int i = id;   				

    	DocumentDefinition rd;    	
    	// PF. Spatial Join performed only if both docs has GEOMETRY_FIELD_NAME
    	while (ld.hasField(Constants.GEOMETRY_FIELD_NAME) && (i < rightDocs.size())) {
    		rd = rightDocs.get(i);

    		if (rd.hasField(Constants.GEOMETRY_FIELD_NAME)) {
				DocumentDefinition doc = performSpatialJoin (ld, rd, command); 
//				List<DocumentDefinition> evaluatedDocs = OLDperformSpatialJoin (ld, rd, command);
//				for(DocumentDefinition doc : evaluatedDocs) 
				if(doc != null) {
					try {
						queue.put(doc);
					} catch (InterruptedException e) {
						e.printStackTrace();
		            	throw new ExecuteProcessException("[SynchronizedSpatialJoinCycle]: terminated");
					}
				}
    		}
    		// fundamental
    		i += nThreads;  
    	}
    }


	private DocumentDefinition performSpatialJoin (DocumentDefinition ld, DocumentDefinition rd, SpatialJoinCommand command) {
		DocumentDefinition evaluatedDoc = null;
		GeoJsonValue lv = (GeoJsonValue) ld.getValue(Constants.GEOMETRY_FIELD_NAME);
		GeoJsonValue rv = (GeoJsonValue) rd.getValue(Constants.GEOMETRY_FIELD_NAME);

		final GeometryEvaluator geometryEvaluator = new GeometryEvaluator();
		final JoinConditionEvaluator joinConditionEvaluator = new JoinConditionEvaluator(command.getJoinCondition());

		Case caseFilter = command.getCaseFilter();


		try {
			if(joinConditionEvaluator.evaluate(lv, rv)) {
				List<FieldDefinition> addFieldsList = new ArrayList<>();
				List<FieldDefinition> fuzzySetList = new ArrayList<>();

				Pipeline docPipeline = new Pipeline();
				List<String> alias = new ArrayList<>();
				alias.add(command.getLeftCollection().getAlias());
				alias.add(command.getRightCollection().getAlias());
				docPipeline.add(ld, command.getLeftCollection().getAlias());
				docPipeline.add(rd, command.getRightCollection().getAlias());
				evaluatedDoc = docPipeline.getAsDocument();

				/* SET GEOMETRY */
				final IGeometryOperation geometryOperation = command.getGeometryOperation();
				if(geometryOperation != null) {
					GeoJsonValue outGeo = geometryEvaluator.evaluate(lv, rv, geometryOperation);
					evaluatedDoc.addField(FieldDefinition.create().fromGeoJson(Constants.GEOMETRY_FIELD_NAME, outGeo).build());
				}
				
				/* ADD FIELDS */
				if(command.getAddFieldsCommand() != null) {
					AddFieldsEvaluator addFieldsEvaluator = new AddFieldsEvaluator();
					for(NoFuzzyFunction nff : command.getAddFieldsCommand().getNonFuzzyFunction()) {
						addFieldsList.addAll (addFieldsEvaluator.evaluate(	evaluatedDoc, 
																			nff, 
																			command.getAddFieldsCommand().getFieldReferences().get(command.getAddFieldsCommand().getNonFuzzyFunction().indexOf(nff)), 
																			alias));
					}
					for (FieldDefinition f:addFieldsList) {
						evaluatedDoc.addField(f);
					}
				}
				
				// PF - Added on 16.07.2021
				/* SET FUZZY SETS */
				if(command.getSetFuzzySetsCommand() != null) {
					SetFuzzySetsEvaluator sfse = new SetFuzzySetsEvaluator();
					fuzzySetList.addAll(sfse.evaluate(ld, rd, command.getSetFuzzySetsCommand()));
					if (fuzzySetList.size() > 0) {
						evaluatedDoc.addField(new FieldDefinition("X_"+Constants.FUZZY_FIELD_NAME+"_X", new DocumentValue(new DocumentDefinition(fuzzySetList))));
					}
				}


				/* CASE WHERE*/
				if(caseFilter != null) {
					try {
						CaseEvaluator caseEvaluator = new CaseEvaluator();
						evaluatedDoc = caseEvaluator.evaluate(docPipeline, caseFilter);				
						evaluatedDoc.removeValue(FieldName.fromString(Constants.GEOMETRY_FIELD_NAME));
					} catch (ScriptException e) {
						e.printStackTrace();
		            	throw new ExecuteProcessException("[SynchronizedSpatianJoinCycle]: CASE terminated");
					}

				} 
			}
		} catch (ScriptException e) {
			e.printStackTrace();
        	throw new ExecuteProcessException("[SynchronizedSpatianJoinCycle]: CONDITION terminated");
		}				
		return evaluatedDoc;
	}


}
