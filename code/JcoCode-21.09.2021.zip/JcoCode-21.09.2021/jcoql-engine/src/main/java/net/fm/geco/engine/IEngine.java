package net.fm.geco.engine;

import java.util.List;

import javax.script.ScriptException;

import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.command.ICommand;

public interface IEngine {
	
	void execute(List<ICommand> commands) throws ExecuteProcessException, ScriptException;
	
	void execute(ICommand command) throws ExecuteProcessException, ScriptException;
}
