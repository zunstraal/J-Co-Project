package net.fm.geco.engine;

import java.util.Properties;


public class Constants {

	public static final String GEOMETRY_FIELD_NAME = "~geometry";
	public static final String FUZZY_FIELD_NAME = "~fuzzysets";
	public static final String LEFT_DOCUMENT_ALIAS = "left";
	public static final String RIGHT_DOCUMENT_ALIAS = "right";

	public static final String SETTINGS_CONFIG_PATH = "config";
	public static final String SETTINGS_CONFIG_FILE = "settings.properties";
	public static final String SETTINGS_N_PROCESSORS = "nProcessors";

	private Properties settings;
	private int nProcessors = 1;
	
	public Constants () {
		settings = null;
		nProcessors = 1;		
	}
    private static Constants only = new Constants();

    public static Constants getInstance() {
        return only;
    }
    public void setSettings(Properties settings) {
		this.settings = settings;
		if (settings.getProperty(Constants.SETTINGS_N_PROCESSORS) != null)
			this.nProcessors = Integer.parseInt(settings.getProperty(Constants.SETTINGS_N_PROCESSORS));

	}
    public int getNProcessors() {
    	return this.nProcessors;
    }
    public Properties getProperties() {
    	return this.settings;
    }
    
	
	

	
}
