package net.fm.geco.engine.executor;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.json.JSONHandler;
import net.fm.geco.model.command.SetIntermediateCommand;
import net.fm.geco.model.engine.IDocumentCollection;

@Executor(SetIntermediateCommand.class)
public class SetIntermediateExecutor implements IExecutor<SetIntermediateCommand> {

	@Override
	public void execute(Pipeline pipeline, SetIntermediateCommand command) throws ExecuteProcessException {


		IDocumentCollection collection = pipeline.getCurrentCollection();
		JSONHandler j = new JSONHandler();
		String fileName = j.createFile(collection, command.getCollectionName());

		//pipeline.setCurrentCollectionName(command.getCollectionName());
		pipeline.addFiles(command.getCollectionName(), fileName);
		pipeline.addCollection(command.getCollectionName(), fileName);
	}

}
