package net.fm.geco.engine.matcher.join;

import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.BasicConditionMatcher;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.join.AreaJoinCondition;
import net.fm.geco.model.expression.BasicExpression;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.SimpleValue;

/*Si può approssimare la terra come superficie piatta se i poligoni sono piccoli*/

public class AreaJoinConditionMatcher implements IMatcher {

	private static final double EARTH_RADIUS = 6371000;// metri

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {

		AreaJoinCondition c = (AreaJoinCondition) condition;
		BasicConditionMatcher bc = new BasicConditionMatcher();

		GeoJsonValue lgj = (GeoJsonValue) pipeline.get(Constants.LEFT_DOCUMENT_ALIAS);
		GeoJsonValue rgj = (GeoJsonValue) pipeline.get(Constants.RIGHT_DOCUMENT_ALIAS);

		Geometry lg = lgj.getGeometry();
		Geometry rg = rgj.getGeometry();

		Geometry temp = lg.intersection(rg);
		if (temp.getGeometryType().equals("Polygon") == false) {
			return false;
		} else {

			Coordinate[] coord = temp.getCoordinates();
			List<Point> locations = new ArrayList<>();

			for (Coordinate coordinate : coord) {
				locations.add(GeometryFactory.createPointFromInternalCoord(coordinate, lg.getCentroid()));
			}

			double area = calculateAreaOfPolygonOnEarthInSquareMeters(locations);

			switch (c.getUnit()) {

			case METERS:
				break;
			case MILES:
				area = area / 1609340;
				break;
			case KILOMETERS:
				area = area / 1000000;
				break;
			default:
				break;

			}

			return bc.matches(
					new BasicCondition(
							new BasicExpression(new SimpleValue(area), c.getOperator(), new SimpleValue(c.getArea()))),
					pipeline);
		}
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		return 0;
	}

	/*
	 * https://stackoverflow.com/questions/5416700/gps-area-in-android/16210785#
	 * 16210785
	 */

	public double calculateAreaOfPolygonOnEarthInSquareMeters(final List<Point> locations) {
		return calculateAreaOfPolygonOnSphereInSquareMeters(locations, EARTH_RADIUS);
	}

	private double calculateAreaOfPolygonOnSphereInSquareMeters(final List<Point> locations, final double radius) {
		if (locations.size() < 3) {
			return 0;
		}

		final double diameter = radius * 2;
		final double circumference = diameter * Math.PI;
		final List<Double> listY = new ArrayList<Double>();
		final List<Double> listX = new ArrayList<Double>();
		final List<Double> listArea = new ArrayList<Double>();

		// calcolo dei segmenti X e Y per ciascun punto
		final double latitudeRef = locations.get(0).getY();
		final double longitudeRef = locations.get(0).getX();
		for (int i = 1; i < locations.size(); i++) {
			final double latitude = locations.get(i).getY();
			final double longitude = locations.get(i).getX();

			listY.add(calculateYSegment(latitudeRef, latitude, circumference));
			listX.add(calculateXSegment(longitudeRef, longitude, latitude, circumference));
		}

		// calcolo delle aree dei triangolini
		for (int i = 1; i < listX.size(); i++) {
			final double x1 = listX.get(i - 1);
			final double y1 = listY.get(i - 1);
			final double x2 = listX.get(i);
			final double y2 = listY.get(i);
			listArea.add(calculateAreaInSquareMeters(x1, x2, y1, y2));

		}

		// somma delle aree dei triangolini
		double areasSum = 0;
		for (final Double area : listArea) {
			areasSum = areasSum + area;
		}

		// valore assoluto dell'area. Se l'aggiunta dei punti avviene in senso orario
		// sarebbe negativa infatti
		return Math.abs(areasSum);// Math.sqrt(areasSum * areasSum);
	}

	private static Double calculateAreaInSquareMeters(final double x1, final double x2, final double y1,
			final double y2) {
		return (y1 * x2 - x1 * y2) / 2;
	}

	private static double calculateYSegment(final double latitudeRef, final double latitude,
			final double circumference) {
		return (latitude - latitudeRef) * circumference / 360.0;
	}

	private static double calculateXSegment(final double longitudeRef, final double longitude, final double latitude,
			final double circumference) {
		return (longitude - longitudeRef) * circumference * Math.cos(Math.toRadians(latitude)) / 360.0;
	}

}
