package net.fm.geco.engine.evaluator;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.IfFailsConditionMatcher;
import net.fm.geco.engine.matcher.TreeConditionMatcher;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.IfFailsCondition;
import net.fm.geco.model.condition.WhereCondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.value.SimpleValue;


public class FuzzyOperatorEvaluator {

    public SimpleValue evaluate(Pipeline pipeline, WhereCondition condition) {

        // USING
        double value = -1.0;

        for (ICondition ic : condition.getConditions()) {

            IMatcher matcher = getMatcher(ic);
            try {
                value = matcher.fuzzyMatches(ic, pipeline);
            } catch (ScriptException e) {
                //e.printStackTrace();
            }
        }

        SimpleValue membership = null;
        if (value != -1.0 && value != 2.0) {
            membership = new SimpleValue(value);
        }

        return membership;

    }

    private IMatcher getMatcher(ICondition condition) {
        IMatcher matcher = null;
        if(condition instanceof TreeCondition){
            matcher = new TreeConditionMatcher();
        } else if(condition instanceof IfFailsCondition) {
            matcher = new IfFailsConditionMatcher();
        }
        return matcher;
    }
}
