package net.fm.geco.engine.executor.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import javax.script.ScriptException;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.evaluator.AddFieldsEvaluator;
import net.fm.geco.engine.evaluator.CaseEvaluator;
import net.fm.geco.engine.evaluator.SetFuzzySetsEvaluator;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.Case;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.NoFuzzyFunction;
import net.fm.geco.model.command.JoinCommand;
import net.fm.geco.model.value.DocumentValue;

public class SynchronizedJoinCycle extends Thread {

	private int id, nThreads;
	private DocumentDefinition ld;
	private ArrayList<DocumentDefinition> rightDocs;
	private LinkedBlockingQueue<DocumentDefinition> queue;
	private JoinCommand command;
	private Pipeline pipeline;

	public SynchronizedJoinCycle(int id, int nThreads, Pipeline pipeline, DocumentDefinition ld, List<DocumentDefinition> rightDocs,
										LinkedBlockingQueue<DocumentDefinition> queue, JoinCommand command) {
		this.id = id;
		this.nThreads = nThreads;
		this.ld = ld;
		this.rightDocs = (ArrayList<DocumentDefinition>) rightDocs;
		this.queue = queue;
		this.command = command;
		this.pipeline = pipeline;
		setPriority(10);
	}

	
    @Override
    public void run() {
    	// fundamental
    	int i = id;   				

    	DocumentDefinition rd;    	
    	while (i < rightDocs.size()) {
    		rd = rightDocs.get(i);

			DocumentDefinition doc = performJoin (ld, rd, command); 
//			List<DocumentDefinition> evaluatedDocs = performJoinOld (ld, rd, command); 			
//			for(DocumentDefinition doc : evaluatedDocs) 
			if(doc != null) {
				try {
					queue.put(doc);
				} catch (InterruptedException e) {
					e.printStackTrace();
	            	throw new ExecuteProcessException("[SynchronizedSpatialJoinCycle]: terminated");
				}
			}
    		// fundamental
    		i += nThreads;  
    	}
    }

    
	private DocumentDefinition performJoin (DocumentDefinition ld, DocumentDefinition rd, JoinCommand command) {
		DocumentDefinition evaluatedDoc = null;
		Case caseFilter = command.getCaseFilter();

		List<FieldDefinition> addFieldsList = new ArrayList<>();
		List<FieldDefinition> fuzzySetList = new ArrayList<>();

		List<String> alias = new ArrayList<>();
		alias.add(command.getLeftCollection().getAlias());
		alias.add(command.getRightCollection().getAlias());

		// A new document is created as join of left and right docs using aliases
		Pipeline docPipeline = new Pipeline();
		// PF. Le seguenti istruzioni servono a mantenere traccia degli operatori fuzzy, funzioni js e dizionary presenti nella pipeline
		docPipeline.setFuzzyOperators(pipeline.getFuzzyOperators());
		docPipeline.setJsFunctions(pipeline.getJsFunction());
		docPipeline.setDictionaries(pipeline.getDictionaries());

		docPipeline.add(ld, command.getLeftCollection().getAlias());
		docPipeline.add(rd, command.getRightCollection().getAlias());
		evaluatedDoc = docPipeline.getAsDocument();
		
		/* ADD FIELDS */
		if(command.getAddFieldsCommand() != null) {
			AddFieldsEvaluator addFieldsEvaluator = new AddFieldsEvaluator();
			for(NoFuzzyFunction nff : command.getAddFieldsCommand().getNonFuzzyFunction()) {
				addFieldsList.addAll (addFieldsEvaluator.evaluate(	evaluatedDoc, 
																	nff, 
																	command.getAddFieldsCommand().getFieldReferences().get(command.getAddFieldsCommand().getNonFuzzyFunction().indexOf(nff)), 
																	alias));
			}
			for (FieldDefinition f:addFieldsList) {
				evaluatedDoc.addField(f);
			}
		}
		
		
		// PF - Added on 16.07.2021
		/* SET FUZZY SETS */
		if(command.getSetFuzzySetsCommand() != null) {
			SetFuzzySetsEvaluator sfse = new SetFuzzySetsEvaluator();
			fuzzySetList.addAll(sfse.evaluate(ld, rd, command.getSetFuzzySetsCommand()));
			if (fuzzySetList.size() > 0) {
				evaluatedDoc.addField(new FieldDefinition("Y_"+Constants.FUZZY_FIELD_NAME+"_Y", new DocumentValue(new DocumentDefinition(fuzzySetList))));
			}
		}

	
		/* CASE WHERE*/
		if(caseFilter != null && evaluatedDoc != null ) {
			try {
				docPipeline.add(evaluatedDoc, "Join");
				CaseEvaluator caseEvaluator = new CaseEvaluator();
				evaluatedDoc = caseEvaluator.evaluate(docPipeline, caseFilter);		
				if(evaluatedDoc != null)
					evaluatedDoc.removeValue(FieldName.fromString(Constants.GEOMETRY_FIELD_NAME));
			} catch (ScriptException e) {
				e.printStackTrace();
            	throw new ExecuteProcessException("[SynchronizedJoinCycle]: CASE terminated");
			}

		} 
		return evaluatedDoc;
	}


}
