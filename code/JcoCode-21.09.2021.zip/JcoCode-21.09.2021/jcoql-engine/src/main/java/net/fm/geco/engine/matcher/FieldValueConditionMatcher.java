package net.fm.geco.engine.matcher;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.condition.FieldValueCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.value.Value;

public class FieldValueConditionMatcher implements IMatcher {

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {
		FieldValueCondition c = (FieldValueCondition) condition;
		DocumentDefinition document = (DocumentDefinition) pipeline.get(c.getField().getCollectionAlias());
		final Value fieldValue = document.getValue(c.getField().getFieldName());
		return fieldValue != null && c.getValue().equals(fieldValue);
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		if(matches(condition, pipeline)) {
			return 1;
		} else {
			return 0;
		}
	}

}
