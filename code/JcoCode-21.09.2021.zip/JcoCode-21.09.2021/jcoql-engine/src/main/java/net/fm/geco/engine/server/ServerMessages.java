package net.fm.geco.engine.server;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.StringJoiner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import net.fm.geco.engine.executor.utils.Configuration;

/**
 * Rappresenta i messaggi che invia il server al clietnt
 * @author Savino Lechiancole
 *
 */
public class ServerMessages {

	public ServerMessages() {}
	
	public String getMsgSuccessExecuteJCO() {
		return "##SUCCESS##";
	}
	
	public String getMsgErrorExecuteJCO(String errorMsg) {
		String prefix = "##BEGIN-ERROR##\n";
		String suffix = "\n##END-ERROR##";
		return prefix + errorMsg + suffix;
	}
	
	public String getAck() {
		return "##ACK##";
	}
	
	public String getMsgCollection(String documents) {
		String prefix = "##BEGIN-COLLECTION##\n";
		String suffix = "\n##END-COLLECTION##";
		return prefix + documents + suffix;
	}
	
	public String getMsgProcess(List<String> istructions) {
		String prefix = "##BEGIN-PROCESS##\n";
		String suffix = "##END-PROCESS##";
		
		String result = "";
		for(String s: istructions) {
			result = result + s + "\n";
		}
		return prefix + result + suffix;
	}
	
	public String getMsgIRList(Collection<String> irlist) {
		String prefix = "##BEGIN-IR-LIST##\n";
		String suffix = "\n##END-IR-LIST##";
		
		StringBuilder output = new StringBuilder("{\n");
		StringJoiner joiner = new StringJoiner(",\n");
		
		StringJoiner joiner2 = new StringJoiner(",");
		
		joiner.add("\t\"total\": " + irlist.size());
		Iterator<String> it = irlist.iterator();
		while(it.hasNext()) {
			joiner2.add("\"" + it.next() + "\"");
		}
		
		joiner.add("\t\"IRList\": " + "[" + joiner2.toString() + "]");
		
		
		output.append(joiner.toString());
		output.append("\n}");
		return prefix + output.toString() + suffix;
	}
	
	
	public String getMsgServerConf(List<Configuration> conf) {
		String prefix = "##BEGIN-SERVER-CONF##\n";
		String suffix = "\n##END-SERVER-CONF##";

        ObjectMapper mapper = new ObjectMapper();
 
        // enable pretty printing
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        
        StringBuilder output = new StringBuilder("{\n");
		StringJoiner joiner = new StringJoiner(",\n");
		
		output.append("\"total\": " + conf.size() + ",\n");
		output.append("\"servers\": [");
       
		for(Configuration c: conf) {
        	String doc;
			try {
				doc = mapper.writeValueAsString(c);
				joiner.add(doc);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
        }
        output.append(joiner.toString());
        output.append("\n]");
        output.append("\n}");
       
		return prefix + output.toString() + suffix;
	}
}
