package net.fm.geco.engine;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.json.JSONHandler;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.engine.state.ProcessState;
import net.fm.geco.model.Dictionary;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.FuzzyOp;
import net.fm.geco.model.JSFunction;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.Value;

public class Pipeline {
	
	private static final String CASE_UNSENSITIVE_SUFFIX = ".#CASE.UNSESITIVE.DICTIONARY#_";	

	// private Map<String, IDocumentCollection> collections;

	// collezioni
	private List<IDocumentCollection> collections;

	private Map<String, Object> objects;

	// file intermedi
	private Map<String, String> setIntermediateFiles;

	// collezione corrente
	private IDocumentCollection currentCollection;

	// nome collezione corrente
	private String currentCollectionName;

	private JSONHandler jh = new JSONHandler();

	private LinkedList<ProcessState> state;

	// contiene le istruzioni che sono state inviate dall'utente. Serve per il
	// messaggio "##GET-PROCESS##"
	private LinkedList<String> istructions;


	// lista dei Fuzzy Operator creati
	private LinkedList<FuzzyOp> fuzzyOperators;
	// lista delle funzioni JavaScript
	private LinkedList<JSFunction> jsFunctions;
	// map dei parametri passati agli operatori e alle funzioni JavaScript
	private DocumentDefinition fuzzyOperatorParameters = null;
	private List<FieldDefinition> fuzzyOperatorParametersList = new ArrayList<>();
	private Map<String, Value> jsFunctionParametersMap = new HashMap<>();

	// PF. added on 22.07.2021
	private Map<String, Dictionary> dictionaries;

	public Pipeline() {
		currentCollection = new SimpleDocumentCollection("empty");
		setIntermediateFiles = new TreeMap<String, String>();
		collections = new LinkedList<>();
		istructions = new LinkedList<>();
		state = new LinkedList<>();

		//creo lo stato iniziale
		ProcessState emptyState = new ProcessState();
		state.add(emptyState);

		fuzzyOperators = new LinkedList<>();
		jsFunctions = new LinkedList<>();
		
		// PF. addedo on 22.07.2021
		dictionaries = new TreeMap<String, Dictionary>();
	}

	/*
	 * private Map<String, IDocumentCollection> getCollections() { if (collections
	 * == null) { collections = new LinkedHashMap<String, IDocumentCollection>(); }
	 * return collections; }
	 */

	/*
	private List<IDocumentCollection> getCollections() {
		return collections;
	}*/


	private Map<String, Object> getObjects() {
		if (objects == null) {
			objects = new TreeMap<String, Object>();
		}
		return objects;
	}


	public void add(Object object, String alias) {
		getObjects().put(alias, object);
		this.currentCollectionName = alias;
	}

	public Object get(String alias) {
		return getObjects().get(alias);
	}

	public DocumentDefinition getAsDocument() {
		List<FieldDefinition> fields = new ArrayList<FieldDefinition>();
		for (Entry<String, Object> entry : objects.entrySet()) {
			String key = entry.getKey();
			Object val = entry.getValue();
			Value value = null;

			if (val instanceof DocumentDefinition) {
				value = new DocumentValue((DocumentDefinition) val);
			}

			if (value != null) {
				fields.add(new FieldDefinition(key, value));
			}
		}
		return new DocumentDefinition(fields);
	}

	public void setFuzzyOperators(List<FuzzyOp> listFuzzyOperator) {
		fuzzyOperators = new LinkedList<>(listFuzzyOperator);
	}

	public void setJsFunctions(List<JSFunction> lisJsFunctions) {
		jsFunctions = new LinkedList<>(lisJsFunctions);
	}

	/*
	 * public void addCollection(IDocumentCollection collection, String alias) {
	 * getCollections().put(alias, collection); this.currentCollectionName = alias;
	 * currentCollection = collection; }
	 */

	public void addCollection(IDocumentCollection collection) {
		collections.add(collection);
		currentCollection = collection;
		ProcessState s = new ProcessState(collection);
		//commenta!
		s.setIstruction(istructions.removeFirst());
		state.add(s);
	}


	//in questo caso lo stato � USEDB
	public void addCollection(List<String> dbnames) {
		ProcessState s = new ProcessState();
		s.setUsedb(dbnames);
		s.setIstruction(istructions.removeFirst());
		state.add(s);

//		currentCollection = new SimpleDocumentCollection();
	}

	//in questo caso lo stato � SET INTERMEDIATE AS
	public void addCollection(String collectionAlias, String fileName) {
		ProcessState s = new ProcessState();
		s.setSetIntermediateAs(collectionAlias, fileName);
		s.setIstruction(istructions.removeFirst());
		state.add(s);

	}

	// salva il nuovo FUZZY OPERATOR
	public void addFuzzyOperator(FuzzyOp fuzzyOp) {
		ProcessState s = new ProcessState(fuzzyOp, state.getLast().getCollection());
		s.setIstruction(istructions.removeFirst());
		state.add(s);
		fuzzyOperators.add(fuzzyOp);
	}

	// salva la nuova JS FUNCTION
	public void addJsFunction(JSFunction jsFun) {
		ProcessState s = new ProcessState(jsFun, state.getLast().getCollection());
		s.setIstruction(istructions.removeFirst());
		state.add(s);
		this.jsFunctions.add(jsFun);
	}

	/*
	 * public IDocumentCollection getCollection(String alias) { if
	 * (getCollections().containsKey(alias)) return getCollections().get(alias);
	 * else return jh.createCollection(alias, setIntermediateFiles.get(alias)); }
	 */


	public IDocumentCollection getCollection(String alias) {
		// Se è temporary restituisci currentCollection
		if (alias.equals("temporary")) {
			return currentCollection;
		} else if (setIntermediateFiles.get(alias) != null) {			
			return jh.createCollection(alias, setIntermediateFiles.get(alias));
		} else {
			// devo scorrere la lista degli stati
			for (ProcessState s : state) {
				if (s.getCollection().getName().equals(alias)) {
					return s.getCollection();
				}
			}
		}
		// la collection non esiste da nessuna parte
		throw new ExecuteProcessException("ERROR: collection " + alias + " does not exist");
	}

	public IDocumentCollection getCurrentCollection() {
		return currentCollection;
	}


	public String getCurrentCollectionName() {
		return currentCollectionName;
	}

	public void addFiles(String collectionName, String fileName) {
		setIntermediateFiles.put(collectionName, fileName);
	}

	public void setCurrentCollectionName(String alias) {
		currentCollectionName = alias;
	}

	public void backtrack(DatabaseRegistry registry) {
		if (!(state.getLast().isEmptyState())) {
			if (state.getLast().isUseDb()) {
				for(String name: state.getLast().getDbNames())
					registry.deleteDatabase(name);
			} else if (state.getLast().isSetIntermediateAs()) {
				File file = new File(state.getLast().getFileName());
		        file.delete();
				setIntermediateFiles.remove(state.getLast().getCollectionAlias());
			} else if(state.getLast().isCreateFuzzyOperator()) {
				fuzzyOperators.removeLast();
			} else if(state.getLast().isCreateJsFunction()) {
				jsFunctions.removeLast();
			}
			// rimuovo l'ultimo stato
			state.removeLast();
			// aggiorno la collezione corrente
			currentCollection = state.getLast().getCollection();
		} else
			throw new ExecuteProcessException("[BACKTRACK]: empty state, cannot go back anymore");
	}

	public List<IDocumentCollection> getListCollections() {
		return collections;
	}

	public void setIstructions(List<String> istr) {
		istructions = new LinkedList<>();
		istructions.addAll(istr);
	}

	public LinkedList<String> getIstructions() {
		LinkedList<String> istr = new LinkedList<>();
		for(ProcessState s: state) {
			if(!(s.isEmptyState()))
				istr.add(s.getIstruction());
		}
		return istr;
	}

	public Collection<String> getIRList() {
		return setIntermediateFiles.keySet();
	}

	public IDocumentCollection getIRCollection(String collectionName) {
		if (setIntermediateFiles.get(collectionName) != null)
			return jh.createCollection(collectionName, setIntermediateFiles.get(collectionName));
		else
			throw new ExecuteProcessException(
					"[GET IR COLLECTION]: IR collection " + collectionName + " does not exits");
	}

	public void addParametersMap(String name, Value value) {
		this.jsFunctionParametersMap.put(name, value);
	}

	public void addFuzzyOperatorParameters(String name, Value value) {
		fuzzyOperatorParametersList.add(new FieldDefinition(name, value));
		if(fuzzyOperatorParameters == null) {
			fuzzyOperatorParameters = new DocumentDefinition(fuzzyOperatorParametersList);
		} else {
			fuzzyOperatorParameters.addField(new FieldDefinition(name, value));
		}
	}

	public DocumentDefinition getFuzzyOperatorParameters() {
		return fuzzyOperatorParameters;
	}

	public List<JSFunction> getJsFunction() {
		return jsFunctions;
	}

	public List<FuzzyOp> getFuzzyOperators() {
		return fuzzyOperators;
	}

	public Map<String, Value> getJsFunctionParametersMap() {
		return jsFunctionParametersMap;
	}

	// PF. added on 22.07.2021
	public void addDictionary(IDocumentCollection collection, String dictionaryNane) {
		String key, value;
		Dictionary dictionary = new Dictionary(dictionaryNane);
		dictionaries.put(dictionaryNane, dictionary);
		Dictionary dictionaryNoCase = new Dictionary(dictionaryNane);
		dictionaries.put(dictionaryNane+CASE_UNSENSITIVE_SUFFIX, dictionaryNoCase);

		for (DocumentDefinition dd:collection.getDocument()) {
			key = null;
			value = null;
			if (dd.getValue("key") != null && dd.getValue("key").getType() == EValueType.STRING)
				key = dd.getValue("key").getStringValue();
			if (dd.getValue("value") != null && dd.getValue("value").getType() == EValueType.STRING) 
				value = dd.getValue("value").getStringValue();
			if (key != null && value != null) {
				dictionary.put(key, value);
				dictionaryNoCase.put(key.toLowerCase(), value);
			}
		}
		
	}
	// PF. added on 22.07.2021
	public String getDictionaryValue (String dictionary, String key, boolean caseSensitive) {
		if (!dictionaries.containsKey(dictionary))
			return null;
		if (caseSensitive)
			return dictionaries.get(dictionary).get(key);
		return dictionaries.get(dictionary+CASE_UNSENSITIVE_SUFFIX).get(key.toLowerCase());		
	}
	public  Map<String, Dictionary> getDictionaries () {
		return dictionaries;
	}
	public void setDictionaries (Map<String, Dictionary> dictionaries) {
		this.dictionaries = dictionaries;
	}
	// PF. added on 26.07.2021
	public void propagateEnvironment (Pipeline targetPipeline) {
		targetPipeline.jh = this.jh;
		targetPipeline.state = this.state;
		targetPipeline.fuzzyOperators = this.fuzzyOperators;
		targetPipeline.jsFunctions = this.jsFunctions;
		targetPipeline.fuzzyOperatorParameters = this.fuzzyOperatorParameters;
		targetPipeline.fuzzyOperatorParametersList = this.fuzzyOperatorParametersList;
		targetPipeline.jsFunctionParametersMap = this.jsFunctionParametersMap;
		targetPipeline.dictionaries = this.dictionaries;		
	}
	// PF. added on 26.07.2021
	public void retrieveEnvironment (Pipeline sourcePipeline) {
		this.jh = sourcePipeline.jh;
		this.state = sourcePipeline.state;
		this.fuzzyOperators = sourcePipeline.fuzzyOperators;
		this.jsFunctions = sourcePipeline.jsFunctions;
		this.fuzzyOperatorParameters = sourcePipeline.fuzzyOperatorParameters;
		this.fuzzyOperatorParametersList = sourcePipeline.fuzzyOperatorParametersList;
		this.jsFunctionParametersMap = sourcePipeline.jsFunctionParametersMap;
		this.dictionaries = sourcePipeline.dictionaries;		
	}

}
