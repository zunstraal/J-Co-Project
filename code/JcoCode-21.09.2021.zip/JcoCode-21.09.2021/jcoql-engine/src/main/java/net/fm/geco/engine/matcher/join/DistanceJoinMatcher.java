package net.fm.geco.engine.matcher.join;

import org.locationtech.jts.geom.Geometry;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.BasicConditionMatcher;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.join.DistanceJoinCondition;
import net.fm.geco.model.expression.BasicExpression;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.SimpleValue;

public class DistanceJoinMatcher implements IMatcher{
	
	public final static double AVERAGE_RADIUS_OF_EARTH_KM = 6371;

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {

		DistanceJoinCondition c = (DistanceJoinCondition)condition;
		BasicConditionMatcher bc = new BasicConditionMatcher();

		GeoJsonValue lgj = (GeoJsonValue) pipeline.get(Constants.LEFT_DOCUMENT_ALIAS);
		GeoJsonValue rgj = (GeoJsonValue) pipeline.get(Constants.RIGHT_DOCUMENT_ALIAS);

		Geometry lg = lgj.getGeometry();
		Geometry rg = rgj.getGeometry();
				
		// distanza in km
		double distance = getDistanceFromLatLonInKm(lg.getCentroid().getY(),lg.getCentroid().getX(),
				rg.getCentroid().getY(),rg.getCentroid().getX());
//		System.out.println("Distanza: "+distance + " Distanza in gradi: "+lg.distance(rg) +"   "+ lg.getCentroid() +" AND " + rg.getCentroid()+ 
//				" Si intersecano? "+  lg.intersects(rg) );

		switch(c.getUnit()){
		
		case METERS:
			distance = distance * 1000;
			break;
		case MILES:
			distance = distance / 1.60934;
			break;
		case KILOMETERS:
			break;
		default:
			break;
		
		}
		
		return bc.matches(new BasicCondition(new BasicExpression(new SimpleValue(distance), c.getOperator(), new SimpleValue(c.getDistance()))), pipeline);
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		if(matches(condition, pipeline)) {
			return 1;
		} else {
			return 0;
		}
	}


	public double getDistanceFromLatLonInKm(double lat1,double lon1,double lat2,double lon2) {
		  int R = 6371;  // km
		  
		  double dLat = Math.toRadians(lat2-lat1);  
		  double dLon = Math.toRadians(lon2-lon1);
		  		  
		  double a = 
		    Math.sin(dLat/2) * Math.sin(dLat/2) +
		    Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * 
		    Math.sin(dLon/2) * Math.sin(dLon/2)
		    ;
		  double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		  double d = R * c; 
		  return d;
		}

}
