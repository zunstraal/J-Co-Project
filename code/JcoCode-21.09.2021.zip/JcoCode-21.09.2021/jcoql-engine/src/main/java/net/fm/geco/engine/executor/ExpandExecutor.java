package net.fm.geco.engine.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import javax.script.ScriptException;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.executor.utils.SynchronizedDuplicateRemover;
import net.fm.geco.engine.executor.utils.SynchronizedExpandCycle;
import net.fm.geco.engine.matcher.FieldPresenceConditionMatcher;
import net.fm.geco.engine.matcher.FieldValueConditionMatcher;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.TreeConditionMatcher;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.command.ExpandCommand;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.FieldValueCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.UnpackCondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.ArrayValue;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;


@Executor(ExpandCommand.class)
public class ExpandExecutor implements IExecutor<ExpandCommand> {
	// PF. da eliminare insieme alla vecchia gestione dell'expand
	boolean isFirstTime;
	List<DocumentDefinition> docList;



	@Override
	// PF. New implementation 1
	public void execute(Pipeline pipeline, ExpandCommand command) throws ExecuteProcessException {
		List<UnpackCondition> unpacks = command.getUnpack();

		SimpleDocumentCollection outCollection = new SimpleDocumentCollection("Expand", new ArrayList<DocumentDefinition>());
		LinkedBlockingQueue<DocumentDefinition> queue = new LinkedBlockingQueue<DocumentDefinition>();
		SynchronizedDuplicateRemover sdr = new SynchronizedDuplicateRemover(queue, false);
		sdr.start();		

		// Preconditions to run EXPAND
		if (unpacks != null && pipeline.getCurrentCollection() != null) {
			IDocumentCollection collection = pipeline.getCurrentCollection();

			// for each doc in collection
			for (DocumentDefinition currentDoc: collection.getDocument()) {
				Boolean discardedDoc = true;
				Pipeline p = new Pipeline();
				p.add(currentDoc, "Expand");

				// for each UNPACK in EXPAND
				for (UnpackCondition unpack : unpacks) {
					try {
						// check if current doc matches the unpack condition
						if (checkConditions(unpack, p)) {
							// Array container
							List<Value> listValues = null;
							FieldReference inputField = unpack.getInputField();
							// retrieve source array field, and remove from the current doc
							Value array = currentDoc.removeValue(inputField.getFieldName());

							// PF. chiedere a giuseppe... che fare se non � un array? nulla o ecczione?
							if (array == null)
									throw new ExecuteProcessException("[EXPAND]: Did not found a value for the field name: " + inputField.getFieldName());	
							// Retrieve array values
							if (array.getType() == EValueType.ARRAY) {
								listValues = ((ArrayValue) array).getValues();
							} else {
								throw new ExecuteProcessException("[EXPAND]: The inputField is neither an array or not existing");
							}

							if (listValues != null && !listValues.isEmpty()) {
								// PF threads declaration
								SynchronizedExpandCycle[] threads;
								int nThreads = 1;
								sdr.setInfomer(listValues.size(), 20);
								//PF per il filter uso tutti i processori logici meno uno
								if (Constants.getInstance().getNProcessors() > 1)
									nThreads = 2*Constants.getInstance().getNProcessors()-1;

								
								// PF threads creation
								threads = new SynchronizedExpandCycle[nThreads];
								for (int i=0; i<nThreads; i++) {
									// save current doc other fields
									List<FieldDefinition> outputList2 = currentDoc.getFields();
									threads[i] = new SynchronizedExpandCycle(i, nThreads, queue, unpack, listValues, outputList2);
								}
								// PF threads launching
								for (int i=0; i<nThreads; i++)
									threads[i].start();

								// PF thread synchro
								for (int i=0; i<nThreads; i++)
									try {
										threads[i].join();
									} catch (InterruptedException e) {
										e.printStackTrace();
										throw new ExecuteProcessException("[EXPAND]: Failed Thread Sychronization");
									}
								
							}
							discardedDoc = false; 
							break;
						}
					} catch (ScriptException e) {
						e.printStackTrace();
					}
				}	// end for each unpack

				// add discarded docs if KEEP option
				if (discardedDoc && command.isKeepOthers()) {
					try {
						queue.put(currentDoc);
					} catch (InterruptedException e) {
						e.printStackTrace();
						throw new ExecuteProcessException("[EXPAND]: Failed to fill queue");
					}
				}
					
			} 	// end for each doc

		}	// end precondition if

		// GET the final collection and return it
		sdr.interrupt();
		try {
			sdr.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ExecuteProcessException("[FILTER]: Failed Remover Thread Sychronization");
		}
		List<DocumentDefinition> outDocs = sdr.getDocs();

		outCollection = new SimpleDocumentCollection("Expand", outDocs);
		pipeline.addCollection(outCollection);
	}
	
	
	
	
//	@Override
	// PF. New implementation 1
	public void executeNEW2(Pipeline pipeline, ExpandCommand command) throws ExecuteProcessException {
		List<UnpackCondition> unpacks = command.getUnpack();
		IDocumentCollection outCollection = new SimpleDocumentCollection("Expand");

		// Preconditions to run EXPAND
		if (unpacks != null && pipeline.getCurrentCollection() != null) {
			IDocumentCollection collection = pipeline.getCurrentCollection();

			// for each doc in collection
			for (DocumentDefinition currentDoc: collection.getDocument()) {
				Boolean discardedDoc = true;
				Pipeline p = new Pipeline();
				p.add(currentDoc, "Expand");

				// for each UNPACK in EXPAND
				for (UnpackCondition unpack : unpacks) {
					try {
						// check if current doc matches the unpack condition
						if (checkConditions(unpack, p)) {
							// Array container
							List<Value> listValues = null;
							FieldReference inputField = unpack.getInputField();
							// retrieve source array field, and remove from the current doc
							Value array = currentDoc.removeValue(inputField.getFieldName());
							// save current doc other fields
							List<FieldDefinition> outputList = currentDoc.getFields();

							// PF. chiedere a giuseppe... che fare se non � un array? nulla o ecczione?
							if (array == null)
									throw new ExecuteProcessException("[EXPAND]: Did not found a value for the field name: " + inputField.getFieldName());	
							// Retrieve array values
							if (array.getType() == EValueType.ARRAY) {
								listValues = ((ArrayValue) array).getValues();
							} else {
								throw new ExecuteProcessException("[EXPAND]: The inputField is neither an array or not existing");
							}

							if (listValues != null && !listValues.isEmpty()) {
								performExpand (unpack, listValues, outputList, outCollection);
							}
							discardedDoc = false; 
							break;
						}
					} catch (ScriptException e) {
						e.printStackTrace();
					}
				}	// end for each unpack

				// add discarded docs if KEEP option
				if (discardedDoc && command.isKeepOthers())
					outCollection.addDocument(currentDoc);
					
			} 	// end for each doc

		}	// end precondition if

		pipeline.addCollection(outCollection);
	}

	// da elimninare
	void performExpand (UnpackCondition unpack, List<Value> listValues, List<FieldDefinition> outputList, IDocumentCollection outCollection) {
		// PF. SE SI PU� PARALLELIZZARE QUI *********
		for (int index=0; index<listValues.size();index++) {
			Value v = listValues.get(index);

//			GenerateCommand generate = unpack.getGenerate();
//			GenerateCommandEvaluator evaluator = new GenerateCommandEvaluator();

			List<FieldDefinition> arrayElements = new ArrayList<>();
			arrayElements.add(new FieldDefinition("position", new SimpleValue(index)));
			arrayElements.add(new FieldDefinition("item", v));
			DocumentValue arrayField = new DocumentValue(new DocumentDefinition(arrayElements));
			FieldDefinition fd = new FieldDefinition(unpack.getOutputField().getLastLevelName(), arrayField);
			// build the array field hierarchy (if existing) es .a.b.c
			for (int l=unpack.getOutputField().getLevel()-2; l>=0; l--) {
				arrayElements = new ArrayList<>();
				arrayElements.add(fd);
				arrayField = new DocumentValue(new DocumentDefinition(arrayElements));
				fd = new FieldDefinition(unpack.getOutputField().getLevelName(l), arrayField);
			}
			outputList.add(fd);
			DocumentDefinition newDoc = new DocumentDefinition(outputList);

			/*	PF. GENEERATE ACTION deprecated on 07.05.2021
			if (generate != null) {
				Pipeline p2 = new Pipeline();
				p2.add(newDoc, "Expand");
				newDoc = evaluator.evaluate(p2, generate);											
			}
*/
			outCollection.addDocument(newDoc);			
		}
	}


	
	/* Controllo delle condizioni in input di unpack */
	private boolean checkConditions(UnpackCondition unpackCondition, Pipeline pipeline) throws ScriptException {

		// se si usa quello commentto si implementa una logica OR
		// boolean matches = false;
		boolean matches = true;

		List<ICondition> conditions = unpackCondition.getWith();
		if (conditions != null) {

			for (ICondition c : conditions) {
				IMatcher matcher = getMatcher(c);
				// si potrebbe mettere qui in controllo che chiede se è il
				// matcher
				// di un orcondition-> se fosse true cortocircuita e restituisce
				// subite matches =true
				if (matcher != null && !matcher.matches(c, pipeline)) {

					// matches = true;
					matches = false;

				}

			}
		}

		return matches;
	}

	/*
	 * Ottiene il valutatore di una determinata condizione, per adesso sono
	 * implementati la valutazione della presenza di un campo e la
	 * corrispondenza di valore di un determinato campo
	 */
	private IMatcher getMatcher(ICondition condition) {
		IMatcher matcher = null;
		if (condition instanceof FieldPresenceCondition) {
			matcher = new FieldPresenceConditionMatcher();
		} else if (condition instanceof FieldValueCondition) {
			matcher = new FieldValueConditionMatcher();
		} else if (condition instanceof TreeCondition) {
			matcher = new TreeConditionMatcher();
		}
		return matcher;
	}

}
