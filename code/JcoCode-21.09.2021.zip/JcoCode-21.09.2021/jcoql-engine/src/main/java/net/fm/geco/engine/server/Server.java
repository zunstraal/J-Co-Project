package net.fm.geco.engine.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	private static ServerSocket serverSocket;
	private static int portNumber = 44444;

	private static void runServer() {
		System.out.println("Server starting...");
		try {
			serverSocket = new ServerSocket(portNumber);
			//serverSocket.setSoTimeout(400000);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		while(true) {
			try {
				Socket clientSocket = serverSocket.accept();
				new Thread(new ServerRunnable(clientSocket)).start();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	public static void main(String[] args) {
		runServer();
	}


}
