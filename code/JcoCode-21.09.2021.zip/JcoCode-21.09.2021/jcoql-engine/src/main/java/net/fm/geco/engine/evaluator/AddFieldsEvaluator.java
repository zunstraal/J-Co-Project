package net.fm.geco.engine.evaluator;

import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.matcher.join.AreaJoinConditionMatcher;
import net.fm.geco.engine.matcher.join.DistanceJoinMatcher;
import net.fm.geco.engine.matcher.join.OrientationJoinConditionMatcher;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.NoFuzzyFunction;
import net.fm.geco.model.condition.join.EOrientation;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.SimpleValue;

public class AddFieldsEvaluator {

    public List<FieldDefinition> evaluate(DocumentDefinition doc, NoFuzzyFunction noFuzzyFunction, List<String> newName, List<String> alias) {

        List<FieldDefinition> outFieldList = new ArrayList<>();
        int type = noFuzzyFunction.getType();
        // Geometry
        DocumentDefinition docLeft = new DocumentDefinition(((DocumentValue) doc.getValue(alias.get(0))).getFields());
        DocumentDefinition docRight = new DocumentDefinition(((DocumentValue) doc.getValue(alias.get(1))).getFields());

        if(docLeft.getValue(Constants.GEOMETRY_FIELD_NAME) != null && docRight.getValue(Constants.GEOMETRY_FIELD_NAME) != null) {
            GeoJsonValue lgj = (GeoJsonValue) docLeft.getValue(Constants.GEOMETRY_FIELD_NAME);
            GeoJsonValue rgj = (GeoJsonValue) docRight.getValue(Constants.GEOMETRY_FIELD_NAME);

            Geometry lg = lgj.getGeometry();
            Geometry rg = rgj.getGeometry();


            // DISTANCE(unit)
            if (type == 0) {
                DistanceJoinMatcher distanceJoinMatcher = new DistanceJoinMatcher();
                double distance = distanceJoinMatcher.getDistanceFromLatLonInKm(lg.getCentroid().getY(), lg.getCentroid().getX(),
                        rg.getCentroid().getY(), rg.getCentroid().getX());
                if (noFuzzyFunction.getUnit().equals("M")) {
                    distance = distance * 1000;
                } else if (noFuzzyFunction.getUnit().equals("ML")) {
                    distance = distance / 1.60934;
                }

                SimpleValue value = new SimpleValue(distance);
                DocumentDefinition docDef = null;
                docDef = getFieldDefinition(newName, value, 0, docDef);

                outFieldList.addAll(docDef.getFields());
                //outFieldList.add(new FieldDefinition(newName, new SimpleValue(distance)));

            // AREA(unit)
            } else if (type == 1) {
                Geometry temp = lg.intersection(rg);
                double area = 0;
                if (temp.getGeometryType().equals("Polygon")) {
                    Coordinate[] coord = temp.getCoordinates();
                    List<Point> locations = new ArrayList<>();

                    for (Coordinate coordinate : coord) {
                        locations.add(GeometryFactory.createPointFromInternalCoord(coordinate, lg.getCentroid()));
                    }

                    AreaJoinConditionMatcher areaJoinConditionMatcher = new AreaJoinConditionMatcher();
                    area = areaJoinConditionMatcher.calculateAreaOfPolygonOnEarthInSquareMeters(locations);

                    if (noFuzzyFunction.getUnit().equals("ML")) {
                        area = area / 1609340;
                    } else if (noFuzzyFunction.getUnit().equals("KM")) {
                        area = area / 1000000;
                    }

                    SimpleValue value = new SimpleValue(area);
                    DocumentDefinition docDef = null;
                    docDef = getFieldDefinition(newName, value, 0, docDef);

                    outFieldList.addAll(docDef.getFields());
                    //outFieldList.add(new FieldDefinition(newName, new SimpleValue(area)));
                }

            // ORIENTATION(from)
            } else if (type == 2) {
                //angleFromCoordinate()
                double angle = 0;
                OrientationJoinConditionMatcher orientationJoinConditionMatcher = new OrientationJoinConditionMatcher();
                if (noFuzzyFunction.getFrom().equals("RIGHT")) {
                    angle = orientationJoinConditionMatcher.angleFromCoordinate(Math.toRadians(lg.getCentroid().getY()),
                            Math.toRadians(lg.getCentroid().getX()), Math.toRadians(rg.getCentroid().getY()),
                            Math.toRadians(rg.getCentroid().getX()));
                } else if (noFuzzyFunction.getFrom().equals("LEFT")) {
                    angle = orientationJoinConditionMatcher.angleFromCoordinate(Math.toRadians(rg.getCentroid().getY()),
                            Math.toRadians(rg.getCentroid().getX()), Math.toRadians(lg.getCentroid().getY()),
                            Math.toRadians(lg.getCentroid().getX()));
                }

                String orientation = "";

                if (angle <= 11.25 && angle > 348.75) {
                    orientation = String.valueOf(EOrientation.E);
                } else if (angle <= 101.25 && angle > 78.75) {
                    orientation = String.valueOf(EOrientation.N);
                } else if (angle <= 56.25 && angle > 33.75) {
                    orientation = String.valueOf(EOrientation.NE);
                } else if (angle <= 191.25 && angle > 168.75) {
                    orientation = String.valueOf(EOrientation.W);
                } else if (angle <= 146.25 && angle > 123.75) {
                    orientation = String.valueOf(EOrientation.NW);
                } else if (angle <= 236.25 && angle > 213.75) {
                    orientation = String.valueOf(EOrientation.SW);
                } else if (angle <= 218.25 && angle > 258.75) {
                    orientation = String.valueOf(EOrientation.S);
                } else if (angle <= 33.75 && angle > 11.25) {
                    orientation = String.valueOf(EOrientation.ENE);
                } else if (angle <= 78.75 && angle > 56.25) {
                    orientation = String.valueOf(EOrientation.NNE);
                } else if (angle <= 123.75 && angle > 101.25) {
                    orientation = String.valueOf(EOrientation.NNW);
                } else if (angle <= 186.75 && angle > 164.25) {
                    orientation = String.valueOf(EOrientation.WNW);
                } else if (angle <= 231.75 && angle > 191.25) {
                    orientation = String.valueOf(EOrientation.WSW);
                } else if (angle <= 258.75 && angle > 236.25) {
                    orientation = String.valueOf(EOrientation.SSW);
                } else if (angle <= 303.75 && angle > 281.25) {
                    orientation = String.valueOf(EOrientation.SSE);
                } else if (angle <= 348.75 && angle > 326.25) {
                    orientation = String.valueOf(EOrientation.ESE);
                }

                if (orientation != null) {
                    SimpleValue value = new SimpleValue(orientation);
                    DocumentDefinition docDef = null;
                    docDef = getFieldDefinition(newName, value, 0, docDef);

                    outFieldList.add(docDef.getFields().get(0));
                    //outFieldList.add(new FieldDefinition(newName, new SimpleValue(orientation)));
                }

            // INCLUDED(side)
            } else if (type == 3) {
                boolean include = false;
                if (noFuzzyFunction.getSide().equals("LEFT")) {
                    include = rg.contains(lg);
                } else {
                    include = lg.contains(rg);
                }

                SimpleValue value = new SimpleValue(include);
                DocumentDefinition docDef = null;
                docDef = getFieldDefinition(newName, value, 0, docDef);

                outFieldList.add(docDef.getFields().get(0));
                //outFieldList.add(new FieldDefinition(newName, new SimpleValue(include)));

            // INCLUDED(LEFT) ?????
            } else if (type == 4) {
                SimpleValue value = new SimpleValue(rg.contains(lg));
                DocumentDefinition docDef = null;
                docDef = getFieldDefinition(newName, value, 0, docDef);

                outFieldList.add(docDef.getFields().get(0));
                //outFieldList.add(new FieldDefinition(newName, new SimpleValue(rg.contains(lg))));

            // INCLUDED(RIGHT) ?????
            } else if (type == 5) {
                SimpleValue value = new SimpleValue(lg.contains(rg));
                DocumentDefinition docDef = null;
                docDef = getFieldDefinition(newName, value, 0, docDef);

                outFieldList.add(docDef.getFields().get(0));
                //outFieldList.add(new FieldDefinition(newName, new SimpleValue(lg.contains(rg))));

            // MEET
            } else if (type == 6) {
                SimpleValue value = new SimpleValue(lg.getBoundary().intersects(rg.getBoundary()));
                DocumentDefinition docDef = null;
                docDef = getFieldDefinition(newName, value, 0, docDef);

                outFieldList.add(docDef.getFields().get(0));
                //outFieldList.add(new FieldDefinition(newName, new SimpleValue(lg.getBoundary().intersects(rg.getBoundary()))));

            // INTERSECT
            } else if (type == 7) {
                SimpleValue value = new SimpleValue(lg.intersects(rg));
                DocumentDefinition docDef = null;
                docDef = getFieldDefinition(newName, value, 0, docDef);

                outFieldList.add(docDef.getFields().get(0));
                //outFieldList.add(new FieldDefinition(newName, new SimpleValue(lg.intersects(rg))));
            }
        }

        return outFieldList;

    }

    private DocumentDefinition getFieldDefinition(List<String> newName, SimpleValue value, int counter, DocumentDefinition docDef) {
        if(counter != newName.size()-1) {
            List<FieldDefinition> listFieldDef = new ArrayList<>();
            listFieldDef.add(new FieldDefinition(newName.get(counter++), new DocumentValue(getFieldDefinition(newName, value, counter, docDef))));
            return new DocumentDefinition(listFieldDef);
        } else {
            List<FieldDefinition> listFieldDef = new ArrayList<>();
            listFieldDef.add(new FieldDefinition(newName.get(counter), value));
            return new DocumentDefinition(listFieldDef);
        }
    }

}
