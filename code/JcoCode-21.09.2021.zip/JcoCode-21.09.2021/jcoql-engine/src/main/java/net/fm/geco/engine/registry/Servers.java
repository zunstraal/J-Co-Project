package net.fm.geco.engine.registry;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import net.fm.geco.engine.executor.utils.Configuration;

@Service
public class Servers {
	
	private ArrayList<Configuration> list;
	
	public Servers() {
		list = new ArrayList<Configuration>();
	}
	
	public void addConfiguration(Configuration c) {
		list.add(c);
	}
	
	public ArrayList<Configuration> getConfigurations(){
		return list;
	}
}