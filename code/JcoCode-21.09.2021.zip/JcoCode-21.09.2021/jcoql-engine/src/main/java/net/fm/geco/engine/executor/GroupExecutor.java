package net.fm.geco.engine.executor;

import static java.util.stream.Collectors.groupingBy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.script.ScriptException;

//import net.fm.geco.engine.IDocumentCollection;
import net.fm.geco.engine.Pipeline;
//import net.fm.geco.engine.SimpleDocumentCollection;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.evaluator.GenerateCommandEvaluator;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.matcher.FieldPresenceConditionMatcher;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.TreeConditionMatcher;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.builder.DocumentDefinitionBuilder;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.command.GroupCommand;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.PartitionCondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;


@Executor(GroupCommand.class)
public class GroupExecutor implements IExecutor<GroupCommand> {

	boolean isFirstTime;

	@Override
	public void execute(Pipeline pipeline, GroupCommand command) throws ExecuteProcessException {
		IDocumentCollection finalCollection;
		IDocumentCollection outCollection = new SimpleDocumentCollection("Group");

		isFirstTime = true;

		List<PartitionCondition> partitions = command.getPartitions();

		// i documenti possono essere aggiunti a una sola partition: keeped document sono i documenti ancora non aggiunti ad una partition
		List<DocumentDefinition> keepedDocuments = new ArrayList<>();

		Pipeline myPipeline = pipeline;

		for (PartitionCondition partition : partitions) {

			boolean dropGrougpingField = partition.getDropGrougpingField();

			// qui prendo la collezione target
			IDocumentCollection collection = myPipeline.getCurrentCollection();

			if (collection != null) {
				List<DocumentDefinition> processedDocuments = new ArrayList<DocumentDefinition>();
				//List<DocumentDefinition> documents = collection.getDocuments();
				List<DocumentDefinition> documents = new ArrayList<>();

				// documents contiene ora i documenti del target
				collection.getDocument().forEach(documents::add);

				if (documents != null && !documents.isEmpty()) {
					if (partitions != null) {

						Stream<DocumentDefinition> stream = documents.stream()
								// Skip documents already processed
								.filter(d -> {
									return !processedDocuments.contains(d);
								})
								// Match conditions
								.filter(d -> {
									Pipeline p = new Pipeline();

									p.add(d, "Group");
									// check condition WITH del target
									try {
										if(checkConditions(partition, p)){
											keepedDocuments.remove(d);
											return true;
										}
										else{
											if(isFirstTime)
												keepedDocuments.add(d);
											return false;
										}
									} catch (ScriptException e) {
										e.printStackTrace();
									}

									return false;
								});

						// Set document processed

						List<FieldReference> orderBy = partition.getOrderBy();
						List<Integer> versus = partition.getVersus();
						List<FieldReference> groupings = partition.getGroupBy();

						if (groupings != null) {
							// groupOutputField è INTO
							//groupings è GROUP BY
							// order by e versus = null

							// cosa contiene outDocuments?

							//NUOVO aggiunto parametro bool dropGrougpingField
							List<DocumentDefinition> outDocuments = groupDocuments(stream,
									partition.getGroupOutputField(), groupings, orderBy, versus, dropGrougpingField);

							//NUOVO 2
							//		List<DocumentDefinition> outDocuments = groupDocuments(stream,
							//				partition.getGroupOutputFieldRef(), groupings, orderBy, versus, dropGrougpingField);

							if (outDocuments != null) {
								final GenerateCommand generate = partition.getGenerate();


								if (generate != null) {
									GenerateCommandEvaluator evaluator = new GenerateCommandEvaluator();
									outDocuments.stream().map(d -> {
										Pipeline p = new Pipeline();
										p.add(d, "Group");
										return evaluator.evaluate(p, generate);
									}).forEach(outCollection::addDocument);

								} else {

									// aggiungo nella outCollection
									outDocuments.forEach(outCollection::addDocument);
								}


								/*IDocumentCollection tempCollection = new SimpleDocumentCollection("tempGroup", keepedDocuments);
								myPipeline.addCollection(tempCollection, tempCollection.getName());*/
								isFirstTime = false;
							}
						}
					}

				}
			}
		}

		List<DocumentDefinition> finalDocs = outCollection.getDocument();

		if(command.isKeepOthers())
			finalDocs.addAll(keepedDocuments);

		finalCollection = new SimpleDocumentCollection("Group",finalDocs);

		pipeline.addCollection(finalCollection);
	}


	// group documents into partition
	private List<DocumentDefinition> groupDocuments(Stream<DocumentDefinition> stream, FieldName groupOutputField,
													List<FieldReference> groupings, List<FieldReference> orderBy, List<Integer> versus, boolean dropGrougpingField) {

//	private List<DocumentDefinition> groupDocuments(Stream<DocumentDefinition> stream, Field groupOutputField,
//			List<FieldReference> groupings, List<FieldReference> orderBy, List<Integer> versus, boolean dropGrougpingField) {


		List<FieldName> keyList = new ArrayList<>();

		for (FieldReference fr : groupings) {
			keyList.add(fr.getFieldName());
		}

		// se INTO non specificato = .items
		FieldName itemsField = Optional.ofNullable(groupOutputField).orElse(FieldName.fromString(".items"));

		//	Field item = new Field();
		//	item.addField(".item");
		//	Field itemsField = Optional.ofNullable(groupOutputField).orElse(item);

		Map<KeyValues, List<DocumentDefinition>> groups = stream
				.collect(groupingBy(d -> new KeyValues(d.getValues(keyList))));

		//EC NUOVO condizione if. Implementazione della nuova clausola drop grouping fields
		if(dropGrougpingField)
		{
			for(Map.Entry<KeyValues, List<DocumentDefinition>> entry : groups.entrySet())
			{
				for(int i = 0; i < entry.getValue().size(); i++)
				{
					for(int j = 0; j < groupings.size(); j++)
					{
						String dropBy = groupings.get(j).getFieldName().getFirstLevelName();
						entry.getValue().get(i).removeValue(dropBy);
					}
				}
			}
		}



		return groups.keySet().stream().map(v -> {

			List<DocumentDefinition> docs = groups.get(v);

			if (orderBy != null) {
				Collections.sort(docs, new Comparator<DocumentDefinition>() {

					@Override
					public int compare(DocumentDefinition o1, DocumentDefinition o2) {

						return compareKeys(o1, o2, orderBy, versus, 0);

					}
				});

			}


			DocumentDefinitionBuilder tempBuilder = new DocumentDefinitionBuilder();
			List<Value> values = v.getValues();

			for (int i = 0; i < groupings.size(); i++) {
				tempBuilder = tempBuilder.withField().fromValue(keyList.get(i).getLastLevelName(), values.get(i)).add();

			}

			return tempBuilder.withField().fromDocumentList(itemsField.getLastLevelName(), docs).add().build();
		}).collect(Collectors.toList());
	}


	private boolean checkConditions(PartitionCondition partitionCondition, Pipeline pipeline) throws ScriptException {
		boolean matches = true;
		List<ICondition> conditions = partitionCondition.getWith();
		if (conditions != null) {
			for (ICondition c : conditions) {
				IMatcher matcher = getMatcher(c);
				if (matcher != null && !matcher.matches(c, pipeline)) {
					matches = false;
				}
			}
		}
		return matches;
	}

	private IMatcher getMatcher(ICondition condition) {
		IMatcher matcher = null;
		if (condition instanceof FieldPresenceCondition) {
			matcher = new FieldPresenceConditionMatcher();
		} else if (condition instanceof TreeCondition) {
			matcher = new TreeConditionMatcher();

		}
		return matcher;
	}

	/* Metodo di appoggio per iterare su più chiavi di ordinamento */
	private int compareKeys(DocumentDefinition o1, DocumentDefinition o2, List<FieldReference> orderBy,
							List<Integer> versus, int index) {

		/* Permette di decidere l'ordine crescente o decrescente */
		int invert;

		if (versus.get(index) == 0)
			invert = 1;
		else
			invert = -1;

		Value v1 = o1.getValue(orderBy.get(index).getFieldName());
		Value v2 = o2.getValue(orderBy.get(index).getFieldName());

		if (v1 != null && v2 == null)
			return 1;
		else if (v1 == null && v2 == null)
			return 0;
		else if (v1 == null && v2 != null)
			return -1;

		else {

			if (!(v1 instanceof SimpleValue) || !(v2 instanceof SimpleValue))
				throw new RuntimeException("Not Comparable values: " + v1.getClass() + " and " + v2.getClass());

			SimpleValue sv1 = (SimpleValue) v1;
			SimpleValue sv2 = (SimpleValue) v2;

			/*
			 * Se due chiavi sono uguali e sono presenti un numero di chiavi >
			 * 1, il confronto prosegue sulla chiave successiva
			 */
			if (sv1.compareTo(sv2) != 0)
				return invert * sv1.compareTo(sv2);
			else if (orderBy.size() - 1 > index)
				return compareKeys(o1, o2, orderBy, versus, index + 1);
			else
				return 0;
		}
	}

}

class KeyValues {

	List<Value> values;

	public KeyValues(List<Value> values) {
		this.values = values;
	}

	@Override
	public String toString() {
		return values.toString();
	}

	public List<Value> getValues() {
		return values;
	}

	@Override
	public boolean equals(Object obj) {

		if (obj instanceof KeyValues) {

			boolean match = true;
			KeyValues v = (KeyValues) obj;
			List<Value> values2 = v.getValues();

			if (v.getValues().size() != values.size())
				return false;
			else {

				for (int i = 0; i < values.size(); i++) {

					if (values.get(i) == null && values2.get(i) == null)
						return true;

					if (values.get(i) == null || values2.get(i) == null)
						return false;

					if (!values.get(i).equals(values2.get(i))) {
						match = false;
						break;
					}

				}
			}
			return match;

		}
		return false;

	}

	@Override
	public int hashCode() {

		return values.hashCode();
	}

}
