package net.fm.geco.engine.evaluator;

import java.util.ArrayList;
import java.util.List;

import net.fm.geco.engine.Constants;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.command.KeepingDroppingFuzzySetsCommand;
import net.fm.geco.model.value.DocumentValue;


public class KeepingDroppingFuzzySetsEvaluator {

    public DocumentDefinition evaluate(DocumentDefinition document, KeepingDroppingFuzzySetsCommand keepingDroppingFuzzySetsCommand) {

        DocumentDefinition outDocument = null;
        List<FieldDefinition> fieldList = new ArrayList<>();
        DocumentDefinition fullDoc;
        List<FieldDefinition> fieldFuzzy = new ArrayList<>();

        int type = keepingDroppingFuzzySetsCommand.getType();
        // DROPPING
        if(type == 0) {
            if(document != null) {
                if(document.getValue(Constants.FUZZY_FIELD_NAME) == null) {
                    outDocument = document;
                } else {
                    DocumentDefinition ddFuzzy = new DocumentDefinition(((DocumentValue) document.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
                    for(FieldDefinition fd : document.getFields()) {
                        if(!fd.getName().equals(Constants.FUZZY_FIELD_NAME)) {
                            fieldList.add(fd);
                        } else {
                            for(FieldDefinition fdFuzzy : ddFuzzy.getFields()) {
                                boolean equals = false;
                                for(String s : keepingDroppingFuzzySetsCommand.getFuzzySets()) {
                                    if(fdFuzzy.getName().equals(s)) {
                                        equals = true;
                                    }
                                }
                                if(!equals) {
                                    fieldFuzzy.add(fdFuzzy);
                                }
                            }
                        }
                        fullDoc = new DocumentDefinition(fieldList);
                        if(fieldFuzzy.size() > 0) {
                            fullDoc.addField(new FieldDefinition(Constants.FUZZY_FIELD_NAME, new DocumentValue(fieldFuzzy)));
                        }
                        outDocument = fullDoc;
                    }
                }
            }
        }
        // KEEPING
        else if(type == 1) {
            if(document != null) {
                if(document.getValue(Constants.FUZZY_FIELD_NAME) == null) {
                    outDocument = document;
                } else {
                    DocumentDefinition ddFuzzy = new DocumentDefinition(((DocumentValue) document.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
                    for(FieldDefinition fd : document.getFields()) {
                        if(!fd.getName().equals(Constants.FUZZY_FIELD_NAME)) {
                            fieldList.add(fd);
                        } else {
                            for(FieldDefinition fdFuzzy : ddFuzzy.getFields()) {
                                for(String s : keepingDroppingFuzzySetsCommand.getFuzzySets()) {
                                    if(fdFuzzy.getName().equals(s)) {
                                        fieldFuzzy.add(fdFuzzy);
                                    }
                                }
                            }
                        }
                        fullDoc = new DocumentDefinition(fieldList);
                        if(fieldFuzzy.size() > 0) {
                            fullDoc.addField(new FieldDefinition(Constants.FUZZY_FIELD_NAME, new DocumentValue(fieldFuzzy)));
                        }
                        outDocument = fullDoc;
                    }
                }
            }
        }
        // DROPPING ALL
        else if(type == 2) {
            if(document != null) {
                for(FieldDefinition fd : document.getFields()) {
                    if(!fd.getName().equals(Constants.FUZZY_FIELD_NAME)) {
                        fieldList.add(fd);
                    }
                }
                outDocument = new DocumentDefinition(fieldList);
            }
        }
        // KEEPING ALL
        else if(type == 3) {
            outDocument = document;
        }

        return outDocument;
    }

}
