package net.fm.geco.engine.executor;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.command.ICommand;

public interface IExecutor<C extends ICommand> {
	
	public void execute(Pipeline pipeline, C command) throws ExecuteProcessException, ScriptException;

}
