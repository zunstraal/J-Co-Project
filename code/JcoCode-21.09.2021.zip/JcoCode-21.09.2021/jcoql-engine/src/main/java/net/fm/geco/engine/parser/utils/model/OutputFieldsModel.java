package net.fm.geco.engine.parser.utils.model;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import geco.model.util.ObjectStructure;
import geco.model.util.OutputFieldSpec;

public class OutputFieldsModel {

	/*
	 * Classe che include una lista che rappresenta tutti i possibili
	 * oggetti (di tipo FieldReference) trovati all'interno di una generate action del parser
	 *
	 * In pratica ognuno di questi alberi rappresenta l'oggetto-campo base da creare con
	 * tutti gli elementi che vengono forniti dal parser
	 *
	 * Esempio:
	 *
	 * GENERATE { .occhio.malocchio.a, .lol.pippo, .occhio.malocchio.b}
	 *
	 * Ci saranno, per costruzione, due alberi in questa lista, uno con chiave
	 * ".occhio" e l'altro con chiave ".lol"
	 *
	 * Con questa rappresentazione si può tenere traccia di oggetti che fanno
	 * parte dello stesso oggetto di base. Nella classe FieldStructureTree è
	 * inoltre presente l'algoritmo che "fonde" un albero esistente con un nuovo
	 * campo che deve appartenere appunto all'albero con la stessa chiave
	 * (quindi con lo stesso campo radice)
	 *
	 *
	 */
	List<FieldsStructureTree> treeList;


	/*
	 * Variabile che serve a distinguere il caso in cui il primo elemento della fieldList è
	 * in realtà l'alias..
	 * Esempio:
	 *
	 * buildings@test AS B
	 *
	 * quando si accede a .B.address bisogna ricordarsi che il primo elemento della lista
	 * è l'alias del doc della pipeline a cui accedere e non un campo
	 *
	 */
	boolean shift;

	public OutputFieldsModel(ObjectStructure objectStructure, boolean shift) {

		treeList = new ArrayList<>();
		this.shift = shift;
		initOutputFieldsModel(objectStructure);

	}

	/* Metodo di inizializzazione: serve a popolare l'oggetto treeList
	 * con le rappresentazione degli oggetti che fanno parte del documento finale
	 */
	public void initOutputFieldsModel(ObjectStructure objectStructure) {

		List<OutputFieldSpec> outputFieldSpec = objectStructure.outputList;
		OutputFieldSpec def;

		/*
		 * Vengono analizzati tutti gli oggetti che fanno parte
		 * dell'outputFieldSpec però vengono trattati solo quelli di tipo 0,
		 * ovvero che sono FieldReference (sia annidati che non annidati)
		 */
		for (int i = 0; i < outputFieldSpec.size(); i++) {
			def = outputFieldSpec.get(i);

			if (def.getOutputFieldSpecType() == OutputFieldSpec.FIELD_REF ) {

				/*
				 * *** Algoritmo di ricerca dell'albero con chiave pari al campo
				 * in prima posizione dato dall'oggetto def ***
				 *
				 * Se l'albero viene trovato si lavora su quello e si modifica
				 * in modo da poter includere l'oggetto corrente, indipendemente
				 * da come e da dove è annidato
				 *
				 * Se l'albero non viene trovato se ne crea uno nuovo e si
				 * rappresenta l'oggetto corrente come albero e poi si aggiunge
				 * alla lista treeList come nuovo
				 */

				boolean found = false;

				/* Se la lista è vuota si aggiunge semplicemente */
				if (treeList.isEmpty()) {
					FieldsStructureTree tree;

					if(shift){
						tree = new FieldsStructureTree(def.fieldRef.fields.get(1));
						tree.FieldList2Tree(def.fieldRef.fields.subList(1, def.fieldRef.fields.size()), def.toString());
					}
					else{
						tree = new FieldsStructureTree(def.fieldRef.fields.get(0));
						tree.FieldList2Tree(def.fieldRef.fields, def.toString());
					}

					treeList.add(tree);

				} else {

					ListIterator<FieldsStructureTree> litr = treeList.listIterator();
					int index = 0;

					/*
					 * Si cerca, nella lista, un albero che come chiave ha lo
					 * stesso campo base dell'oggetto corrente che si vuole
					 * aggiungere
					 */

					int shiftINT;
					if(shift)
						shiftINT = 1;
					else
						shiftINT = 0;

					while (litr.hasNext()) {

						FieldsStructureTree treeTemp = litr.next();

						/*
						 * Se viene trovato un albero con stessa chiave del
						 * campo base attuale prima si preleva l'albero, lo si
						 * rimuove dalla lista, lo si modifica e infine lo si
						 * riaggiunge modificato in base a quello che gli è
						 * arrivato. La variabile index serve a mantenere
						 * l'ordine degli alberi in modo che stiano sempre nella
						 * stessa posizione
						 */




						if (treeTemp.getKey().equals(def.fieldRef.fields.get(shiftINT))) {

							found = true;
							treeList.remove(treeTemp);
							if(shift){
								treeTemp.FieldList2Tree(def.fieldRef.fields.subList(1, def.fieldRef.fields.size()), def.toString());
							}
							else{
								treeTemp.FieldList2Tree(def.fieldRef.fields, def.toString());
							}							treeList.add(index, treeTemp);
							break;
						}

						index++;

					}

					/*
					 * Se non ha trovato un albero a cui aggiungere l'oggetto (e
					 * la lista NON è vuota) si crea un nuovo albero e si
					 * aggiunge
					 */
					if (!found) {

						FieldsStructureTree tree;
						if(shift){
							tree = new FieldsStructureTree(def.fieldRef.fields.get(1));
							tree.FieldList2Tree(def.fieldRef.fields.subList(1, def.fieldRef.fields.size()), def.toString());
						}
						else{
							tree = new FieldsStructureTree(def.fieldRef.fields.get(0));
							tree.FieldList2Tree(def.fieldRef.fields, def.toString());
						}						treeList.add(tree);

					}

				}

			}
		}

	}

	public List<FieldsStructureTree> getTreeList() {
		return treeList;
	}

	/* Metodo d'aiuto che stampa gli alberi */
	public void printOutputModel() {

		if (treeList.isEmpty()) {
// PF - add something to handle the case es:  System.out.println("The list is empty");
			;
		} else {

			for (int i = 0; i < treeList.size(); i++) {
				treeList.get(i).printTree();
			}
		}

	}

}
