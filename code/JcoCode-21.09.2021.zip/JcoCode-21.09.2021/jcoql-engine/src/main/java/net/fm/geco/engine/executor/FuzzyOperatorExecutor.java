package net.fm.geco.engine.executor;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.FuzzyOp;
import net.fm.geco.model.command.FuzzyOperatorCommand;


@Executor(FuzzyOperatorCommand.class)
public class FuzzyOperatorExecutor implements IExecutor<FuzzyOperatorCommand> {

    @Override
    public void execute(Pipeline pipeline, FuzzyOperatorCommand command) throws ExecuteProcessException {
        if(alreadyExists(pipeline, command)) {
            throw new ExecuteProcessException("[CREATE FUZZY OPERATOR]: Fuzzy Operator \"" + command.getFuzzyOperatorName() + "\" already exist!");
        } else {
/* PF. What is for?        	
        	for (ICondition ic:command.getPrecondition().getConditions()) {
        		// PF - a che serve?
        		TreeCondition t = (TreeCondition)ic;
        	}
*/        	
            FuzzyOp fop = new FuzzyOp(command.getFuzzyOperatorName(), command.getParameters(),
                    command.getPrecondition(), command.getEvaluate(), command.getRange(), command.getPolyline());
            pipeline.addFuzzyOperator(fop);
        }
    }

    // verifica che il nuovo operatore non abbia un nome già in uso da un altro operatore
    private boolean alreadyExists(Pipeline pipeline, FuzzyOperatorCommand command) {
        for(int i = 0; i < pipeline.getFuzzyOperators().size(); i++) {
            if(pipeline.getFuzzyOperators().get(i).equals(command.getFuzzyOperatorName(), command.getParameters())) {
                return true;
            }
        }
        return false;
    }
}
