package net.fm.geco.engine.evaluator;

import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.CoordinateSequence;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryCollection;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.PrecisionModel;
import org.locationtech.jts.geom.impl.CoordinateArraySequence;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.GeometryDefinition;
import net.fm.geco.model.command.EGeometryAction;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.value.ArrayValue;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class GenerateCommandEvaluator {

	public DocumentDefinition evaluate(Pipeline pipeline, GenerateCommand generate) {
		List<FieldDefinition> fields = new ArrayList<FieldDefinition>();
		FieldEvaluator fieldEvaluator = new FieldEvaluator();

		if (generate.getOutputDefinition() != null) {
			List<FieldDefinition> docFields = generate.getOutputDefinition().getFields();

			if (docFields != null) {
				for (FieldDefinition field : docFields) {
					if (field.getValue().getType() == EValueType.DOCUMENT) {
						DocumentValue docValue = evaluate(pipeline, ((DocumentValue) field.getValue()).getFields());
						fields.add(new FieldDefinition(field.getName(), docValue));
					} 
					else if (field.getValue().getType() == EValueType.BUILT_IN_FUNCTION) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.COUNT) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.TO_INT_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.TO_FLOAT_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.TO_STRING_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.TO_BOOL_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.TO_SERIALIZE_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.MEMBERSHIP_OF_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else if (field.getValue().getType() == EValueType.TRANSLATE_FIELD) {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					} 
					else {
						fields.add(new FieldDefinition(field.getName(), fieldEvaluator.evaluate(pipeline, field.getValue())));
					}
				}
			}

		} else {
			DocumentDefinition initialDoc = pipeline.getAsDocument();
			if(initialDoc.getFields().size() == 1) {
				fields.addAll(((DocumentValue)initialDoc.getFields().get(0).getValue()).getFields());
			} else if(initialDoc.getFields().size() == 2) {
				String fieldNameLeft = initialDoc.getFields().get(0).getName();
				String fieldNameRight = initialDoc.getFields().get(1).getName();

				fields.add(new FieldDefinition(fieldNameLeft, ((DocumentValue)initialDoc.getFields().get(0).getValue())));
				fields.add(new FieldDefinition(fieldNameRight,((DocumentValue)initialDoc.getFields().get(1).getValue())));
			}

			/* E' necessario rimuovere il campo geometry prima di proseguire */
			for (int i = 0; i < fields.size(); i++) {
				if(fields.get(i).getName().equals(Constants.GEOMETRY_FIELD_NAME)) {
					fields.remove(i);
				}
			}
		}

		final EGeometryAction geometryAction = generate.getGeometryAction();

		if (EGeometryAction.KEEP == geometryAction) {
			
			fields.add(new FieldDefinition(
								Constants.GEOMETRY_FIELD_NAME,
								fieldEvaluator.evaluate(
										pipeline,
										new FieldValue(pipeline.getCurrentCollectionName(), Constants.GEOMETRY_FIELD_NAME)
								)
							)
					);

		} else if (EGeometryAction.GENERATE == geometryAction) {
			GeometryDefinition geoDef = generate.getGeometry();
			Geometry geometry;

			if(geoDef!=null) {

				if(geoDef.getType() == GeometryDefinition.POINT) {

					Coordinate[] coordinates = new Coordinate[1];

					Value lat = fieldEvaluator.evaluate(pipeline, new FieldValue(geoDef.getLatitude()));
					Value lon = fieldEvaluator.evaluate(pipeline, new FieldValue(geoDef.getLongitude()));

					if(lat == null || lon == null) {
						throw new RuntimeException("Null coordinates are not allowed");
					}

					if(lat instanceof SimpleValue && lon instanceof SimpleValue) {

						if((((SimpleValue)lat).getType() == EValueType.DECIMAL || ((SimpleValue)lat).getType() == EValueType.INTEGER) &&
								(((SimpleValue)lon).getType() == EValueType.DECIMAL || ((SimpleValue)lon).getType() == EValueType.INTEGER)) {

							coordinates[0] = new Coordinate(getCoordinate((SimpleValue)lon),getCoordinate((SimpleValue)lat));
							CoordinateSequence s = new CoordinateArraySequence(coordinates, 1);
							geometry = new Point(s, new GeometryFactory(new PrecisionModel(), 0));

							fields.add(new FieldDefinition(Constants.GEOMETRY_FIELD_NAME, new GeoJsonValue(geometry)));
						}
					}else {
						throw new RuntimeException("Illegal value types for coordinates: " + lat.getType().toString() + " "+ lon.getType().toString() );
					}

				}else if(geoDef.getType() == GeometryDefinition.FIELD_REF) {
					Value g = fieldEvaluator.evaluateGeometry(pipeline, new FieldValue(geoDef.getField()));

					if(g!=null) {
						if(g instanceof GeoJsonValue) {
							fields.add(new FieldDefinition(Constants.GEOMETRY_FIELD_NAME, g));
						}
//						else
//							throw new RuntimeException("Input field type: " + g.getType().toString() + " is not a GEOMETRY");
					} else {
						throw new RuntimeException("Value "+ geoDef.getField() + " is not a geometry or does not exist");
					}


				} else if(geoDef.getType() == GeometryDefinition.AGGREGATE) {

					GeometryCollection collection;
					Geometry[] geometries;
					List<Geometry> listGeometries = new ArrayList<>();
					Value v = fieldEvaluator.evaluate(pipeline, new FieldValue(geoDef.getField()));

					if(v !=null) {

						if(v instanceof ArrayValue) {
							List<Value> values = ((ArrayValue)v).getValues();

							for (Value value : values) {
								if(value instanceof DocumentValue) {
									GeoJsonValue temp = (GeoJsonValue)((DocumentValue)value).getValue(FieldName.fromString(Constants.GEOMETRY_FIELD_NAME));
									listGeometries.add(temp.getGeometry());
								}
							}
							if(!listGeometries.isEmpty()){
								geometries = listGeometries.toArray(new Geometry[listGeometries.size()]);
								collection = new GeometryCollection(geometries, new GeometryFactory(new PrecisionModel(), 0));

								fields.add(new FieldDefinition(Constants.GEOMETRY_FIELD_NAME, new GeoJsonValue(collection)));
							}
						} else {
							throw new RuntimeException("Illegal type for the aggregate operation: " + v.getType().toString());
						}

					}
				} else if(geoDef.getType() == GeometryDefinition.TO_POLYLINE) {

					Geometry lineString;
					Coordinate[] coordinates;
					List<Coordinate> listCoordinate = new ArrayList<>();

					Value v = fieldEvaluator.evaluate(pipeline, new FieldValue(geoDef.getField()));

					if(v !=null) {
						if(v instanceof ArrayValue) {

							List<Value> values = ((ArrayValue)v).getValues();
							for (Value value : values) {
								if(value instanceof DocumentValue) {
									GeoJsonValue temp = (GeoJsonValue)((DocumentValue)value).getValue(FieldName.fromString(Constants.GEOMETRY_FIELD_NAME));
									listCoordinate.add(new Coordinate(temp.getGeometry().getCentroid().getX(), temp.getGeometry().getCentroid().getY()));
								}
							}

							if(!listCoordinate.isEmpty()){
								coordinates = listCoordinate.toArray(new Coordinate[listCoordinate.size()]);
								CoordinateSequence sequence =  new CoordinateArraySequence(coordinates);
								//collection = new GeometryCollection(geometries, new GeometryFactory(new PrecisionModel(), 0));
								lineString = new LineString(sequence, new GeometryFactory(new PrecisionModel(), 0));

								fields.add(new FieldDefinition(Constants.GEOMETRY_FIELD_NAME, new GeoJsonValue(lineString)));
							}

						} else {
							throw new RuntimeException("Illegal type for the polyline operation: " + v.getType().toString());
						}
					}
				} else {
					throw new RuntimeException("Value "+ geoDef.getField() + " does not exist");
				}
			}

		}
		// It's not needed to handle EGEometryAction.DROP because by default
		// no geometry field is added to the output document
		return new DocumentDefinition(fields);
	}

	public DocumentValue evaluate(Pipeline pipeline, List<FieldDefinition> docFields) {
		List<FieldDefinition> fields = new ArrayList<FieldDefinition>();
		FieldEvaluator fieldEvaluator = new FieldEvaluator();

		if (docFields != null) {
			for (FieldDefinition field : docFields) {
				if (field.getValue().getType() == EValueType.DOCUMENT) {
					DocumentValue docValue = evaluate(pipeline, ((DocumentValue) field.getValue()).getFields());
					fields.add(new FieldDefinition(field.getName(), docValue));

				} else {
					Value vl = fieldEvaluator.evaluate(pipeline, field.getValue());
					if (vl != null) {

						if (field.getValue().getType() != EValueType.ROOTABLE_FIELD) {
							fields.add(new FieldDefinition(field.getName(), vl));
						}
// PF - ELSE added to handle Rootable elements
						else {
							if (vl.getType() == EValueType.DOCUMENT) {
								List<FieldDefinition> df;
								df = ((DocumentValue) vl).getFields();
								if (df != null) {
									for (FieldDefinition ff : df) {
										Value vl2 = fieldEvaluator.evaluate(pipeline, ff.getValue());
										fields.add(new FieldDefinition(ff.getName(), vl2));
									}
								}
							}
						}
					}
				}
			}

		}

		return new DocumentValue(fields);
	}

	private double getCoordinate(SimpleValue v) {
		if(v.getType() == EValueType.DECIMAL) {
			return (Double)(v.getValue());
		} else if(v.getType() == EValueType.INTEGER) {
			return (Long)(v.getValue());
		} else {
			throw new RuntimeException("Illegal type for a coordinate: "+v.getType().toString());
		}
	}
}
