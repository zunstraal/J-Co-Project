package net.fm.geco.engine.evaluator;

import java.util.List;

import org.locationtech.jts.geom.Geometry;

import geco.model.fuzzy.FuzzySetDefinitionElement;
import net.fm.geco.engine.Constants;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.command.SetFuzzySetsCommand;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

// PF. rewritten on 16.07.2021
public class SetFuzzySetsEvaluator {


	private void insertField (DocumentDefinition doc, FieldDefinition f, String newName, int policy) {
		if (f != null && f.getValue() != null &&
				(f.getValue().getType() == EValueType.DECIMAL || f.getValue().getType() == EValueType.INTEGER)) {

			// insert FIRST value
			if (!doc.hasField(newName))
				doc.addField(new FieldDefinition(newName, f.getValue()));
			else {
				// insert LAST value
				if (policy == SetFuzzySetsCommand.POLICY_LAST)
					doc.addField(new FieldDefinition(newName, f.getValue()));
				// insert MIN value
				else if (policy == SetFuzzySetsCommand.POLICY_AND || policy == SetFuzzySetsCommand.POLICY_DEFAULT) {					
					SimpleValue newValue = (SimpleValue)f.getValue();
					SimpleValue oldValue = (SimpleValue) doc.getValue(newName);		
					if (newValue.compareTo(oldValue) < 0) 
						doc.addField(new FieldDefinition(newName, f.getValue()));
				}
				// insert MAX value
				else if (policy == SetFuzzySetsCommand.POLICY_OR) {
					SimpleValue newValue = (SimpleValue)f.getValue();
					SimpleValue oldValue = (SimpleValue) doc.getValue(newName);		
					if (newValue.compareTo(oldValue) > 0) 
						doc.addField(new FieldDefinition(newName, f.getValue()));
				}
			}
		}
	}
    public List<FieldDefinition> evaluate(DocumentDefinition ld, DocumentDefinition rd, SetFuzzySetsCommand setFuzzySetsCommand) {
    	DocumentDefinition fuzzyLeftDoc = null;
    	DocumentDefinition fuzzyRightDoc = null;
    	if (ld.getValue(Constants.FUZZY_FIELD_NAME) != null)    	
    		fuzzyLeftDoc = new DocumentDefinition (((DocumentValue) ld.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
        if (rd.getValue(Constants.FUZZY_FIELD_NAME) != null)
    		fuzzyRightDoc = new DocumentDefinition (((DocumentValue) rd.getValue(Constants.FUZZY_FIELD_NAME)).getFields());

    	DocumentDefinition outDoc =  new DocumentDefinition(Constants.FUZZY_FIELD_NAME);

    	if (setFuzzySetsCommand.setType == SetFuzzySetsCommand.KEEP_ALL) {
    		if (fuzzyLeftDoc != null)
    			for (int i=0; i<fuzzyLeftDoc.getFields().size(); i++)
    				insertField (outDoc, fuzzyLeftDoc.getFields().get(i), fuzzyLeftDoc.getFields().get(i).getName(), setFuzzySetsCommand.policyType);    		
    		if (fuzzyRightDoc != null)
    			for (int i=0; i<fuzzyRightDoc.getFields().size(); i++)
    				insertField (outDoc, fuzzyRightDoc.getFields().get(i), fuzzyRightDoc.getFields().get(i).getName(), setFuzzySetsCommand.policyType);    		    			
    	}

    	else if (setFuzzySetsCommand.setType == SetFuzzySetsCommand.KEEP_LEFT) {
    		if (fuzzyLeftDoc != null)
    			for (int i=0; i<fuzzyLeftDoc.getFields().size(); i++)
    				insertField (outDoc, fuzzyLeftDoc.getFields().get(i), fuzzyLeftDoc.getFields().get(i).getName(), setFuzzySetsCommand.policyType);    		
    				    	}

    	else if (setFuzzySetsCommand.setType == SetFuzzySetsCommand.KEEP_RIGHT) {
    		if (fuzzyRightDoc != null)
    			for (int i=0; i<fuzzyRightDoc.getFields().size(); i++)
    				insertField (outDoc, fuzzyRightDoc.getFields().get(i), fuzzyRightDoc.getFields().get(i).getName(), setFuzzySetsCommand.policyType);    		    			
    	}

    	else if (setFuzzySetsCommand.setType == SetFuzzySetsCommand.DEFINITION_LIST) {
    		for (int j=0; j<setFuzzySetsCommand.fuzzySetsList.size(); j++) {
    			FuzzySetDefinitionElement fsde = setFuzzySetsCommand.fuzzySetsList.get(j);
    			// Non-Function case
    			if (!fsde.isFunction()) {
    				DocumentDefinition fuzzyDoc = fuzzyLeftDoc;
    				if (fsde.isRight())
    					fuzzyDoc = fuzzyRightDoc;
    				if (fuzzyDoc != null)
	    				if (fsde.allSide()) {
	    	    			for (int i=0; i<fuzzyDoc.getFields().size(); i++)
	    	    				insertField (outDoc, fuzzyDoc.getFields().get(i), fuzzyDoc.getFields().get(i).getName(), setFuzzySetsCommand.policyType);    		    			
	    				}
	    				else if (fuzzyDoc.hasField(fsde.sourceFuzzySet)){
	    					String newName = fsde.sourceFuzzySet;
	    					if (fsde.hasNewName())
	    						newName = fsde.newFuzzySet;
		    				insertField (outDoc, fuzzyDoc.getField(fsde.sourceFuzzySet), newName, setFuzzySetsCommand.policyType);    		    			
	    				}
    			}
    			// Function case
    			else {
                    GeoJsonValue lgj = (GeoJsonValue) ld.getValue(Constants.GEOMETRY_FIELD_NAME);
                    GeoJsonValue rgj = (GeoJsonValue) rd.getValue(Constants.GEOMETRY_FIELD_NAME);

                	if(lgj != null && rgj != null) {
	                    Geometry lg = lgj.getGeometry();
	                    Geometry rg = rgj.getGeometry();	
	                    double value = 0;
	
	                	if(lg != null && rg != null) {
		                    // HOW-MEET
		                    if(fsde.isHowMeetFunction()) {
			                    Geometry boundaryLeft = lg.getBoundary();
			                    Geometry boundaryRight = rg.getBoundary();
		                        if(!boundaryLeft.isEmpty() && !boundaryRight.isEmpty()) {
		                        	if (fsde.isLeft() && boundaryLeft.getLength() != 0) {
		                                value = (boundaryLeft.intersection(boundaryRight)).getLength() / boundaryLeft.getLength();
		                            }
		                            if(fsde.isRight()  && boundaryRight.getLength() != 0) {
		                                value = (boundaryLeft.intersection(boundaryRight)).getLength() / boundaryRight.getLength();
		                            }
		                        }	
		                    }
		                    // INSIDE
		                    else if(fsde.isInsideFunction()) {
		                        Geometry intersect = lg.intersection(rg);
		                        if(fsde.isLeft() && lg.getArea() != 0) {
		                            value = intersect.getArea() / lg.getArea();
		                        }
		                        if(fsde.isRight() && rg.getArea() != 0) {
		                            value = intersect.getArea() / rg.getArea();
		                        }
		                    }
			                // OVERLAP
		                    else if(fsde.isOverlapFunction()) {
		                        Geometry intersect = lg.intersection(rg);
		                        Geometry union = lg.union(rg);
		
		                        if(union.getArea() != 0) {
		                            value = intersect.getArea() / union.getArea();		
		                        }
		                    }
	                    }
	        			Value v = new SimpleValue(value);
	    				insertField (outDoc, new FieldDefinition(fsde.newFuzzySet, v), fsde.newFuzzySet, setFuzzySetsCommand.policyType);    		    			
                	}
        		}
    		}
    			
    	}

    	return outDoc.getFields();

    }

}
