package net.fm.geco.engine.matcher.join;

import org.locationtech.jts.geom.Geometry;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.join.EFrom;
import net.fm.geco.model.condition.join.OrientationJoinCondition;
import net.fm.geco.model.value.GeoJsonValue;

public class OrientationJoinConditionMatcher implements IMatcher {

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {

		OrientationJoinCondition o = (OrientationJoinCondition) condition;

		GeoJsonValue lgj = (GeoJsonValue) pipeline.get(Constants.LEFT_DOCUMENT_ALIAS);
		GeoJsonValue rgj = (GeoJsonValue) pipeline.get(Constants.RIGHT_DOCUMENT_ALIAS);

		Geometry lg = lgj.getGeometry();
		Geometry rg = rgj.getGeometry();
		double angle;
		double angleDiff;

		if (o.getFromOrientation() == EFrom.RIGHT) {
			angle = angleFromCoordinate(Math.toRadians(lg.getCentroid().getY()),
					Math.toRadians(lg.getCentroid().getX()), Math.toRadians(rg.getCentroid().getY()),
					Math.toRadians(rg.getCentroid().getX()));
		} else {
			angle = angleFromCoordinate(Math.toRadians(rg.getCentroid().getY()),
					Math.toRadians(rg.getCentroid().getX()), Math.toRadians(lg.getCentroid().getY()),
					Math.toRadians(lg.getCentroid().getX()));
		}

		/*
		 * https://stackoverflow.com/questions/12234574/calculating-if-an-angle-is-between-two-angles
		 */

		angleDiff = (o.getOrientation().getOrientation() - angle + 180 + 360) % 360 - 180;

		return ((-o.getDelta() <= angleDiff) && angleDiff <= o.getDelta());

	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		return 0;
	}

	public double angleFromCoordinate(double lat1, double long1, double lat2, double long2) {

		double dLon = (long2 - long1);

		double y = Math.sin(dLon) * Math.cos(lat2);
		double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

		double brng = Math.atan2(y, x);

		brng = Math.toDegrees(brng);
		brng = (brng + 360) % 360;

		return brng;
	}
}
