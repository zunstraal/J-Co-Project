package net.fm.geco.engine.server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.net.Socket;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import net.fm.geco.engine.parser.Parser;
import net.fm.geco.model.engine.IDocumentCollection;

public class ServerRunnable implements Runnable {

	protected Socket clientSocket;
	private DataInputStream din;
	private DataOutputStream dout;
	private Parser p;
	protected ServerMessages msg;

	public ServerRunnable(Socket clientSocket) throws IOException {
		this.clientSocket = clientSocket;
		p = new Parser();
		msg = new ServerMessages();
	}

	@Override
	public void run() {

		try {
			din = new DataInputStream(clientSocket.getInputStream());
			dout = new DataOutputStream(clientSocket.getOutputStream());

			// invio al client la lista dei server disponibili in formato JSON
			sendMessage(msg.getMsgServerConf(p.getConfigurations()));

			while (true) {
				if (din.available() > 0) {
					// leggo la prima riga
					decoder(din.readUTF());

				} else {
					Thread.sleep(500);
				}
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}


	private void decoder(String s) {
		BufferedReader br = new BufferedReader(new StringReader(s));
		String text;
		try {
			text = br.readLine();
			if (text.equals("##BEGIN-PROCESS##")) {

				// togli inizio e fine del messaggio
				int firstindex = text.length();
				int lastindex = s.lastIndexOf("##END-PROCESS##");
				String istr = s.substring(firstindex, lastindex-1);

				LinkedList<String> istructions = new LinkedList<>();
				istructions = istructionSeparator("", istr, istructions);
// PF - parser launching
				p.parse(istructions);
				// se arrivo qui non ci sono stati errori nell'esecuzione
				sendMessage(msg.getMsgSuccessExecuteJCO());
				sendMessage(msg.getMsgProcess(p.getProcess()));

			} else if (text.equals("##BACKTRACK##")) {
				p.backtrack();
				// se arrivo qui non ci sono stati errori nell'esecuzione
				sendMessage(msg.getAck());
				sendMessage(msg.getMsgProcess(p.getProcess()));

			} else if (text.equals("##GET-TEMPORARY-COLLECTION##")) {
				IDocumentCollection collection = p.getTemporaryCollection();
				sendMessage(msg.getMsgCollection(collection.toString()));

			} else if (text.equals("##GET-PROCESS##")) {
				List<String> process = p.getProcess();
				sendMessage(msg.getMsgProcess(process));

			} else if (text.equals("##GET-IR-LIST##")) {
				Collection<String> irlist = p.getIRList();
				sendMessage(msg.getMsgIRList(irlist));

			} else if (text.equals("##GET-IR-COLLECTION##")) {
				String collectionName = br.readLine();
				IDocumentCollection collection = p.getIRCollection(collectionName);
				sendMessage(msg.getMsgCollection(collection.toString()));

			} else if (text.equals("##ADD-SERVER-CONF##")) {
				int firstindex = text.length();
				int lastindex = s.lastIndexOf("##END-SERVER-CONF##");
				p.addServer(s.substring(firstindex, lastindex));
				// rispondo con la nuova lista dei server disponibili
				sendMessage(msg.getMsgServerConf(p.getConfigurations()));
			}

		} catch (Exception e) {
			sendMessage(msg.getMsgErrorExecuteJCO(e.getMessage()));
			sendMessage(msg.getMsgProcess(p.getProcess()));
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static LinkedList<String> istructionSeparator(String istr, String allIstr, LinkedList<String> istructions) {

		int semicolon = allIstr.indexOf(";");
		int quote = allIstr.indexOf("\"");
		int indexBodyStart = allIstr.indexOf("BODY");
		int indexBodyEnd = allIstr.indexOf("END BODY");

		while (semicolon != -1) {
			if (quote == -1 || semicolon < quote) {
				if (semicolon > indexBodyStart && semicolon < indexBodyEnd) {
					istr = istr + allIstr.substring(0, indexBodyEnd + 9);
					allIstr = allIstr.substring(indexBodyEnd + 9, allIstr.length());
					istructions.add(istr.trim());
					istr = "";
				} else {
					istr = istr + allIstr.substring(0, semicolon + 1);
					allIstr = allIstr.substring(semicolon + 1, allIstr.length());
					istructions.add(istr.trim());
					istr = "";
				}
			} else {
				if (semicolon > indexBodyStart && semicolon < indexBodyEnd) {
					istr = istr + allIstr.substring(0, indexBodyEnd + 9);
					allIstr = allIstr.substring(indexBodyEnd + 9, allIstr.length());
					istructions.add(istr.trim());
					istr = "";
				} else {
					istr = istr + allIstr.substring(0, semicolon + 1);
					allIstr = allIstr.substring(semicolon + 1, allIstr.length());
					istructions.add(istr.trim());
					istr = "";
				}
				/*
				System.out.println("else");
				istr = allIstr.substring(0, quote + 1);
				allIstr = allIstr.substring(quote + 1, allIstr.length());
				quote = allIstr.indexOf("\"");
				istr = istr + allIstr.substring(0, quote + 1);
				allIstr = allIstr.substring(quote + 1, allIstr.length());
				*/
			}
			semicolon = allIstr.indexOf(";");
			quote = allIstr.indexOf("\"");
			indexBodyStart = allIstr.indexOf("BODY");
			indexBodyEnd = allIstr.indexOf("END BODY");
		}

		return istructions;
	}

	public void sendMessage(String msg) {
		try {
			byte[] data = msg.getBytes("UTF-8");
			dout.writeInt(data.length);
			dout.write(data);

			//dout.writeUTF(msg);
			dout.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
