package net.fm.geco.engine.executor;

import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.executor.utils.SynchronizedDuplicateRemover;
import net.fm.geco.engine.executor.utils.SynchronizedSpatialJoinCycle;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.SpatialJoinCommand;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;
import net.fm.geco.model.engine.SimpleDocumentCollection;

@Executor(SpatialJoinCommand.class)
public class SpatialJoinExecutor implements IExecutor<SpatialJoinCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public SpatialJoinExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}



	@Override
	public void execute(Pipeline pipeline, SpatialJoinCommand command) throws ExecuteProcessException {
//	PF
		LinkedBlockingQueue<DocumentDefinition> queue = new LinkedBlockingQueue<DocumentDefinition>();
		SynchronizedDuplicateRemover sdr = new SynchronizedDuplicateRemover(queue, command.isRemoveDuplicates());
		sdr.start();
//	PF	end

		final SimpleDocumentCollection outCollection;
		final IDocumentCollection leftCollection;
		final IDocumentCollection rightCollection;

		IDatabase database;

		String dbNameLeft = command.getLeftCollection().getDatabaseName();
		String dbNameRight = command.getRightCollection().getDatabaseName();

		if(dbNameLeft!=null){
			database = databaseRegistry.getDatabase(dbNameLeft);
			if (database == null) {
				throw new ExecuteProcessException("[SPATIAL JOIN]: Invalid database " + dbNameLeft);
			}
			leftCollection = database.getCollection(command.getLeftCollection().getCollectionName());
			pipeline.add(leftCollection, command.getLeftCollection().getCollectionName());
		}
		else{
			leftCollection = pipeline.getCollection(command.getLeftCollection().getCollectionName());
		}

		if(dbNameRight!=null){
			database = databaseRegistry.getDatabase(dbNameRight);
			if (database == null) {
				throw new ExecuteProcessException("[SPATIAL JOIN]: Invalid database " + dbNameRight);
			}
			rightCollection = database.getCollection(command.getRightCollection().getCollectionName());
			pipeline.add(rightCollection, command.getRightCollection().getCollectionName());
		}
		else{
			rightCollection = pipeline.getCollection(command.getRightCollection().getCollectionName());
		}


		if(leftCollection != null && rightCollection != null) {
			/* PF. ok */
			List<DocumentDefinition> leftDocs = leftCollection.getDocument();
			List<DocumentDefinition> rightDocs = rightCollection.getDocument();
			// PF. set SDR size
			sdr.setDimensions(leftDocs.size(), rightDocs.size());

			// PF - first foreach cycle is sequential. the 2nd is parallel
			for (DocumentDefinition ld : leftDocs) {			/* substitution */
				// PF threads declaration
				SynchronizedSpatialJoinCycle[] threads;
				int nThreads = 1;
				//PF per il filter uso tutti i processori fisici meno uno
				if (Constants.getInstance().getNProcessors() > 1)
					nThreads = Constants.getInstance().getNProcessors()-1;

				// PF threads creation
				threads = new SynchronizedSpatialJoinCycle[nThreads];
				for (int i=0; i<nThreads; i++)
					threads[i] = new SynchronizedSpatialJoinCycle(i, nThreads, ld, rightDocs, queue, command);

				// PF threads launching
				for (int i=0; i<nThreads; i++)
					threads[i].start();

				// PF thread synchro
				for (int i=0; i<nThreads; i++)
					try {
						threads[i].join();
					} catch (InterruptedException e) {
						throw new ExecuteProcessException("[SPATIAL JOIN]: Failed Thread Sychronization");
					}

			}
		}

		// GET the final collection and return it
		sdr.interrupt();
		try {
			sdr.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ExecuteProcessException("[FILTER]: Failed Remover Thread Sychronization");
		}
		List<DocumentDefinition> outDocs = sdr.getDocs();

		outCollection = new SimpleDocumentCollection("SpatialJoin", outDocs);
		pipeline.addCollection(outCollection);
	}

}
