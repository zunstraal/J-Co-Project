package net.fm.geco.engine.executor;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.command.JavascriptFunctionCommand;


@Executor(JavascriptFunctionCommand.class)
public class JavascriptFunctionExecutor implements IExecutor<JavascriptFunctionCommand> {
    @Override
    public void execute(Pipeline pipeline, JavascriptFunctionCommand command) throws ExecuteProcessException {
        // IDocumentCollection collection = pipeline.getCurrentCollection();
        if(alreadyExists(pipeline, command)) {
            throw new ExecuteProcessException("[CREATE JAVASCRIPT FUNCTION]: JavaScript function \"" + command.getJsFunction().getFunctionName() + "\" already exist!");
        } else {
            pipeline.addJsFunction(command.getJsFunction());
            /*new JSFunction(command.getJsFunction().getFunctionName(),
                    command.getJsFunction().getParameters(), command.getJsFunction().getPreCondition(),
                    command.getJsFunction().getBody()));*/
        }
    }

    // verifica che la nuova funzione js non abbia un nome già in uso da un'altra funzione
    private boolean alreadyExists(Pipeline pipeline, JavascriptFunctionCommand command) {
        for(int i = 0; i < pipeline.getJsFunction().size(); i++) {
            if(pipeline.getJsFunction().get(i).equals(command.getJsFunction().getFunctionName(), command.getJsFunction().getParameters())) {
                return true;
            }
        }
        return false;
    }
}
