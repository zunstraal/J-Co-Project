package net.fm.geco.engine.evaluator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import geco.model.util.Expression;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.OperationConditionMatcher;
import net.fm.geco.engine.matcher.TreeConditionMatcher;
import net.fm.geco.model.JSFunction;
import net.fm.geco.model.ParameterDefinition;
import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.tree.TreeCondition;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FunctionJsValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class JSFunctionEvaluator {

    private List<Value> listValue;

    public Value evaluate(FunctionJsValue function, Pipeline pipeline) throws ScriptException {

        JSFunction jsFun = getJsFunction(function.getFunctionName(), function.getParameters(), pipeline);

        for(int i = 0; i < listValue.size(); i++) {
            pipeline.addParametersMap(jsFun.getParameters().get(i).getName(), listValue.get(i));
        }

        if(jsFun != null) {
            if(checkPrecondition(jsFun, pipeline)) {
                // qui calcolo il valore della funzione
                ScriptEngineManager manager = new ScriptEngineManager();
                ScriptEngine engine = manager.getEngineByName("JavaScript");
                try {
                    String resultJs = engine.eval(codeToString(jsFun, listValue, pipeline)).toString();
                    return new SimpleValue(Double.parseDouble(resultJs));
                } catch (ScriptException e) {
                    //e.printStackTrace();
                    return null;
                }
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    private boolean checkPrecondition(JSFunction jsf, Pipeline pipeline) throws ScriptException {

        boolean matchPrecondition = true;

		// PF. "if" added on 18.05.2021 after deciding that PRECONDITIONS are optional
		if (jsf.getPreCondition() != null)        
	        for(ICondition precondition : jsf.getPreCondition().getConditions()) {
	            IMatcher matcher = getMatcher(precondition);
	            if(matcher != null && !matcher.matches(precondition, pipeline)) {
	                matchPrecondition = false;
	            }
	        }

        return matchPrecondition;
    }

    private String codeToString(JSFunction jsFun, List<Value> values, Pipeline pipeline) {
        String code = "function " + jsFun.getFunctionName() + "(";
        String functionParameters = "";
        int countFunctionParam = 0;

        for(ParameterDefinition pd : jsFun.getParameters()) {
            if(countFunctionParam != 0) {
                functionParameters += ", " + pd.getName();
            } else {
                functionParameters += pd.getName();
                countFunctionParam++;
            }
        }

        String functionParametersValue = "";
        int countParam = 0;
        for(int p = 0; p < jsFun.getParameters().size(); p++) {
            if(countParam != 0) {
                if(values.get(p).getType().equals(EValueType.STRING)) {
                    functionParametersValue += ", \"" + values.get(p) + "\"";
                } else {
                    functionParametersValue += ", " + values.get(p);
                }
            } else {
                if(values.get(p).getType().equals(EValueType.STRING)) {
                    functionParametersValue += "\"" + values.get(p) + "\"";
                } else {
                    functionParametersValue += values.get(p);
                }
                countParam++;
            }
        }

        code += functionParameters + ")" + jsFun.getBody() + "\n" + jsFun.getFunctionName() + "(" + functionParametersValue + ");";

        return code;
    }

    private JSFunction getJsFunction(String name, List<Expression> parameters, Pipeline pipeline) throws ScriptException {

        listValue = new ArrayList<>();

        for(Expression e : parameters) {
            OperationTree opTree = new OperationTree("Generate Fuzzy");
            opTree.expression2Tree(e);
            List<OperationTree> opTreeList = Collections.singletonList(opTree);

            OperationConditionMatcher opCondMatcher = new OperationConditionMatcher();
            for(OperationTree opT : opTreeList) {
                Value v = opCondMatcher.evaluateOperationTreeValue(opT.getRoot(), pipeline);
                listValue.add(v);
            }
        }

        JSFunction js = functionWithSameName(name, listValue, pipeline);

        return js;

    }

    private JSFunction functionWithSameName(String name, List<Value> parametersValue, Pipeline pipeline) {
        List<JSFunction> listFunction = new ArrayList<>();

        for(JSFunction jsf : pipeline.getJsFunction()) {
            if(jsf.getFunctionName().equals(name)) {
                listFunction.add(jsf);
            }
        }

        if(listFunction.size() == 1) {
            return listFunction.get(0);
        } else if(listFunction.size() > 1) {
            return functionWithSameNumParameters(listFunction, parametersValue, pipeline);
        } else {
            return null;
        }
    }

    private JSFunction functionWithSameNumParameters(List<JSFunction> jsFunctionList, List<Value> parameters, Pipeline pipeline) {
        List<JSFunction> listFunction = new ArrayList<>();
        for(JSFunction jsf : jsFunctionList) {
            if(jsf.getParameters().size() == parameters.size()) {
                listFunction.add(jsf);
            }
        }

        if(listFunction.size() == 1) {
            return listFunction.get(0);
        } else if(listFunction.size() > 1) {
            return checkParametersType(listFunction, parameters, pipeline);
        } else {
            return null;
        }
    }

    private JSFunction checkParametersType(List<JSFunction> listFunction, List<Value> parameters, Pipeline pipeline) {
        for(JSFunction jsf : listFunction) {
            boolean match = false;
            for(int p = 0; p < parameters.size(); p++) {
                if(jsf.getParameters().get(p).getType().equals(parameters.get(p).getType().toString())) {
                    match = true;
                }
            }
            if(match) {
                return jsf;
            }
        }

        return null;
    }

    private IMatcher getMatcher(ICondition condition) {
        IMatcher matcher = null;
        if(condition instanceof TreeCondition){
            matcher = new TreeConditionMatcher();
        }
        return matcher;
    }

}
