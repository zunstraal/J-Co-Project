package net.fm.geco.engine.evaluator;

import java.util.List;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.matcher.IMatcher;
import net.fm.geco.engine.matcher.TreeConditionMatcher;
import net.fm.geco.model.Case;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.AlphaCutCommand;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.command.GenerateFuzzyCommand;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.WhereCondition;
import net.fm.geco.model.condition.tree.TreeCondition;


public class CaseEvaluator {

	public DocumentDefinition evaluate(Pipeline pipeline, Case caseFilter) throws ScriptException {

		DocumentDefinition outDoc = null;

		for(WhereCondition whereCondition : caseFilter.getWhereConditions()) {
			if(checkCondition(whereCondition, pipeline)) {
				/* GENERATE */
				GenerateCommand generate =  whereCondition.getGenerate();
				if(generate != null) {
					GenerateCommandEvaluator evaluator = new GenerateCommandEvaluator();
					outDoc = evaluator.evaluate(pipeline, generate);

				} else {
					final Object currentObj = pipeline.get(pipeline.getCurrentCollectionName());
					if(currentObj instanceof DocumentDefinition) {
						outDoc = (DocumentDefinition) currentObj;
					} else {
						outDoc = pipeline.getAsDocument();
					}
				}

				/* GENERATE FUZZY SET */
				List<GenerateFuzzyCommand> generateFuzzy = whereCondition.getGenerateFuzzyList();
				if(generateFuzzy != null) {
					Pipeline generateFuzzyPipeline = new Pipeline();
					Pipeline generateFuzzyPipelineRic = new Pipeline();
					generateFuzzyPipeline.setFuzzyOperators(pipeline.getFuzzyOperators());
					generateFuzzyPipelineRic.setFuzzyOperators(pipeline.getFuzzyOperators());
					generateFuzzyPipeline.setJsFunctions(pipeline.getJsFunction());
					generateFuzzyPipelineRic.setJsFunctions(pipeline.getJsFunction());
					generateFuzzyPipeline.add(outDoc, "Generate Fuzzy");
					DocumentDefinition tempDoc = null;
					for (GenerateFuzzyCommand gfc : generateFuzzy) {
						if (gfc != null) {
							GenerateFuzzyCommandEvaluator evaluatorFuzzy = new GenerateFuzzyCommandEvaluator();
							if(tempDoc != null) {
								generateFuzzyPipelineRic.add(tempDoc, "Generate Fuzzy");
								tempDoc = evaluatorFuzzy.evaluate(generateFuzzyPipelineRic, gfc);
							} else {
								tempDoc = evaluatorFuzzy.evaluate(generateFuzzyPipeline, gfc);
							}
						}
					}
					outDoc = tempDoc;

				}

				/* ALPHA-CUT */
				if(whereCondition.getAlphaCutCommands() != null) {
					List<AlphaCutCommand> listAlphaCommand = whereCondition.getAlphaCutCommands();
					AlphaCutEvaluator ace = new AlphaCutEvaluator();
					if (listAlphaCommand != null) {
						outDoc = ace.evaluate(outDoc, listAlphaCommand);
					}
				}

				/* DROPPING - KEEPING (ALL) FUZZY SETS (fuzzy sets, ...) */
				if(whereCondition.getKeepDropFuzzyCommand() != null) {
					KeepingDroppingFuzzySetsEvaluator kdfs = new KeepingDroppingFuzzySetsEvaluator();
					outDoc = kdfs.evaluate(outDoc, whereCondition.getKeepDropFuzzyCommand());
				}

				// PF. Once the 1st where condition has met with the current document there's no need to go on.
				break;

			} else if(caseFilter.isKeepOthers()) {
				final Object currentObj = pipeline.get(pipeline.getCurrentCollectionName());
				if(currentObj instanceof DocumentDefinition) {
					outDoc = (DocumentDefinition) currentObj;
				} else {
					outDoc = pipeline.getAsDocument();
				}
			}
		}
		return outDoc;
	}

	private boolean checkCondition(WhereCondition whereCondition, Pipeline pipeline) throws ScriptException {
		boolean match = true;
		
		List<ICondition> conditions = whereCondition.getConditions();
		if(conditions != null) {
	
			for(ICondition c : conditions) {
				IMatcher matcher = getMatcher(c);
				
				if(matcher != null && !matcher.matches(c, pipeline)) {
					match = false;
				}
			}
		}
		return match;
	}

	// le whereCondition sono tutte instanceof TreeCondition, quindi tutti gli altri matcher non servono
	private IMatcher getMatcher(ICondition condition) {
		IMatcher matcher = null;
		
		if(condition instanceof TreeCondition){
			matcher = new TreeConditionMatcher();
		}
		return matcher;
	}

}
