package net.fm.geco.engine.executor;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import geco.model.util.DbName;
import net.fm.geco.ds.datatype.JcoDsRemoteDatabase;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.elasticsearch.ElasticDatabase;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.executor.utils.Configuration;
import net.fm.geco.engine.mongodb.MongoDbDatabase;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.engine.registry.Servers;
import net.fm.geco.model.command.UseDbCommand;
import net.fm.geco.model.engine.IDatabase;

@Executor(UseDbCommand.class)
public class UseDbExecutor implements IExecutor<UseDbCommand> {

	private DatabaseRegistry registry;
	private Servers s;

	@Autowired
	public UseDbExecutor(DatabaseRegistry registry, Servers s) {
		this.registry = registry;
		this.s = s;
	}

	@Override
	public void execute(Pipeline pipeline, UseDbCommand command) throws ExecuteProcessException {
		IDatabase db = null;
		String dbname = "";
		List<String> dbnames = new ArrayList<>();
		if (command.getType() == 0) {
			// ON DEFAULT SERVER
			for (Configuration c : s.getConfigurations()) {
				if (c.isDefault()) {
					for (DbName name : command.getDbNames()) {
						if (name.alias != null) {
							dbname = name.alias;
						} else {
							dbname = name.db;
						}
						db = createDB(c.getType(), c.getHost(), c.getPort(), name.db);
						dbnames.add(dbname);
						// registry.registerDatabase(dbname, db);
					}
				}
			}
		} else if (command.getType() == 1) {
			// ON SERVER serverName
			for (Configuration c : s.getConfigurations()) {
				if (c.getServer().equals(command.getServerName())) {
					for (DbName name : command.getDbNames()) {
						if (name.alias != null) {
							dbname = name.alias;
						} else {
							dbname = name.db;
						}
						db = createDB(c.getType(), c.getHost(), c.getPort(), name.db);
						dbnames.add(dbname);
						// registry.registerDatabase(dbname, db);
					}
				}
			}
		} else if (command.getType() == 2) {
			// ON SERVER serverType serverName
			String serverType = command.getServerType().toLowerCase();
			if (serverType.startsWith("'"))
				serverType = serverType.substring(1, serverType.length() - 1);
			URL u = null;
			for (DbName name : command.getDbNames())
				try {
					u = new URL(command.getConnectionString().substring(1, command.getConnectionString().length() - 1));
					String host = u.getHost();
					if (u.getPath() != null)
						host = host + u.getPath();

					if (name.alias != null)
						dbname = name.alias;
					else
						dbname = name.db;
					db = createDB(serverType, host, u.getPort(), name.db);
					dbnames.add(dbname);
					// registry.registerDatabase(dbname, db);
				} catch (MalformedURLException e) {
					System.out.println("Error: the URL is incorrect");
					System.exit(1);
				}
		}

		// Verifico se il database esiste o meno
		if (registry.getDatabase(dbname) == null) {
			registry.registerDatabase(dbname, db);
		} else {
			throw new ExecuteProcessException("[USE DB]: Error: database " + dbname + " already exists");
		}

		// PF - what's for?
		pipeline.addCollection(dbnames);

	}
/*
	private void addDatabase(IDatabase db, String dbname) {
		// Verifico se il database esiste o meno
		if (registry.getDatabase(dbname) == null) {
			registry.registerDatabase(dbname, db);
		} else {
			throw new ExecuteProcessException("[USE DB]: Error: database " + dbname + " already exists");
		}
	}
*/
	private IDatabase createDB(String type, String host, int port, String dbname) {
		IDatabase result = null;
		if (type.toLowerCase().equals("mongodb")) {
			result = new MongoDbDatabase(host, port, dbname);
		} else if (type.toLowerCase().equals("elasticsearch")) {
			result = new ElasticDatabase(host, port, dbname);
		} else if (type.toLowerCase().equals("jcods")) {
			result = new JcoDsRemoteDatabase(host, port, dbname);
		}
		return result;
	}

}
