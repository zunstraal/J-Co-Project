package net.fm.geco.engine.evaluator;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryCollection;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.PrecisionModel;

import net.fm.geco.model.operation.AllOperation;
import net.fm.geco.model.operation.IGeometryOperation;
import net.fm.geco.model.operation.IntersectionOperation;
import net.fm.geco.model.operation.LeftOperation;
import net.fm.geco.model.operation.RightOperation;
import net.fm.geco.model.value.GeoJsonValue;

public class GeometryEvaluator {

	public GeoJsonValue evaluate(GeoJsonValue leftGeometry, GeoJsonValue rightGeometry, IGeometryOperation geometryOperation) {
		GeoJsonValue outGeo = null;
		if(geometryOperation != null) {
			if(geometryOperation instanceof IntersectionOperation) {
				outGeo = new GeoJsonValue(leftGeometry.getGeometry().intersection(rightGeometry.getGeometry()));
			} else if(geometryOperation instanceof AllOperation) {
				
				GeometryCollection collection;
				Geometry[] geometries = new Geometry[2];
				
				geometries[0] = leftGeometry.getGeometry();
				geometries[1] = rightGeometry.getGeometry();

				
				collection = new GeometryCollection(geometries, new GeometryFactory(new PrecisionModel(), 0));
				outGeo = new GeoJsonValue(collection);
				//outGeo = new GeoJsonValue(leftGeometry.getGeometry().(rightGeometry.getGeometry()));
			}else if(geometryOperation instanceof RightOperation) {
				
				outGeo = new GeoJsonValue(rightGeometry.getGeometry());
				
			}else if(geometryOperation instanceof LeftOperation) {
				
				outGeo = new GeoJsonValue(leftGeometry.getGeometry());
			}
		}
		return outGeo;
	}

}
