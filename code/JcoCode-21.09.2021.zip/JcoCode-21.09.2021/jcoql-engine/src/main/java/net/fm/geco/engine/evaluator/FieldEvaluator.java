package net.fm.geco.engine.evaluator;

import net.fm.geco.byZun.ZunWarningTracker;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.ArrayValue;
import net.fm.geco.model.value.BuiltInFunctionFieldValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.Value;
import net.fm.geco.model.value.SimpleValue;

import java.util.List;
import java.util.Stack;
import org.wololo.jts2geojson.GeoJSONReader;


public class FieldEvaluator {

	
	public Value evaluate(Pipeline pipeline, Value value) {
		Value outValue = value;

		if(value != null) {
			if (value instanceof FieldValue) {
				FieldValue fieldValue = (FieldValue) value;
				final FieldReference fieldReference = fieldValue.getFieldReference();

				if(fieldReference != null) {
					Object objDoc = pipeline.get(fieldReference.getCollectionAlias());
					if(objDoc != null && objDoc instanceof DocumentDefinition) {
						outValue = ((DocumentDefinition) objDoc).getValue(fieldReference.getFieldName());
					}
				}
			}
			// PF - Else aggiunto per gestire TUTTE LE FUNZION BUILT-IN
			else if (value instanceof BuiltInFunctionFieldValue) {
				outValue = evaluateFunction(pipeline, (BuiltInFunctionFieldValue) value);
			}
		}

		return outValue;
	}

	

// PF - method added in order to evaluate if a field is a GeoJson geometry 
	public Value evaluateGeometry(Pipeline pipeline, Value value) {
		Value outValue = value;
		if(value != null && value instanceof FieldValue) {
			FieldValue fieldValue = (FieldValue) value;
			final FieldReference fieldReference = fieldValue.getFieldReference();

			if(fieldReference != null) {
				Object objDoc = pipeline.get(fieldReference.getCollectionAlias());
				if(objDoc != null && objDoc instanceof DocumentDefinition) {
					try {
						outValue = ((DocumentDefinition) objDoc).getValue(fieldReference.getFieldName());
						outValue  = new GeoJsonValue(new GeoJSONReader().read(outValue.toString()));
					} catch (Exception e) {
						outValue = null;
					}
				}
			}
		}
		return outValue;
	}


// PF - method added to evalutate BuiltIn functions : COUNT, TO_STRING, TO_BOOL, TO_INT, TO_FLOAT, TO_STRING, TRANSLATE
	Value evaluateFunction (Pipeline pipeline, BuiltInFunctionFieldValue function) {		
		Value outValue = null;
		final FieldReference fieldReference = function.getFieldReference();
		ZunWarningTracker.add("EVALUATE:\t" + function.toDebugString());

		if(fieldReference != null) {
			Object objDoc = pipeline.get(fieldReference.getCollectionAlias());
			if(objDoc != null && objDoc instanceof DocumentDefinition) {
				Value value = ((DocumentDefinition) objDoc).getValue(fieldReference.getFieldName());

				if (value != null) {
					String valueStr = value.getStringValue().trim();
	
					// PF. Handling of COUNT built-in function
					if (function.getType() == EValueType.COUNT) {
						long count = 1;		// defaultValue
						if (value.getType() == EValueType.ARRAY) {
							count = 0;
							List<Value> listValues = ((ArrayValue) value).getValues();							
							if (listValues != null)
								count = listValues.size();
						}
						outValue = new SimpleValue (count);
					} 
					
					// PF. Handling of TO_BOOL built-in function
					else if (function.getType() == EValueType.TO_BOOL_FIELD) {
						boolean bool = false; 	// default Value
						if (value.getType() == EValueType.ARRAY) {
							long count = 0;
							List<Value> listValues = ((ArrayValue) value).getValues();							
							if (listValues != null)
								count = listValues.size();

							bool = (count > 0);
						} else if (value.getType() == EValueType.DOCUMENT) {
							bool = true; 
						} else if (value.getType() == EValueType.BOOLEAN) {
							bool = valueStr.equals("true");
						} else if (value.getType() == EValueType.INTEGER || value.getType() == EValueType.DECIMAL) {
							try {
								double d = Double.parseDouble(valueStr.replace("\"", "").replace(",", ".").trim());
								bool = (d != 0);
							}catch (NumberFormatException e) {
									
							}							
						} else if (value.getType() == EValueType.STRING) {
							bool = !valueStr.equals("");
						}
						outValue = new SimpleValue (bool);
					} 

					// PF. Handling of TO_INT built-in function
					else if (function.getType() == EValueType.TO_INT_FIELD) {
						long toInt = 0; 	// default Value for ARRAY & DOCUMENT
						if (value.getType() == EValueType.BOOLEAN) {
							if (valueStr.equalsIgnoreCase("true"))
								toInt = 1;
						}
						else if (value.getType() == EValueType.INTEGER || 
								value.getType() == EValueType.DECIMAL || 
								value.getType() == EValueType.STRING) {
							try {
								double d = Double.parseDouble(valueStr.replace("\"", "").replace(",", ".").trim());
								toInt = (long) d;					// i numeri decimali vengono trocati
							}catch (NumberFormatException e) {
									
							}
						}
						outValue = new SimpleValue (toInt);						
					} 

					// PF. Handling of TO_FLOAT built-in function
					else if (function.getType() == EValueType.TO_FLOAT_FIELD) {
						double toDouble = 0; 	// default Value for ARRAY & DOCUMENT
						if (value.getType() == EValueType.BOOLEAN) {
							if (valueStr.equalsIgnoreCase("true"))
								toDouble = 1.0;
						}
						else if (value.getType() == EValueType.INTEGER || 
								value.getType() == EValueType.DECIMAL || 
								value.getType() == EValueType.STRING) {
							try {
								toDouble = Double.parseDouble(valueStr.replace("\"", "").replace(",", ".").trim());
							}catch (NumberFormatException e) {
									
							}
						}
						outValue = new SimpleValue (toDouble);						
						
					} 

					// PF. Handling of TO_STRING built-in function
					else if (function.getType() == EValueType.TO_STRING_FIELD) {
						String st = valueStr;	
						if (value.getType() == EValueType.DOCUMENT || 
								value.getType() == EValueType.ARRAY) {
							st = "";
						}
						else if (value.getType() == EValueType.DECIMAL) {
							Double d = Double.parseDouble(valueStr.toString());
							st = d.toString();
						} 
						ZunWarningTracker.add("PASSSO QUI PER IL TO STRING:\t"+function.toString());
						outValue = new SimpleValue (st);
					} 

					// PF. Handling of TO_SERIALIZE built-in function
					else if (function.getType() == EValueType.TO_SERIALIZE_FIELD) {
						String st = valueStr;	
						if (value.getType() == EValueType.DOCUMENT || 
								value.getType() == EValueType.ARRAY) {
							st = valueStr.replace("\n", "").replace("\r", "").replace("\t", " ");
						}
						else if (value.getType() == EValueType.DECIMAL) {
							Double d = Double.parseDouble(valueStr.toString());
							st = d.toString();
						} 
						outValue = new SimpleValue (st);						
					} 					

					// PF. Handling of TRANSLATE built-in function - TRANSLATE Strings values if it finds a match. otherwise assign the DefaultTranslation OR it leaves the value unchanged, 
					else if (function.getType() == EValueType.TRANSLATE_FIELD) {
						outValue = value;
						if (function.hasDefaultTranslation())
							outValue = new SimpleValue (function.getDefaultTranslation());
						if (value.getType() == EValueType.STRING) {
							String key = valueStr;
							String st = pipeline.getDictionaryValue(function.getDictionary(), key, function.isDictionaryCaseSensitive());
							if (st != null)
								outValue = new SimpleValue (st);
						}
					} 

				}		
				
			}
		}
		return outValue;		
	} 

	
	
// PF - method added to evaluate the COUNT function - DEPRECATED
	@Deprecated
	long countFieldValuesDEPRECATED (String str, int start) {
		boolean empty = true;
		String ch;
		long count = 0;
    	Stack<String> stack = new Stack<String>();
    	int valueStrPos=start;

		while (valueStrPos < str.length()) {
			ch = "" + str.charAt(valueStrPos);

			// controlla se la stringa non � vuota (spazi a parte) ergo c'� almeno un elemento
			if (!ch.equals(" ")  && !ch.equals("\n") && !ch.equals("\t") && !ch.equals("\r") && !ch.equals("]"))
				empty = false;

			// conto solo le virgole (vuol dire che gli elementi sono pi� di uno
			if (stack.isEmpty()) {
				if (ch.equals(","))
					count++;
				else if (ch.equals("'"))
					stack.push(ch);
				else if (ch.equals("\""))
					stack.push(ch);
				else if (ch.equals("{"))
					stack.push("}");
				else if (ch.equals("["))
					stack.push("]");
				else if (ch.equals("("))
					stack.push(")");
			} else {
				if (stack.lastElement().equals("'")) {
					if (ch.equals("'"))
						stack.pop();
				}
				else if (stack.lastElement().equals("\"")) {
					if (ch.equals("\""))
						stack.pop();
				}
				else if (stack.lastElement().equals(ch))
					stack.pop();
				else if (ch.equals("'"))
					stack.push("'");
				else if (ch.equals("\""))
					stack.push("\"");
				else if (ch.equals("{"))
					stack.push("}");
				else if (ch.equals("["))
					stack.push("]");
				else if (ch.equals("("))
					stack.push(")");

			}


			valueStrPos++;

		}

		if (!empty)
			count++;

		return count;
	}


}
