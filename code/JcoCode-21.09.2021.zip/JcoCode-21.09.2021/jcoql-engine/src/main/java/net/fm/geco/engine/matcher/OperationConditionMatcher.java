package net.fm.geco.engine.matcher;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.evaluator.JSFunctionEvaluator;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.comparison.model.EOperationType;
import net.fm.geco.model.comparison.model.OperationNode;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.tree.OperationCondition;
import net.fm.geco.model.expression.BasicExpression;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.FunctionJsValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class OperationConditionMatcher implements IMatcher{

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) throws ScriptException {
		OperationCondition c = (OperationCondition) condition;
		return evaluate(c, pipeline);
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) throws ScriptException {
		if(matches(condition, pipeline)) {
			return 1;
		} else {
			return 0;
		}
	}

	private boolean evaluate(OperationCondition condition, Pipeline pipeline) throws ScriptException {

		BasicConditionMatcher bcMatcher = new BasicConditionMatcher();
		BasicCondition bc = null;

		Value valueLeft = null;
		Value valueRight = null;

		if(condition.getValue() == null){
			valueLeft = evaluateOperationTree(condition.getOperationTreeLeft().getRoot(), pipeline);
			valueRight = evaluateOperationTree(condition.getOperationTreeRight().getRoot(), pipeline);
		}

		else if(condition.getOperationTreeLeft() == null){
			valueLeft = condition.getValue();
			valueRight = evaluateOperationTree(condition.getOperationTreeRight().getRoot(), pipeline);
		}
		else if(condition.getOperationTreeRight() == null){
			valueLeft =  evaluateOperationTree(condition.getOperationTreeLeft().getRoot(), pipeline);
			valueRight = condition.getValue();
		}

		bc = new BasicCondition(new BasicExpression(valueLeft, condition.getOperatorType(), valueRight));

		return bcMatcher.matches(bc, pipeline);
	}

	public Value evaluateOperationTree(OperationNode node,Pipeline pipeline) throws ScriptException {
		if(node == null){
			return new SimpleValue(0);
		} else {

            if(node.getType() == EOperationType.ADD){
                return ComputeAdd(evaluateOperationTree(node.getLeft(), pipeline), evaluateOperationTree(node.getRight(), pipeline), pipeline);
            }else if(node.getType() == EOperationType.SUB){
                return ComputeSub(evaluateOperationTree(node.getLeft(), pipeline), evaluateOperationTree(node.getRight(), pipeline), pipeline);
            }else if(node.getType() == EOperationType.MUL){
                return ComputeMul(evaluateOperationTree(node.getLeft(), pipeline), evaluateOperationTree(node.getRight(), pipeline), pipeline);
            }else if(node.getType() == EOperationType.DIV){
                return ComputeDiv(evaluateOperationTree(node.getLeft(), pipeline), evaluateOperationTree(node.getRight(), pipeline), pipeline);
            }
            else if(node.getType() == null) {
				if (node.factor.value != null) {
					return new SimpleValue(Double.parseDouble(node.factor.value.value));
				} else if (node.factor.field != null) {
					FieldReference f = ((FieldValue) node.getValue()).getFieldReference();
					DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
					return document.getValue(f.getFieldName());
				} else if (node.factor.function != null) {
					JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
					FunctionJsValue valueJs = new FunctionJsValue(node.factor.function, node.factor.functionParams);
					return jsFunctionEvaluator.evaluate(valueJs, pipeline);
				} else if(node.factor.id != null) {
					return new SimpleValue(Double.parseDouble(pipeline.getJsFunctionParametersMap().get(node.factor.id).getStringValue()));
				} else {
					return node.getValue();
				}
			}
            else
                throw new RuntimeException("Undefined Operation");
        }
	}


	/* ** ** ** ** ** ** ** ** ** ** */
	public Value evaluateOperationTreeValue(OperationNode node, Pipeline pipeline) throws ScriptException {
		if(node == null){
			return new SimpleValue(0);
		} else {
			if(node.getType() == EOperationType.ADD) {
				Value add = ComputeAdd(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
				if(add == null) {
					return null;
				} else {
					return add;
				}
				//return ComputeAdd(evaluateOperationTreeValue(node.getLeft(), mapValue, pipeline), evaluateOperationTreeValue(node.getRight(), mapValue, pipeline), pipeline);
			} else if(node.getType() == EOperationType.SUB) {
				Value sub = ComputeSub(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
				if(sub == null) {
					return null;
				} else {
					return sub;
				}
				//return ComputeSub(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
			} else if(node.getType() == EOperationType.MUL) {
				Value mul = ComputeMul(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
				if(mul == null) {
					return null;
				} else {
					return mul;
				}
				//return ComputeMul(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
			} else if(node.getType() == EOperationType.DIV) {
				Value div = ComputeDiv(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
				if(div == null) {
					return null;
				} else {
					return div;
				}
				//return ComputeDiv(evaluateOperationTreeValue(node.getLeft(), pipeline), evaluateOperationTreeValue(node.getRight(), pipeline), pipeline);
			} else if(node.getType() == null) {
				if(node.factor.value != null) {
					return new SimpleValue(Double.parseDouble(node.factor.value.value));
				} else if(node.factor.field != null) {
					// parametri FuzzyOperator
					/*DocumentDefinition parametersOpFuzzy = pipeline.getFuzzyOperatorParameters();
					FieldReference f = ((FieldValue) node.getValue()).getFieldReference();
					for(FieldDefinition fd : parametersOpFuzzy.getFields()){
						if(fd.getName().equals(f.getFieldName())) {
							return fd.getValue();
						}
					}
					return null;*/
					FieldReference f = ((FieldValue) node.getValue()).getFieldReference();
					DocumentDefinition document = pipeline.getFuzzyOperatorParameters();
					return document.getValue(f.getFieldName());
				} else if(node.factor.function != null) {
                    JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
                    FunctionJsValue valueJs = new FunctionJsValue(node.factor.function, node.factor.functionParams);
					return jsFunctionEvaluator.evaluate(valueJs, pipeline);
				} else if(node.factor.id != null) {
					// parametri JS function
					return new SimpleValue(Double.parseDouble(pipeline.getJsFunctionParametersMap().get(node.factor.id).getStringValue()));
				} else {
					return node.getValue();
				}
			} else {
				throw new RuntimeException("Undefined Operation");
			}
		}
	}
	/* ** ** ** ** ** ** ** ** ** ** */




	private Value ComputeAdd(Value valueLeft, Value valueRight, Pipeline pipeline) throws ScriptException {
		if (valueLeft != null && valueRight != null) {
			/* Caso in cui si deve lavorare su due Simple Value */
			if (valueLeft instanceof SimpleValue && valueRight instanceof SimpleValue) {

				double a = 0, b = 0;
				String sa = null, sb = null;

				/* Analisi Value Left*/
				if (valueLeft.getType() == EValueType.DECIMAL) {
					a = (Double) (((SimpleValue) valueLeft).getValue());
				} else if (valueLeft.getType() == EValueType.INTEGER) {
					a = (Long) (((SimpleValue) valueLeft).getValue());
				} else if (valueLeft.getType() == EValueType.STRING) {
					sa = (String) (((SimpleValue) valueLeft).getValue());
				} else {
					throw new RuntimeException("Operation ADD not defined for type: " + valueLeft.getType());
				}

				/* Analisi value Right*/
				if (valueRight.getType() == EValueType.DECIMAL) {
					b = (Double) (((SimpleValue) valueRight).getValue());
				} else if (valueRight.getType() == EValueType.INTEGER) {
					b = (Long) (((SimpleValue) valueRight).getValue());
				} else if (valueRight.getType() == EValueType.STRING) {
					sb = (String) (((SimpleValue) valueRight).getValue());
				} else {
					throw new RuntimeException("Operation ADD not defined for type: " + valueRight.getType());
				}

				if (valueLeft.getType() == valueRight.getType()) {
					if (valueLeft.getType() == EValueType.DECIMAL || valueLeft.getType() == EValueType.INTEGER) {
						return new SimpleValue(a + b);
					} else if (valueLeft.getType() == EValueType.STRING || valueLeft.getType() == EValueType.STRING) {
						return new SimpleValue(sa + sb);
					} else {
						throw new RuntimeException("Operation ADD not defined for type: " + valueRight.getType());
					}
				} else if (valueLeft.getType() == EValueType.DECIMAL && valueRight.getType() == EValueType.INTEGER) {
					return new SimpleValue(a + b);
				} else if (valueLeft.getType() == EValueType.INTEGER && valueRight.getType() == EValueType.DECIMAL) {
					return new SimpleValue(a + b);
				} else {
					throw new RuntimeException("Operation ADD not defined for different types");
				}
			}

			/* Caso in cui si hanno due Field Value */
			else if (valueLeft instanceof FieldValue && valueRight instanceof FieldValue) {
				FieldReference f1 = ((FieldValue) valueLeft).getFieldReference();
				FieldReference f2 = ((FieldValue) valueRight).getFieldReference();

				DocumentDefinition document = (DocumentDefinition) pipeline.get(f1.getCollectionAlias());

				Value value1 = document.getValue(f1.getFieldName());
				Value value2 = document.getValue(f2.getFieldName());

				checkValue(value1, f1, value2, f2);

				return ComputeAdd(value1, value2, pipeline);
			}

			/*Caso in cui si ha un FieldValue (left) e un SimpleValue (right)*/
			else if (valueLeft instanceof FieldValue && valueRight instanceof SimpleValue) {

				FieldReference f = ((FieldValue) valueLeft).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeAdd(value1, valueRight, pipeline);

			}

			/* Caso in cui si ha un SimpleValue (left) e un FieldValue (right) */
			else if (valueLeft instanceof SimpleValue && valueRight instanceof FieldValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeAdd(valueLeft, value1, pipeline);

			}
			/* AGGIUNTA */
			/* Caso in cui si ha due funzioni JS */
			else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FunctionJsValue) {
				JSFunctionEvaluator jsFunctionEvaluator1 = new JSFunctionEvaluator();
				JSFunctionEvaluator jsFunctionEvaluator2 = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator1.evaluate((FunctionJsValue) valueLeft, pipeline);
				Value vr = jsFunctionEvaluator2.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeAdd(vl, vr, pipeline);

				/* caso con funzione js + Value */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof SimpleValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);
				return ComputeAdd(vl, valueRight, pipeline);

				/* caso con Funzione js + FieldValue */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FieldValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vr = document.getValue(f.getFieldName());
				checkValue(vr, f);

				return ComputeAdd(vl, vr, pipeline);

				/* caso con Value + funzione js */
			} else if (valueLeft instanceof SimpleValue && valueRight instanceof FunctionJsValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeAdd(valueLeft, vr, pipeline);

				/* caso con FieldValue + Funzione js */
			} else if (valueLeft instanceof FieldValue && valueRight instanceof FunctionJsValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vl = document.getValue(f.getFieldName());
				checkValue(vl, f);

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);
				return ComputeAdd(vl, vr, pipeline);

			} else {
				throw new RuntimeException("Operation ADD not defined for types: " + valueLeft.getType() + "," + valueRight.getType());
			}
		} else {
			return null;
		}
	}
	
	private Value ComputeSub(Value valueLeft, Value valueRight,Pipeline pipeline) throws ScriptException {
		if(valueLeft != null && valueRight != null) {
			/* Caso in cui si deve lavorare su due Simple Value */
			if (valueLeft instanceof SimpleValue && valueRight instanceof SimpleValue) {
				double a = 0, b = 0;
				/* Analisi Value Left*/
				if (valueLeft.getType() == EValueType.DECIMAL) {
					a = (Double) (((SimpleValue) valueLeft).getValue());
				} else if (valueLeft.getType() == EValueType.INTEGER) {
					a = (Long) (((SimpleValue) valueLeft).getValue());
				} else
					throw new RuntimeException("Operation SUB not defined for type: " + valueLeft.getType());

				/* Analisi value Right*/
				if (valueRight.getType() == EValueType.DECIMAL) {
					b = (Double) (((SimpleValue) valueRight).getValue());
				} else if (valueRight.getType() == EValueType.INTEGER) {
					b = (Long) (((SimpleValue) valueRight).getValue());
				} else
					throw new RuntimeException("Operation SUB not defined for type: " + valueRight.getType());

				if (valueLeft.getType() == valueRight.getType()) {

					if (valueLeft.getType() == EValueType.DECIMAL || valueLeft.getType() == EValueType.INTEGER) {
						return new SimpleValue(a - b);
					} else
						throw new RuntimeException("Operation SUB not defined for type: " + valueRight.getType());

				} else if (valueLeft.getType() == EValueType.DECIMAL && valueRight.getType() == EValueType.INTEGER) {
					return new SimpleValue(a - b);
				} else if (valueLeft.getType() == EValueType.INTEGER && valueRight.getType() == EValueType.DECIMAL) {
					return new SimpleValue(a - b);
				} else
					throw new RuntimeException("Operation SUB not defined for different types");

			}

			/* Caso in cui si hanno due Field Value */
			else if (valueLeft instanceof FieldValue && valueRight instanceof FieldValue) {

				FieldReference f1 = ((FieldValue) valueLeft).getFieldReference();
				FieldReference f2 = ((FieldValue) valueRight).getFieldReference();

				DocumentDefinition document = (DocumentDefinition) pipeline.get(f1.getCollectionAlias());

				Value value1 = document.getValue(f1.getFieldName());
				Value value2 = document.getValue(f2.getFieldName());

				checkValue(value1, f1, value2, f2);

				return ComputeSub(value1, value2, pipeline);

			}
			/*Caso in cui si ha un FieldValue (left) e un SimpleValue (right)*/
			else if (valueLeft instanceof FieldValue && valueRight instanceof SimpleValue) {

				FieldReference f = ((FieldValue) valueLeft).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeSub(value1, valueRight, pipeline);
			}
			/* Caso in cui si ha un SimpleValue (left) e un FieldValue (right) */
			else if (valueLeft instanceof SimpleValue && valueRight instanceof FieldValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeSub(valueLeft, value1, pipeline);
			}
			/* AGGIUNTA */
			/* Caso in cui si ha due funzioni JS */
			else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FunctionJsValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeSub(vl, vr, pipeline);

				/* caso con funzione js + Value */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof SimpleValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				return ComputeSub(vl, valueRight, pipeline);

				/* caso con Funzione js + FieldValue */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FieldValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vr = document.getValue(f.getFieldName());
				checkValue(vr, f);

				return ComputeSub(vl, vr, pipeline);

				/* caso con Value + funzione js */
			} else if (valueLeft instanceof SimpleValue && valueRight instanceof FunctionJsValue) {

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeSub(valueLeft, vr, pipeline);

				/* caso con FieldValue + Funzione js */
			} else if (valueLeft instanceof FieldValue && valueRight instanceof FunctionJsValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vl = document.getValue(f.getFieldName());
				checkValue(vl, f);

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeSub(vl, vr, pipeline);

			} else
				throw new RuntimeException("Operation SUB not defined for types: " + valueLeft.getType() + "," + valueRight.getType());
		} else {
			return null;
		}
	}
	
    private Value ComputeMul(Value valueLeft, Value valueRight,Pipeline pipeline) throws ScriptException {
		if(valueLeft != null && valueRight != null) {
			/* Caso in cui si deve lavorare su due Simple Value */
			if (valueLeft instanceof SimpleValue && valueRight instanceof SimpleValue) {
				double a = 0, b = 0;
				/* Analisi Value Left*/
				if (valueLeft.getType() == EValueType.DECIMAL) {
					a = (Double) (((SimpleValue) valueLeft).getValue());
				} else if (valueLeft.getType() == EValueType.INTEGER) {
					a = (Long) (((SimpleValue) valueLeft).getValue());
				} else
					throw new RuntimeException("Operation MUL not defined for type: " + valueLeft.getType());

				/* Analisi value Right*/
				if (valueRight.getType() == EValueType.DECIMAL) {
					b = (Double) (((SimpleValue) valueRight).getValue());
				} else if (valueRight.getType() == EValueType.INTEGER) {
					b = (Long) (((SimpleValue) valueRight).getValue());

				} else
					throw new RuntimeException("Operation MUL not defined for type: " + valueRight.getType());

				if (valueLeft.getType() == valueRight.getType()) {

					if (valueLeft.getType() == EValueType.DECIMAL || valueLeft.getType() == EValueType.INTEGER) {
						return new SimpleValue(a * b);
					} else
						throw new RuntimeException("Operation MUL not defined for type: " + valueRight.getType());

				} else if (valueLeft.getType() == EValueType.DECIMAL && valueRight.getType() == EValueType.INTEGER) {
					return new SimpleValue(a * b);
				} else if (valueLeft.getType() == EValueType.INTEGER && valueRight.getType() == EValueType.DECIMAL) {
					return new SimpleValue(a * b);
				} else
					throw new RuntimeException("Operation MUL not defined for different types");

			}
			/* Caso in cui si hanno due Field Value */
			else if (valueLeft instanceof FieldValue && valueRight instanceof FieldValue) {

				FieldReference f1 = ((FieldValue) valueLeft).getFieldReference();
				FieldReference f2 = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f1.getCollectionAlias());

				Value value1 = document.getValue(f1.getFieldName());
				Value value2 = document.getValue(f2.getFieldName());

				checkValue(value1, f1, value2, f2);

				return ComputeMul(value1, value2, pipeline);

			}
			/*Caso in cui si ha un FieldValue (left) e un SimpleValue (right)*/
			else if (valueLeft instanceof FieldValue && valueRight instanceof SimpleValue) {

				FieldReference f = ((FieldValue) valueLeft).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeMul(value1, valueRight, pipeline);

			}
			/* Caso in cui si ha un SimpleValue (left) e un FieldValue (right) */
			else if (valueLeft instanceof SimpleValue && valueRight instanceof FieldValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeMul(valueLeft, value1, pipeline);

			}
			/* AGGIUNTA */
			/* Caso in cui si ha due funzioni JS */
			else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FunctionJsValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeMul(vl, vr, pipeline);

				/* caso con funzione js + Value */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof SimpleValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				return ComputeMul(vl, valueRight, pipeline);

				/* caso con Funzione js + FieldValue */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FieldValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vr = document.getValue(f.getFieldName());
				checkValue(vr, f);

				return ComputeMul(vl, vr, pipeline);

				/* caso con Value + funzione js */
			} else if (valueLeft instanceof SimpleValue && valueRight instanceof FunctionJsValue) {

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeMul(valueLeft, vr, pipeline);

				/* caso con FieldValue + Funzione js */
			} else if (valueLeft instanceof FieldValue && valueRight instanceof FunctionJsValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vl = document.getValue(f.getFieldName());
				checkValue(vl, f);

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeMul(vl, vr, pipeline);

			} else
				throw new RuntimeException("Operation MUL not defined for types: " + valueLeft.getType() + "," + valueRight.getType());
		} else {
			return null;
		}
		 							
	}

    private Value ComputeDiv(Value valueLeft, Value valueRight,Pipeline pipeline) throws ScriptException {
		if(valueLeft != null && valueRight != null) {
			/* Caso in cui si deve lavorare su due Simple Value */
			if (valueLeft instanceof SimpleValue && valueRight instanceof SimpleValue) {

				double a = 0, b = 0;

				/* Analisi Value Left*/
				if (valueLeft.getType() == EValueType.DECIMAL) {
					a = (Double) (((SimpleValue) valueLeft).getValue());
				} else if (valueLeft.getType() == EValueType.INTEGER) {
					a = (Long) (((SimpleValue) valueLeft).getValue());

				} else
					throw new RuntimeException("Operation DIV not defined for type: " + valueLeft.getType());

				/* Analisi value Right*/
				if (valueRight.getType() == EValueType.DECIMAL) {
					b = (Double) (((SimpleValue) valueRight).getValue());
				} else if (valueRight.getType() == EValueType.INTEGER) {
					b = (Long) (((SimpleValue) valueRight).getValue());

				} else
					throw new RuntimeException("Operation DIV not defined for type: " + valueRight.getType());

				if (b == 0)
					throw new IllegalArgumentException("Argument divisor is 0");

				if (valueLeft.getType() == valueRight.getType()) {

					if (valueLeft.getType() == EValueType.DECIMAL || valueLeft.getType() == EValueType.INTEGER) {
						return new SimpleValue(a / b);
					} else
						throw new RuntimeException("Operation DIV not defined for type: " + valueRight.getType());


				} else if (valueLeft.getType() == EValueType.DECIMAL && valueRight.getType() == EValueType.INTEGER) {
					return new SimpleValue(a / b);


				} else if (valueLeft.getType() == EValueType.INTEGER && valueRight.getType() == EValueType.DECIMAL) {
					return new SimpleValue(a / b);
				} else
					throw new RuntimeException("Operation DIV not defined for different types");

			}
			/* Caso in cui si hanno due Field Value */
			else if (valueLeft instanceof FieldValue && valueRight instanceof FieldValue) {

				FieldReference f1 = ((FieldValue) valueLeft).getFieldReference();
				FieldReference f2 = ((FieldValue) valueRight).getFieldReference();

				DocumentDefinition document = (DocumentDefinition) pipeline.get(f1.getCollectionAlias());

				Value value1 = document.getValue(f1.getFieldName());
				Value value2 = document.getValue(f2.getFieldName());

				checkValue(value1, f1, value2, f2);


				return ComputeDiv(value1, value2, pipeline);

			}
			/*Caso in cui si ha un FieldValue (left) e un SimpleValue (right)*/
			else if (valueLeft instanceof FieldValue && valueRight instanceof SimpleValue) {


				FieldReference f = ((FieldValue) valueLeft).getFieldReference();

				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeDiv(value1, valueRight, pipeline);

			}
			/* Caso in cui si ha un SimpleValue (left) e un FieldValue (right) */
			else if (valueLeft instanceof SimpleValue && valueRight instanceof FieldValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();

				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());

				Value value1 = document.getValue(f.getFieldName());
				checkValue(value1, f);

				return ComputeDiv(valueLeft, value1, pipeline);

			}
			/* AGGIUNTA */
			/* Caso in cui si ha due funzioni JS */
			else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FunctionJsValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeDiv(vl, vr, pipeline);

				/* caso con funzione js + Value */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof SimpleValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				return ComputeDiv(vl, valueRight, pipeline);

				/* caso con Funzione js + FieldValue */
			} else if (valueLeft instanceof FunctionJsValue && valueRight instanceof FieldValue) {
				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();

				Value vl = jsFunctionEvaluator.evaluate((FunctionJsValue) valueLeft, pipeline);

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vr = document.getValue(f.getFieldName());
				checkValue(vr, f);

				return ComputeDiv(vl, vr, pipeline);

				/* caso con Value + funzione js */
			} else if (valueLeft instanceof SimpleValue && valueRight instanceof FunctionJsValue) {

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeDiv(valueLeft, vr, pipeline);

				/* caso con FieldValue + Funzione js */
			} else if (valueLeft instanceof FieldValue && valueRight instanceof FunctionJsValue) {

				FieldReference f = ((FieldValue) valueRight).getFieldReference();
				DocumentDefinition document = (DocumentDefinition) pipeline.get(f.getCollectionAlias());
				Value vl = document.getValue(f.getFieldName());
				checkValue(vl, f);

				JSFunctionEvaluator jsFunctionEvaluator = new JSFunctionEvaluator();
				Value vr = jsFunctionEvaluator.evaluate((FunctionJsValue) valueRight, pipeline);

				return ComputeMul(vl, vr, pipeline);

			} else
				throw new RuntimeException("Operation Div not defined for types: " + valueLeft.getType() + "," + valueRight.getType());
		} else {
			return null;
		}
    }


    private void checkValue(Value v1,FieldReference f1,Value v2, FieldReference f2){

        checkValue(v1,f1);
        checkValue(v2,f2);
    }

    private void checkValue(Value v,FieldReference f){

        if(v==null)
            throw new RuntimeException("Did not found any value for the fieldReference: "+ f.getFieldName());
    }


}
