package net.fm.geco.engine.matcher;

import net.fm.geco.engine.Constants;
import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.KnownCondition;
import net.fm.geco.model.value.DocumentValue;


public class KnownConditionMatcher implements IMatcher {

    @Override
    public boolean matches(ICondition condition, Pipeline pipeline) {

        KnownCondition c = (KnownCondition) condition;
        String nameFuzzySet = c.getNameFuzzySets();
        boolean match = true;
        DocumentDefinition document = (DocumentDefinition) pipeline.get("Filter");

        if(document.getValue(Constants.FUZZY_FIELD_NAME) != null) {
            DocumentDefinition dd = new DocumentDefinition(((DocumentValue) document.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
            // verifica la presenza del campo ~fuzzysets
            // verifica l'assenza dello specifico fuzzy set
            if (dd.getValue(nameFuzzySet) == null) {
                match = false;
            }                
        } else {
            match = false;
        }
        return match;
    }

    @Override
    public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
        if(matches(condition, pipeline)) {
            return 1;
        } else {
            return 0;
        }
    }
}
