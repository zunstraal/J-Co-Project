package net.fm.geco.engine.parser.utils;

import geco.model.fuzzy.FuzzyCheck;
import net.fm.geco.model.command.GenerateFuzzyCommand;

public class GenerateFuzzyCommandCreator {

	private GenerateFuzzyCommand generateFuzzyCommand;
	// PF - what is for?
	private FuzzyCheck fuzzyGenerate;
	// PF - what is for?
	private String nameFuzzy;

	public GenerateFuzzyCommandCreator(FuzzyCheck fuzzyGenerate) {
		this.fuzzyGenerate = fuzzyGenerate;

		this.nameFuzzy = fuzzyGenerate.fuzzySet;
	}

	
	public GenerateFuzzyCommand getGenerateFuzzyCommand() {
		return generateFuzzyCommand;
	}
	
	// PF. Added on 01.08.2021 - But it seems useless
	public FuzzyCheck getFuzzyGenerate ( ) {
		return fuzzyGenerate;
	}
	// PF. Added on 01.08.2021 - But it seems useless
	public String getNameFuzzy ( ) {
		return nameFuzzy;
	}

}
