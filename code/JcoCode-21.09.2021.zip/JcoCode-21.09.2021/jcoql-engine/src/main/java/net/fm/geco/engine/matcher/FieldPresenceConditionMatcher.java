package net.fm.geco.engine.matcher;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.ICondition;

public class FieldPresenceConditionMatcher implements IMatcher {

	@Override
	public boolean matches(ICondition condition, Pipeline pipeline) {

		FieldPresenceCondition c = (FieldPresenceCondition) condition;
		String alias = c.getField().getCollectionAlias();

		DocumentDefinition document = (DocumentDefinition) pipeline.get(alias);
		return document.getValue(c.getField().getFieldName()) != null;
	}

	@Override
	public double fuzzyMatches(ICondition condition, Pipeline pipeline) {
		if(matches(condition, pipeline)) {
			return 1;
		} else {
			return 0;
		}
	}

}
