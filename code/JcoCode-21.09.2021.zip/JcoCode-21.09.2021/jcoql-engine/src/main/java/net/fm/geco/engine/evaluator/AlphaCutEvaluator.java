package net.fm.geco.engine.evaluator;

import java.util.List;

import net.fm.geco.engine.Constants;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.AlphaCutCommand;
import net.fm.geco.model.value.DocumentValue;

public class AlphaCutEvaluator {
    public DocumentDefinition evaluate(DocumentDefinition document, List<AlphaCutCommand> accList) {

        DocumentDefinition result = null;

        if(accList.size() > 0) {
            for (AlphaCutCommand acc : accList) {
                if (evaluateAlphaCut(document, acc)) {
                    result = document;
                } else {
                    return null;
                }
            }
        }

        return result;
    }

    private boolean evaluateAlphaCut(DocumentDefinition doc, AlphaCutCommand acc) {
        // se c'è il document ~fuzzysets
        if(doc.getValue(Constants.FUZZY_FIELD_NAME) != null) {
            DocumentDefinition dd = new DocumentDefinition(((DocumentValue) doc.getValue(Constants.FUZZY_FIELD_NAME)).getFields());
            // se c'è l'elemento desiderato
            if (dd.getValue(acc.getOn()) != null) {
                float v = Float.parseFloat(dd.getValue(acc.getOn()).toString());
                // verifica che il valore sia >= a quello di AlphaCut
                if (v >= Float.parseFloat(acc.getAlphaCut())) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            // non è presente il ~fuzzysets considero come se membership nulla
            return false;
        }
    }
}
