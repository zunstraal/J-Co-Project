package net.fm.geco.engine.executor.utils;

import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

import javax.script.ScriptException;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.evaluator.CaseEvaluator;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.model.Case;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.command.FilterCommand;
import net.fm.geco.model.engine.IDocumentCollection;

public class SynchronizedFilterCycle extends Thread {

	private int id, nThreads;
	private ArrayList<DocumentDefinition> docs;
	private LinkedBlockingQueue<DocumentDefinition> queue;

	private Pipeline pipeline;
	private IDocumentCollection collection;
	private Case caseFilter ;
	private CaseEvaluator caseEvaluator;
	
	public SynchronizedFilterCycle(int id, int nThread, Pipeline pipeline,
									LinkedBlockingQueue<DocumentDefinition> queue, FilterCommand command) {
		this.id = id;
		this.nThreads = nThread;
		this.docs = (ArrayList<DocumentDefinition>) docs;
		this.queue = queue;
		setPriority(10);

		this.pipeline = pipeline;
		collection = pipeline.getCurrentCollection();
		caseFilter = command.getCaseFilter();
		caseEvaluator = new CaseEvaluator();
	}

	
    @Override
    public void run() {
    	// fundamental
    	int i = id;   				

    	DocumentDefinition evaluatuedDocument;    	
    	while (i < collection.getDocument().size()) {
    		evaluatuedDocument = collection.getDocument().get(i);
			final Pipeline docPipeline = new Pipeline();
			docPipeline.add(evaluatuedDocument, "Filter");
			// PF. Le seguenti istruzioni servono a mantenere traccia degli operatori fuzzy, funzioni js e dizionary presenti nella pipeline
			docPipeline.setFuzzyOperators(pipeline.getFuzzyOperators());
			docPipeline.setJsFunctions(pipeline.getJsFunction());
			docPipeline.setDictionaries(pipeline.getDictionaries());

			DocumentDefinition doc = null;
			try {
				doc = caseEvaluator.evaluate(docPipeline, caseFilter);				
				if(doc != null)
					try {
						queue.put(doc);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
		            	throw new ExecuteProcessException("[SynchronizedFilterCycle]: terminated");
					}
			} catch (ScriptException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
            	throw new ExecuteProcessException("[SynchronizedFilterCycle]: terminated");
			}

    		
    		// fundamental
    		i += nThreads;  
    	}
    }



}
