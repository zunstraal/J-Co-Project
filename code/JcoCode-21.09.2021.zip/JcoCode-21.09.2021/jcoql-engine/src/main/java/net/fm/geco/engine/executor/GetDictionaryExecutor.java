package net.fm.geco.engine.executor;

import org.springframework.beans.factory.annotation.Autowired;

import net.fm.geco.engine.Pipeline;
import net.fm.geco.engine.annotation.Executor;
import net.fm.geco.engine.exception.ExecuteProcessException;
import net.fm.geco.engine.registry.DatabaseRegistry;
import net.fm.geco.model.command.GetDictionaryCommand;
import net.fm.geco.model.engine.IDatabase;
import net.fm.geco.model.engine.IDocumentCollection;

@Executor(GetDictionaryCommand.class)
public class GetDictionaryExecutor implements IExecutor<GetDictionaryCommand> {

	private DatabaseRegistry databaseRegistry;

	@Autowired
	public GetDictionaryExecutor(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}

	@Override
	public void execute(Pipeline pipeline, GetDictionaryCommand command) throws ExecuteProcessException {
		if (command.getDbName() != null) {
			IDatabase database = databaseRegistry.getDatabase(command.getDbName());
			if (database == null) {
				throw new ExecuteProcessException("[GET DICTIONARY]: Invalid database " + command.getDbName());
			}

			IDocumentCollection collection = database.getCollection(command.getCollectionName());
			pipeline.addDictionary (collection, command.getDictionary());
		} 
	}


}
