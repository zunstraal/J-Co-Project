package net.fm.geco.model.reference;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import net.fm.geco.model.FieldName;

public class FieldReferenceTest {

	@Test
	public void testFieldReference() {
		FieldReference ref = new FieldReference("c1", FieldName.fromString(".a1"));
		assertEquals("c1", ref.getCollectionAlias());
		assertEquals(1, ref.getFieldName().getLevel());
		assertEquals("a1", ref.getFieldName().getParts()[0]);
	}
	
	@Test
	public void testFieldReferenceFromString() {
		FieldReference ref = new FieldReference("c1", ".a1");
		assertEquals("c1", ref.getCollectionAlias());
		assertEquals(1, ref.getFieldName().getLevel());
		assertEquals("a1", ref.getFieldName().getParts()[0]);
	}

	@Test
	public void testFieldReferenceFromStringWithoutCollectionAlias() {
		FieldReference ref = new FieldReference("c1.a1");
		assertEquals("c1", ref.getCollectionAlias());
		assertEquals(1, ref.getFieldName().getLevel());
		assertEquals("a1", ref.getFieldName().getParts()[0]);
	}

}
