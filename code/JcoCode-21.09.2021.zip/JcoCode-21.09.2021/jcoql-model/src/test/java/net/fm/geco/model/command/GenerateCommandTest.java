package net.fm.geco.model.command;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.value.EValueType;

public class GenerateCommandTest {

	@Test
	public void testConstructor() {
		DocumentDefinition doc = DocumentDefinition.create()
			.withField().fromFieldReference("c1", ".c").add()
			.withField().fromDocument("d")
							.withField()
									.fromDocument("da")
										.withField().fromFieldReference("d1", "c1", ".a.a1").add()
										.withField().fromFieldReference("d2", "c1", ".a.a2").add()
									.buildField().add()
							.withField().fromFieldReference("e", "c1", ".b").add()
						.buildField().add()
		.build();


		GenerateCommand cmd = new GenerateCommand(doc, EGeometryAction.DROP, null);
		List<FieldDefinition> fields = cmd.getOutputDefinition().getFields();
		assertEquals(2, fields.size());
		assertEquals("c", fields.get(0).getName());
		assertEquals(EValueType.FIELD, fields.get(0).getValue().getType());
		assertEquals("d", fields.get(1).getName());
		assertEquals(EValueType.DOCUMENT, fields.get(1).getValue().getType());
		assertEquals(EGeometryAction.DROP, cmd.getGeometryAction());
		assertEquals(null, cmd.getGeometry());
	}

}
