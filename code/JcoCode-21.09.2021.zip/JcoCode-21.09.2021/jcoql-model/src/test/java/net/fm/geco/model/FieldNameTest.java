package net.fm.geco.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FieldNameTest {

	@Test
	public void testBasicFieldName() {
		FieldName fieldName = FieldName.fromString(".a");
		assertEquals(1, fieldName.getLevel());
		assertEquals("a", fieldName.getParts()[0]);
		assertEquals("a", fieldName.getFirstLevelName());
	}

	@Test
	public void testTwoLevelsFieldName() {
		FieldName fieldName = FieldName.fromString(".a.a1");
		assertEquals(2, fieldName.getLevel());
		assertEquals("a", fieldName.getParts()[0]);
		assertEquals("a1", fieldName.getParts()[1]);
		assertEquals("a", fieldName.getFirstLevelName());
	}

}
