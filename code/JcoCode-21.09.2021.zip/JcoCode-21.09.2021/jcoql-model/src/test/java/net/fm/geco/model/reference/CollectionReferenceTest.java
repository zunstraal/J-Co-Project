package net.fm.geco.model.reference;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CollectionReferenceTest {

	@Test
	public void testCollectionReferenceWithoutAlias() {
		CollectionReference ref = new CollectionReference("db", "c1");
		assertEquals("db", ref.getDatabaseName());
		assertEquals("c1", ref.getCollectionName());
		assertEquals("c1", ref.getAlias());
	}
	
	@Test
	public void testCollectionReferenceWithAlias() {
		CollectionReference ref = new CollectionReference("db", "c1", "a1");
		assertEquals("db", ref.getDatabaseName());
		assertEquals("c1", ref.getCollectionName());
		assertEquals("a1", ref.getAlias());
	}

}
