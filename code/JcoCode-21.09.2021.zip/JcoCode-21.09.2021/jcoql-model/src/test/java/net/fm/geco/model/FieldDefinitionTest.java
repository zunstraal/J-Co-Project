package net.fm.geco.model;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import net.fm.geco.model.value.EValueType;

public class FieldDefinitionTest {

	@Test
	public void testStringFieldDefinition() {
		FieldDefinition field = FieldDefinition.create().fromString("A", "a1").build();
		
		assertEquals("A", field.getName());
		assertEquals(EValueType.STRING, field.getValue().getType());
		assertEquals("a1", field.getValue().getStringValue());
	}
	
	@Test
	public void testIntegerFieldDefinition() {
		FieldDefinition field = FieldDefinition.create().fromInteger("A", 1).build();
		
		assertEquals("A", field.getName());
		assertEquals(EValueType.INTEGER, field.getValue().getType());
		assertEquals("1", field.getValue().getStringValue());
	}
	
	@Test
	public void testDecimalFieldDefinition() {
		FieldDefinition field = FieldDefinition.create().fromDecimal("A", BigDecimal.valueOf(3.5)).build();
		
		assertEquals("A", field.getName());
		assertEquals(EValueType.DECIMAL, field.getValue().getType());
		assertEquals("3.5", field.getValue().getStringValue());
	}
	
	@Test
	public void testFieldReferenceFieldDefinition() {
		FieldDefinition field = FieldDefinition.create().fromFieldReference("coll", FieldName.fromString(".a")).build();
		
		assertEquals("a", field.getName());
		assertEquals(EValueType.FIELD, field.getValue().getType());
	}

}
