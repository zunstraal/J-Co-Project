package net.fm.geco.model.value;

import java.util.List;

import geco.model.util.Expression;

public class FunctionJsValue implements Value {

    private String functionName;
    private List<Expression> parameters;

    public FunctionJsValue(String name, List<Expression> parameters) {
        this.functionName = name;
        this.parameters = parameters;
    }

    public String getFunctionName() {
        return functionName;
    }

    public List<Expression> getParameters() {
        return parameters;
    }

    @Override
    public EValueType getType() {
        return null;
    }

    @Override
    public String getStringValue() {
        return null;
    }

    @Override
    public Object getValue() {
        return null;
    }
}
