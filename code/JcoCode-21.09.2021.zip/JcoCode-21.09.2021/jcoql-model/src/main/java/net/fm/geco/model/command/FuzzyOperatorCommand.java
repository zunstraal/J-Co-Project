package net.fm.geco.model.command;

import java.util.List;

import geco.model.util.Expression;
import net.fm.geco.model.ParameterDefinition;
import net.fm.geco.model.PointDefinition;
import net.fm.geco.model.RangeDefinition;
import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.WhereCondition;

public class FuzzyOperatorCommand implements ICommand {

    private String fuzzyOperatorName;
    private List<ParameterDefinition> parameters;
    private WhereCondition precondition;
    private List<OperationTree> evaluate;
    private RangeDefinition range;
    private List<PointDefinition> polyline;

    private Expression expression;

    public FuzzyOperatorCommand(String name, List<ParameterDefinition> parameters, WhereCondition preCondition,
                                List<OperationTree> evaluate, RangeDefinition range, List<PointDefinition> polyline, Expression expression) {
        this.fuzzyOperatorName = name;
        this.parameters = parameters;
        this.precondition = preCondition;
        this.evaluate = evaluate;
        this.range = range;
        this.polyline = polyline;

        this.expression = expression;
    }

    public String getFuzzyOperatorName() {
        return fuzzyOperatorName;
    }

    public List<ParameterDefinition> getParameters() {
        return parameters;
    }

    public WhereCondition getPrecondition() {
        return precondition;
    }

    public List<OperationTree> getEvaluate() {
        return evaluate;
    }

    public RangeDefinition getRange() {
        return range;
    }

    public List<PointDefinition> getPolyline() {
        return polyline;
    }

    public Expression getExpression() {
		return expression;
	}

	@Override
    public String toString() {
        String stringVal = "CREATE FUZZY OPERATOR";
        return stringVal + " " + this.getFuzzyOperatorName();
    }

    public String getName () {
    	return "Fuzzy operator";
    }

}
