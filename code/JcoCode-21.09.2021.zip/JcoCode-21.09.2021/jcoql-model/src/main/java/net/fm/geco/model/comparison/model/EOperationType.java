package net.fm.geco.model.comparison.model;

public enum EOperationType {

	ADD("+"), SUB("-"), MUL("*"), DIV("/");

	private String operator;

	private EOperationType(String operator) {
		this.operator = operator;

	}

	public String getOperator() {

		return operator;
	}

	public EOperationType fromString(String operatorString) {

		EOperationType operator = null;
		for (EOperationType op : values()) {

			if (op.getOperator().equals(operatorString)) {
				operator = op;
				break;
			}
		}
		return operator;

	}

}
