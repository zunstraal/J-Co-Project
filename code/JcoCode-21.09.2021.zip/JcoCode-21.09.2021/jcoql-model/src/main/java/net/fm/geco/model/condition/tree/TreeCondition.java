package net.fm.geco.model.condition.tree;

import java.util.Collections;
import java.util.List;

import geco.model.util.Condition;
import geco.model.util.ConditionAnd;
import geco.model.util.ConditionNot;
import geco.model.util.ConditionOr;
import geco.model.util.Expression;
import geco.model.util.ExpressionFactor;
import geco.model.util.ExpressionTerm;
import geco.model.util.Field;
import geco.model.util.Predicate;
import geco.model.util.WithPredicate;
import geco.model.util.WithoutPredicate;
import net.fm.geco.model.comparison.util.ComparisonComputer;
import net.fm.geco.model.condition.FieldPresenceCondition;
import net.fm.geco.model.condition.FuzzyOperatorCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.IdCondition;
import net.fm.geco.model.condition.IfFailsCondition;
import net.fm.geco.model.condition.KnownCondition;
import net.fm.geco.model.condition.UnknownCondition;
import net.fm.geco.model.condition.ValueTypeCondition;
import net.fm.geco.model.condition.WithinFuzzySetsCondition;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;

public class TreeCondition implements ITreeModel,ICondition {

	private TreeNode root;
	private String alias;

	public TreeCondition(String cc) {
		root = null;
		this.alias = cc+".";
	}

	public TreeCondition(){
		root = null;
		this.alias = "";
	}

	@Override
	public TreeNode getRoot() {
		return root;
	}

	@Override
	public void parser2Engine(Condition condition) {
		parser2Engine(condition, this.root);
	}

	private void parser2Engine(Condition condition, TreeNode actualNode) {
		boolean flag = false;
		TreeNode node = null;
		ConditionAnd ca;
		ConditionOr co;
		ConditionNot cn;
		Predicate p;

		if (condition.type == Condition.AND_CONDITION) {
			ca = (ConditionAnd) condition;

			if (actualNode == null) {
				this.root = new TreeNode(EBooleanType.AND);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.AND));
			}

			for (int i = 0; i < ca.conditions.size(); i++) {
				if (flag) {
					parser2Engine(ca.conditions.get(i), node);
				} else {
					parser2Engine(ca.conditions.get(i), this.root);
				}
			}

		} else if (condition.type == Condition.OR_CONDITION) {
			co = (ConditionOr) condition;
			if (actualNode == null) {
				this.root = new TreeNode(EBooleanType.OR);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.OR));
			}

			for (int i = 0; i < co.conditions.size(); i++) {
				if (flag) {
					parser2Engine(co.conditions.get(i), node);
				} else {
					parser2Engine(co.conditions.get(i), this.root);
				}
			}
		} else if (condition.type == Condition.NOT_CONDITION) {

			cn = (ConditionNot) condition;			

			if (actualNode == null) {
				this.root = new TreeNode(EBooleanType.NOT);
				parser2Engine(cn.condition, this.root);
			} else {
				node = actualNode.addChild(new TreeNode(EBooleanType.NOT));
				parser2Engine(cn.condition, node);
			}
		} else if (condition.type == Condition.PREDICATE_CONDITION) {
			p = condition.predicate;
			computePredicate(p, actualNode);
		}

	}

	private void computePredicate(Predicate p, TreeNode actualNode) {
		List<Field> fieldList;
		WithPredicate w;
		WithoutPredicate wo;
		Expression e1;
		Expression e2;
		List<String> fuzzysetList;
		TreeNode node = null;
		boolean flag = false;


		if(p.type == Predicate.WITHIN_PREDICATE) {

			/*String alias2 = alias.replace(".", "");
			System.out.println(alias2);*/

			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL, TreeNode.WITHIN);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.WITHIN));
			}

			fuzzysetList = p.withinFuzzySets;

			for(String s : fuzzysetList) {
				if (flag) {
					node.addCondition(new WithinFuzzySetsCondition(s));
				} else {
					this.root.addCondition(new WithinFuzzySetsCondition(s));
				}
			}
		} else if(p.type == Predicate.KNOWN_PREDICATE) {
			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL, TreeNode.KNOWN);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.KNOWN));
			}

			fuzzysetList = p.knownFuzzySets;

			for(String s : fuzzysetList) {
				if (flag) {
					node.addCondition(new KnownCondition(s));
				} else {
					this.root.addCondition(new KnownCondition(s));
				}
			}
		} else if(p.type == Predicate.UNKNOWN_PREDICATE) {
			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL, TreeNode.UNKNOWN);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.UNKNOWN));
			}

			fuzzysetList = p.unknownFuzzySets;

			for(String s : fuzzysetList) {
				if (flag) {
					node.addCondition(new UnknownCondition(s));
				} else {
					this.root.addCondition(new UnknownCondition(s));
				}
			}
        } else if (p.type == Predicate.WITH_PREDICATE) {

			w = p.withPredicate;

			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL, TreeNode.WITH);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.WITH));
			}

			fieldList = w.fieldRefs;

			if(w.getTypeSelector() == Predicate.UNDEFINED){

				for (int i = 0; i < fieldList.size(); i++) {
					if (flag) {
						node.addCondition(new FieldPresenceCondition(
								new FieldReference(alias + fieldList.get(i).toString().substring(1))));
					} else {
						this.root.addCondition(new FieldPresenceCondition(
								new FieldReference(alias + fieldList.get(i).toString().substring(1))));
					}
				}
			} else {

				for (int i = 0; i < fieldList.size(); i++) {
					if (flag) {
						node.addCondition(new ValueTypeCondition(evaluateType(w.getTypeSelector()), new FieldValue(new FieldReference(alias + fieldList.get(i).toString().substring(1)))));
					} else {
						this.root.addCondition(new ValueTypeCondition(evaluateType(w.getTypeSelector()), new FieldValue(new FieldReference(alias + fieldList.get(i).toString().substring(1)))));
					}
				}
			}
		} else if (p.type == Predicate.WITHOUT_PREDICATE) {
			wo = p.withoutPredicate;

			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL, TreeNode.WITHOUT);
			} else {
				flag = true;
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.WITHOUT));
			}

			fieldList = wo.fieldRefs;
			for (int i = 0; i < fieldList.size(); i++) {
				if (flag) {
					node.addCondition(new FieldPresenceCondition(
							new FieldReference(alias + fieldList.get(i).toString().substring(1))));
				} else {
					this.root.addCondition(new FieldPresenceCondition(
							new FieldReference(alias + fieldList.get(i).toString().substring(1))));
				}
			}
		} else if(p.type == Predicate.IFFAILS_PREDICATE) { /* IF-FAILS PREDICATE  */
			TreeCondition treeCondition = new TreeCondition("Fuzzy Generate");
			treeCondition.parser2Engine(p.ifFails.ifFailsCondition);
			List<ICondition> listICondition = Collections.singletonList(treeCondition);

			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL, TreeNode.IF_FAILS);
				this.root.addCondition(new IfFailsCondition(listICondition, p.ifFails.ifFailsValue));
			} else {
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.IF_FAILS));
				node.addCondition(new IfFailsCondition(listICondition, p.ifFails.ifFailsValue));
			}
		} else if (p.type == Predicate.EXPRESSION_PREDICATE) {

			e1 = p.expression1;
			List<ExpressionTerm> l = e1.terms;

			/*if(l.size() != 1)
				throw new RuntimeException("Expression not allowed");*/

			// E' un casino
			for (ExpressionTerm e : l) {
				List<ExpressionFactor> lf = e.factors;
				/*if(lf.size()!= 1)
					throw new RuntimeException("Expression not allowed");*/
				for (ExpressionFactor f : lf) {
					if(f.type == 1) { /* VALUE */

					} else if (f.type == 2) { /* CONDITION */
						parser2Engine(f.condition, actualNode);

					} else if (f.type == 5) { /* FIELDNAME */
						throw new RuntimeException("Field References are not handled"); // ???????????
						/*FieldReference fr = new FieldReference(f.field.fields.toString());
						if (this.root == null) {
							this.root = new TreeNode(EBooleanType.NULL, TreeNode.FIELDNAME);
							this.root.addCondition(new FieldValueCondition(fr, new SimpleValue(f.value.value)));
						} else {
							node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.FIELDNAME));
							node.addCondition(new FieldValueCondition(fr, new SimpleValue(f.value.value)));
						}*/

					} else if(f.type == 3) { /* FUNZIONE */
						if (this.root == null) {
							this.root = new TreeNode(EBooleanType.NULL, TreeNode.FUNCTION);
							this.root.addCondition(new FuzzyOperatorCondition(f.function, f.functionParams));
						} else {
							node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.FUNCTION));
							node.addCondition(new FuzzyOperatorCondition(f.function, f.functionParams));
						}

					} else if(f.type == 4){ /* ID */
						if (this.root == null) {
							this.root = new TreeNode(EBooleanType.NULL, TreeNode.ID);
							this.root.addCondition(new IdCondition(f.id));
						} else {
							node = actualNode.addChild(new TreeNode(EBooleanType.NULL, TreeNode.ID));
							node.addCondition(new IdCondition(f.id));
						}

						/*boolean value;

						if(f.id.equals("true"))
							value = true;
						else if(f.id.equals("false"))
							value = false;
						else
							throw new RuntimeException("Only Boolean types are allowed");


						if (this.root == null) {
							this.root = new TreeNode(EBooleanType.NULL,TreeNode.UNDEFINED);

							if(value)
								this.root.addCondition(new BasicCondition(new BasicExpression(new SimpleValue(value), EOperator.EQUALS, new SimpleValue(value) )));
							else
								this.root.addCondition(new BasicCondition(new BasicExpression(new SimpleValue(value), EOperator.NOT_EQUALS, new SimpleValue(value) )));


						} else {
							node = actualNode.addChild(new TreeNode(EBooleanType.NULL,TreeNode.UNDEFINED));
							if(value)
								node.addCondition(new BasicCondition(new BasicExpression(new SimpleValue(value), EOperator.EQUALS, new SimpleValue(value) )));
							else
								node.addCondition(new BasicCondition(new BasicExpression(new SimpleValue(value), EOperator.NOT_EQUALS, new SimpleValue(value) )));
						}*/
					}
				}
			}

		} else if (p.type == Predicate.COMPARISON_PREDICATE) {
			e1 = p.expression1;
			e2 = p.expression2;

			ComparisonComputer cc = new ComparisonComputer(e1, e2, p.comparator, alias);

			if (this.root == null) {
				this.root = new TreeNode(EBooleanType.NULL);
				this.root.addCondition(cc.evaluateCondition());
				
			} else {
				node = actualNode.addChild(new TreeNode(EBooleanType.NULL));

				node.addCondition(cc.evaluateCondition());
			}
		}
	}


	private EValueType evaluateType(int selector){

	if(selector == 0){
		return EValueType.SIMPLE;
	}else if(selector == 1){
		return EValueType.COMPLEX;
	}else if(selector == 2){
		return EValueType.ARRAY;
	}else if(selector == 3){
		return EValueType.STRING;
	}else if(selector == 4){
		return EValueType.NUMBER;
	}else if(selector == 5){
		return EValueType.INTEGER;
	}else if(selector == 6){
		return EValueType.DECIMAL;
	}else if(selector == 7){
		return EValueType.GEOMETRY;
	}else
		throw new RuntimeException("EValueType not managed");
	}

	public String printTree() {
		return printTree(this.root, 0);

	}

	private String printTree(TreeNode root, int level) {
		String st = "";
		for (int i = 0; i < level; i++) {
            st += "\t";
		}
		
        st += root.toString()+"\n";
		if (!root.getChildren().isEmpty()) {

			for (TreeNode child : root.getChildren()) {
				st += printTree(child, level + 1);
			}
		}
		return st;
	}

	public String getCurrentCollection(){
		return alias;
	}

	@Override
	public boolean evaluate() {
		return false;
	}

}
