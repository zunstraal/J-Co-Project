package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.JSFunction;
import net.fm.geco.model.ParameterDefinition;
import net.fm.geco.model.condition.WhereCondition;

public class JavascriptFunctionCommand implements ICommand {
    private JSFunction jsFunction;

    public JavascriptFunctionCommand(String jsFunctionName, List<ParameterDefinition> parameters, WhereCondition precondition, String instruction) {
        jsFunction = new JSFunction(jsFunctionName, parameters, precondition, instruction);
    }

    public JSFunction getJsFunction() {
        return jsFunction;
    }

    @Override
    public String toString() {
        String stringVal = "CREATE JAVASCRIPT FUNCTION ";
        return stringVal + this.jsFunction.getFunctionName();
    }

    public String getName () {
    	return "Javascript function";
    }

}
