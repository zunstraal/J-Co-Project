package net.fm.geco.model.value;

import com.fasterxml.jackson.annotation.JsonIgnore;

public interface Value{
	
	EValueType getType();

	@JsonIgnore
	String getStringValue();

	Object getValue();
		
}
