package net.fm.geco.model;

public class SetFuzzySetsReference {

    private int type;
    private String leftRight;
    private String fuzzySet;
    private String as;
    private String function;
    private String parameter;
    private int parameterType;

    public SetFuzzySetsReference(int type, String leftRight, String fuzzySet, String as, String function, String parameter, int parameterType) {
        this.type = type;
        this.leftRight = leftRight;
        this.fuzzySet = fuzzySet;
        this.as = as;
        this.function = function;
        this.parameter = parameter;
        this.parameterType = parameterType;
    }

    public int getType() {
        return type;
    }

    public String getLeftRight() {
        return leftRight;
    }

    public String getFuzzySet() {
        return fuzzySet;
    }

    public String getAs() {
        return as;
    }

    public String getFunction() {
        return function;
    }

    public String getParameter() {
        return parameter;
    }

    public int getParameterType() {
        return parameterType;
    }
}
