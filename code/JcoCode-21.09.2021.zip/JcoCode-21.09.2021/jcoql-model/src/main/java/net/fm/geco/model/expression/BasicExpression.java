package net.fm.geco.model.expression;

import net.fm.geco.model.EOperator;
import net.fm.geco.model.value.Value;

public class BasicExpression implements IExpression {

	private Value left;

	private EOperator operator;

	private Value right;

	public BasicExpression(Value left, EOperator operator, Value right) {
		this.left = left;
		this.operator = operator;
		this.right = right;
	}

	public Value getLeft() {
		return left;
	}

	public EOperator getOperator() {
		return operator;
	}

	public Value getRight() {
		return right;
	}

	@Override
	public String toString() {
		return left.toString() + " " + operator + " " + right.toString();
	}
}
