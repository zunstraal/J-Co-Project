package net.fm.geco.model.command;

import net.fm.geco.model.condition.WhereCondition;


public class GenerateFuzzyCommand implements ICommand {

    private String nameFuzzySet;
    private WhereCondition foUsingCond;

    public GenerateFuzzyCommand(String nameFuzzySet, WhereCondition foUsingCond) {
        this.nameFuzzySet = nameFuzzySet;
        this.foUsingCond = foUsingCond;
    }

    public WhereCondition getFoUsingCond() {
        return foUsingCond;
    }

    public String getNameFuzzySet() {
        return nameFuzzySet;
    }

    public String getName () {
    	return "Generate fuzzy";
    }

}
