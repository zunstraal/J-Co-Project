package net.fm.geco.model.builder;

import java.util.ArrayList;
import java.util.List;

import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.value.DocumentValue;

public class DocumentDefinitionBuilder {
	
	private String fieldName;
	
	private List<FieldDefinition> fields;
	private FieldDefinitionBuilder parentField;
	
	public static DocumentDefinitionBuilder create() {
		return new DocumentDefinitionBuilder();
	}
	
	public DocumentDefinitionBuilder() {
		this(null, null);
	}
	
	public DocumentDefinitionBuilder(String fieldName) {
		this(fieldName, null);
	}
	
	public DocumentDefinitionBuilder(String fieldName, FieldDefinitionBuilder parent) {
		this.fieldName = fieldName;
		this.fields = new ArrayList<FieldDefinition>();
		this.parentField = parent;
	}
	

	public DocumentDefinitionBuilder withField(FieldDefinition fieldDefinition) {
		fields.add(fieldDefinition);
		return this;
	}
	
	public DocumentDefinition build() {
		return new DocumentDefinition(fieldName, fields);
	}
	
	public FieldDefinitionBuilder withField() {
		return new FieldDefinitionBuilder(this);
	}
	
	public FieldDefinitionBuilder buildField() {
		return this.parentField.fromDocument(fieldName, new DocumentValue(fields));
	}

}
