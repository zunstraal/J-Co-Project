package net.fm.geco.model.command;

public class LogCommand implements ICommand {

	public String getName () {
    	return "Log";
    }

}
