package net.fm.geco.model.condition.join;

public class OrientationJoinCondition implements JoinCondition {

	private final static double QUANTUM = 11.25;
	
	private EFrom fromOrientation;
	private EOrientation orientation;
	private double delta;
	
	public OrientationJoinCondition(EFrom fromOrientation, EOrientation orientation) {
		this.fromOrientation = fromOrientation;
		this.orientation = orientation;
		this.delta = QUANTUM;
	}
	
	public OrientationJoinCondition(EFrom fromOrientation, EOrientation orientation,float delta) {

		this.fromOrientation = fromOrientation;
		this.orientation = orientation;
		this.delta =  delta;
	}

	public EFrom getFromOrientation() {
		return fromOrientation;
	}
	
	public EOrientation getOrientation(){
		return orientation;
	}
	
	public double getDelta(){
		return delta;
	}
}
