package net.fm.geco.model.command;

public interface ICommand {
	public String getName ();
	
}
