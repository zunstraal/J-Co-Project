package net.fm.geco.model.condition;

public interface SimpleCondition extends ICondition{

}
