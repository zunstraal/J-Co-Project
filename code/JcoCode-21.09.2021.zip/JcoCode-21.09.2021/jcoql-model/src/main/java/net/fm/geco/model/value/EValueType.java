package net.fm.geco.model.value;

public enum EValueType {
	NULL,
	SIMPLE,
	COMPLEX,
	STRING,
	BOOLEAN,
	NUMBER,
	INTEGER,
	DECIMAL,
	ARRAY,
	FIELD,
	DOCUMENT,
	GEOMETRY,
	DATE,
	ROOTABLE_FIELD,    					// PF - added 
	COUNT,    							// PF - added to handle COUNT
	TO_STRING_FIELD,    				// PF - added to handle TO_STRING
	TO_INT_FIELD,    					// PF - added to handle TO_INT
	TO_FLOAT_FIELD,    					// PF - added to handle TO_FLOAT
	TO_BOOL_FIELD,    					// PF - added to handle TO_BOOL
	TO_SERIALIZE_FIELD,    				// PF - added to handle SERIALIZE
	MEMBERSHIP_OF_FIELD,    			// PF - added to handle MEMBERSHIP_OF
	TRANSLATE_FIELD,    				// PF - added to handle TRANSLATE
	BUILT_IN_FUNCTION    				// PF - added to handle BUILT IN FUNCTIONS
}
