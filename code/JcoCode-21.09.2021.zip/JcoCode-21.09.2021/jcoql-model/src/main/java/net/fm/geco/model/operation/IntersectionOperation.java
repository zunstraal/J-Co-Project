package net.fm.geco.model.operation;

public class IntersectionOperation implements IGeometryOperation {

}
