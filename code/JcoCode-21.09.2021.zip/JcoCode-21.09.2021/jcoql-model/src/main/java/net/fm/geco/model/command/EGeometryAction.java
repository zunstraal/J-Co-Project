package net.fm.geco.model.command;

public enum EGeometryAction {
	KEEP,
	DROP,
	GENERATE;
}
