package net.fm.geco.model.condition;

import net.fm.geco.model.expression.IExpression;

public class BasicCondition implements ICondition {

	private IExpression expression;

	public BasicCondition(IExpression expression) {
		this.expression = expression;
	}

	public IExpression getExpression() {
		return this.expression;
	}

	@Override
	public String toString() {
		return expression.toString();
	}

}
