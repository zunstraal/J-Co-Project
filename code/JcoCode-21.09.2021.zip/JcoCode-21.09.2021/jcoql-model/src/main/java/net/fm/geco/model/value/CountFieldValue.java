package net.fm.geco.model.value;

import net.fm.geco.model.FieldName;
import net.fm.geco.model.reference.FieldReference;

public class CountFieldValue implements Value {
	
	private FieldReference fieldReference;
	
	public CountFieldValue(FieldReference fieldReference) {
		this.fieldReference = fieldReference;
	}

	public CountFieldValue(String collectionAlias, String fieldName) {
		this.fieldReference = new FieldReference(collectionAlias, fieldName);
	}

	public CountFieldValue(String collectionAlias, FieldName fieldName) {
		this.fieldReference = new FieldReference(collectionAlias, fieldName);
	}
	
	@Override
	public EValueType getType() {
		return EValueType.COUNT;
	}

	public FieldReference getFieldReference() {
		return fieldReference;
	}
	
	@Override
	public String getStringValue() {
		return toString();
	}

	@Override
	public Object getValue() {
		return fieldReference;
	}

	@Override
	public String toString() {
		return fieldReference.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fieldReference == null) ? 0 : fieldReference.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		CountFieldValue other = (CountFieldValue) obj;
		if (fieldReference == null) {
			if (other.fieldReference != null) {
				return false;
			}
		} else if (!fieldReference.equals(other.fieldReference)) {
			return false;
		}
		return true;
	}

}
