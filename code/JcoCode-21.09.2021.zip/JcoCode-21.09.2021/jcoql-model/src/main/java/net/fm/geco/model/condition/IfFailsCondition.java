package net.fm.geco.model.condition;

import java.util.List;


public class IfFailsCondition implements ICondition {

    private List<ICondition> conditions;
    private String defaultValue;


    public IfFailsCondition(List<ICondition> conditions, String defaultValue) {
        this.conditions = conditions;
        this.defaultValue = defaultValue;
    }

    public List<ICondition> getConditions() {
        return conditions;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public String toString() {
        return "IF-FAILS";
    }
}
