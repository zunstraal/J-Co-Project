package net.fm.geco.model.condition;

public interface CompoundCondition extends ICondition{

}
