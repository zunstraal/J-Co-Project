package net.fm.geco.model;

import java.util.List;

import net.fm.geco.model.condition.WhereCondition;

public class JSFunction {
    private String functionName;
    private List<ParameterDefinition> parameters;
    private WhereCondition preCondition;
    private String body;

    public JSFunction(String fName, List<ParameterDefinition> parameters, WhereCondition preCondition, String body) {
        this.functionName = fName;
        this.parameters = parameters;
        this.preCondition = preCondition;
        this.body = body;
    }

    public boolean equals(String name, List<ParameterDefinition> parameters) {
        if(!this.functionName.equals(name)) {
            return false;
        } else {
            if(this.parameters.size() != parameters.size()) {
                return false;
            } else {
                for(int p = 0; p < parameters.size(); p++) {
                    if(!this.parameters.get(p).type.equals(parameters.get(p).type)) {
                        return false;
                    }
                }
                return true;
            }
        }
    }

    public String getFunctionName() {
        return functionName;
    }

    public List<ParameterDefinition> getParameters() {
        return parameters;
    }

    public WhereCondition getPreCondition() {
        return preCondition;
    }

    public String getBody() {
        return body;
    }
}
