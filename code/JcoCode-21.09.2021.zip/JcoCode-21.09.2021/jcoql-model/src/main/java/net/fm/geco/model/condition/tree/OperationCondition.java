package net.fm.geco.model.condition.tree;

import net.fm.geco.model.EOperator;
import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.value.Value;

public class OperationCondition implements ICondition {

	private OperationTree operationTreeLeft;
	private OperationTree operationTreeRight;
	Value value;

	EOperator operatorType;
	
	public OperationCondition(OperationTree operationTreeLeft,OperationTree operationTreeRight,EOperator operatorType) {

		this.operationTreeLeft = operationTreeLeft;
		this.operationTreeRight = operationTreeRight;
		value = null;
		this.operatorType = operatorType;

	}

	public OperationCondition(OperationTree operationTreeLeft, Value value, EOperator operatorType) {

		this.operationTreeLeft = operationTreeLeft;
		this.operationTreeRight = null;
		this.value = value;
		this.operatorType = operatorType;


	}

	public OperationCondition(Value value, OperationTree operationTreeRight,EOperator operatorType) {

		this.operationTreeLeft = null;
		this.operationTreeRight = operationTreeRight;
		this.value = value;
		this.operatorType = operatorType;

	}

	public OperationTree getOperationTreeLeft() {

		return operationTreeLeft;

	}

	public OperationTree getOperationTreeRight() {

		return operationTreeRight;

	}

	public Value getValue() {

		return value;
	}
	
	public EOperator getOperatorType(){
		
		return operatorType;
	}
	
	@Override
	public String toString(){

		if(value == null) return operationTreeLeft.toString() + operatorType.toString() + operationTreeRight.toString();
		else if(operationTreeLeft == null) return value + operatorType.toString() + operationTreeRight.toString();
		else if(operationTreeRight == null) return operationTreeLeft.toString() + operatorType.toString() + value;
		
		return null;
		
	}

}
