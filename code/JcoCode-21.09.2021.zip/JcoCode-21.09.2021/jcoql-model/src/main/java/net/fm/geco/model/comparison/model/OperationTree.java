package net.fm.geco.model.comparison.model;


import geco.model.util.Expression;
import geco.model.util.ExpressionFactor;
import geco.model.util.ExpressionTerm;


public class OperationTree {


    private OperationNode root;
    private String alias;
    private Expression expression;
    OperationNode left = null, right = null;


    public OperationTree() {

    }

    // OperationNode node2 = null;
    public OperationTree(String currentCollection) {

        this.root = null;
        this.alias = currentCollection;

    }

    public void expression2Tree(Expression e) {

        this.expression = e;
        expression2Tree(e, root, null);

    }

    // lastNode indica il nodo inserito in precedenza
    private void expression2Tree(Expression e, OperationNode actualNode, OperationNode parent) {

        if( e.operators.size() == 1 && e.operators.get(0).equals("") && e.terms.size() == 1
                && e.terms.get(0).factors.size() ==1 && e.terms.get(0).factors.get(0).type == ExpressionFactor.SUBCONDITION){

            if(e.terms.get(0).factors.get(0).condition.type != 4)
                throw new RuntimeException("Invalid Expression at: " + e.toString());

            expression2Tree(e.terms.get(0).factors.get(0).condition.predicate.expression1,actualNode,parent);

        } else {
            for (int i = e.terms.size() - 1; i >= 0; i--) {
                String op = e.operators.get(i);

                if (op != "") {
                    if (this.root == null) {
                        this.root = new OperationNode(string2OperatorType(op), alias);
                        actualNode = this.root;
                    } else if (parent == null) {
                        if (actualNode == null) {
                            actualNode = new OperationNode(string2OperatorType(op), alias);

                        } else if (actualNode != null) {

                            if (actualNode.getRight() != null && actualNode.getLeft() == null) {
                                left = actualNode.addLeft(new OperationNode(string2OperatorType(op), alias));
                                actualNode = left;
                            }else if (actualNode.getRight() == null && actualNode.getLeft() == null) {
                                right = actualNode.addRight(new OperationNode(string2OperatorType(op), alias));
                                //System.out.println("ho aggiunto a destra di (" + actualNode.getType() + ") il figlioo ("
                                        //+ right.toString() + ")");
                                actualNode = right;
                            }
                        }
                    }
                    /*
                     * caso in cui abbiamo annidamento quindi ho parentesi ...così
                     * non può funzionare perchè resto chiuso in un ramo dell'albero
                     */
                    else {
                        if (actualNode == null) {
                            actualNode = new OperationNode(string2OperatorType(op), alias);

                            /*
                             * aggancio i nuovi nodi al parent in base al ramo senza
                             * nodi
                             */

                            if (parent.getRight() == null)
                                parent.right = actualNode;
                            else
                                parent.left = actualNode;

                        } else if (actualNode != null) {
                            if (actualNode.getRight() != null && actualNode.getLeft() == null) {
                                left = actualNode.addLeft(new OperationNode(string2OperatorType(op), alias));
                                actualNode = left;
                            } else if (actualNode.getRight() == null && actualNode.getLeft() == null) {
                                right = actualNode.addRight(new OperationNode(string2OperatorType(op), alias));
                                //System.out.println("ho aggiunto a destra di (" + actualNode.getType() + ") il figlioo ("
                                        //+ right.toString() + ")");
                                actualNode = right;
                            } else
                                actualNode = parent;
                        }
                    }
                }

                ExpressionTerm term = e.terms.get(i);

                evaluateTerm(term, actualNode, parent);
            }
        }
    }

    private void evaluateTerm(ExpressionTerm term, OperationNode actualNode, OperationNode parent) {

        for (int i = term.factors.size() - 1; i >= 0; i--) {
            String op = term.operators.get(i); // il primo è nullo
            if (op != "") {
                if (this.root == null) {
                    this.root = new OperationNode(string2OperatorType(op), alias);
                    actualNode = this.root;

                } else

                if (parent == null) {
                    if (actualNode == null) {
                        actualNode = new OperationNode(string2OperatorType(op), alias);
                    } else if (actualNode != null) {

                        if (actualNode.getRight() != null && actualNode.getLeft() == null) {
                            left = actualNode.addLeft(new OperationNode(string2OperatorType(op), alias));
                            actualNode = left;
                        }else if (actualNode.getRight() == null && actualNode.getLeft() == null) {
                            right = actualNode.addRight(new OperationNode(string2OperatorType(op), alias));
                            /*System.out.println("ho aggiunto a destra di (" + actualNode.getType() + ") il figlioo ("
                                    + right.toString() + ")");*/
                            actualNode = right;
                        }
                    }
                }
                /*
                 * caso in cui abbiamo annidamento quindi ho parentesi ...così
                 * non può funzionare perchè resto chiuso in un ramo dell'albero
                 */
                else {
                    if (actualNode == null) {
                        actualNode = new OperationNode(string2OperatorType(op), alias);

                        /*
                         * aggancio i nuovi nodi al parent in base al ramo senza
                         * nodi
                         */

                        if (parent.getRight() == null)
                            parent.right = actualNode;
                        else
                            parent.left = actualNode;
                    } else if (actualNode != null) {
                        if (actualNode.getRight() != null && actualNode.getLeft() == null) {
                            left = actualNode.addLeft(new OperationNode(string2OperatorType(op), alias));
                            actualNode = left;
                        }else if (actualNode.getRight() == null && actualNode.getLeft() == null) {
                            right = actualNode.addRight(new OperationNode(string2OperatorType(op), alias));
                            /*System.out.println("ho aggiunto a destra di (" + actualNode.getType() + ") il figlioo ("
                                    + right.toString() + ")");*/
                            actualNode = right;
                        } else
                            actualNode = parent;
                    }
                }
            }
            ExpressionFactor factor = term.factors.get(i);
            evaluateFactor(factor, actualNode);
        }
    }

    private void evaluateFactor(ExpressionFactor factor, OperationNode actualNode) {

        /* VALUE */
        if (factor.type == 1) {
            //System.out.println("SONO UN VALUE");
            if(actualNode != null) {
                if (actualNode.getRight() == null) {
                    right = actualNode.addRight(new OperationNode(factor, alias));
                } else if (actualNode.getLeft() == null && actualNode.getRight() != null) {
                    left = actualNode.addLeft(new OperationNode(factor, alias));
                }
            } else {
                this.root = new OperationNode(factor, alias);
            }
        }
        /* FIELDNAME */
        else if (factor.type == 5) {
            if(actualNode != null) {
                if (actualNode.getRight() == null) {
                    //System.out.println("Type: " + factor.type + " " + factor.field);
                    right = actualNode.addRight(new OperationNode(factor, alias));
                } else if (actualNode.getLeft() == null && actualNode.getRight() != null) {
                    left = actualNode.addLeft(new OperationNode(factor, alias));
                }
            } else {
                this.root = new OperationNode(factor, alias);
            }
        }
        /* SUBCONDITION */
        else if (factor.type == 2) {
            //System.out.println("SONO UNA SUB CONDITION");
           Expression eTemp=factor.condition.predicate.expression1;
            if(eTemp.terms.size()==1 && eTemp.terms.get(0).factors.size()==1){
                evaluateFactor(eTemp.terms.get(0).factors.get(0), actualNode);
            }else {
                if(factor.condition.type != 4)
                    throw new RuntimeException("Invalid Expression at: " + factor.toString());

                if (actualNode.getRight() == null) {
                    expression2Tree(factor.condition.predicate.expression1, actualNode.right, actualNode);
                } else if (actualNode.getLeft() == null && actualNode.getRight() != null) {
                    expression2Tree(factor.condition.predicate.expression1, actualNode.left, actualNode);
                }
            }
        /* FUNCTION aggiunto */
        } else if(factor.type == 3) {
            //System.out.println("SONO UNA FUNZIONE JS");
            if(actualNode != null) {
                if (actualNode.getRight() == null) {
                    right = actualNode.addRight(new OperationNode(factor, alias));
                } else if (actualNode.getLeft() == null && actualNode.getRight() != null) {
                    left = actualNode.addLeft(new OperationNode(factor, alias));
                }
            } else {
                this.root = new OperationNode(factor, alias);
            }
        /* ID aggiunto */
        } else if(factor.type == 4) {
            if(actualNode != null) {
                if (actualNode.getRight() == null) {
                    right = actualNode.addRight(new OperationNode(factor, alias));
                } else if (actualNode.getLeft() == null && actualNode.getRight() != null) {
                    left = actualNode.addLeft(new OperationNode(factor, alias));
                }
            } else {
                this.root = new OperationNode(factor, alias);
            }
        }

    }

    /* metodo per castare da stringa a eval */
    private EOperationType string2OperatorType(String operator) {
        if (operator.equals("+"))
            return EOperationType.ADD;
        if (operator.equals("-"))
            return EOperationType.SUB;
        if (operator.equals("*"))
            return EOperationType.MUL;
        if (operator.equals("\\"))
            return EOperationType.DIV;
        return null;
    }

    public String printTree() {

        return printTree(root, 0);
    }

    private String printTree(OperationNode root, int level) {
    	String st = "";
    	
        if (root != null) {
            for (int i = 0; i < level; i++) {
                st += "\t";
            }
            st += root.toString()+"\n";
            st += printTree(root.getRight(), level + 1);
            st += printTree(root.getLeft(), level + 1);
        }
        return st;
    }

    public OperationNode getRoot(){
        return this.root;
    }

    public String toString(){
        return expression.toString();
    }

}