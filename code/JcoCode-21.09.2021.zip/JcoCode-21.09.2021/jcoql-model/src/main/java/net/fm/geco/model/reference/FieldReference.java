package net.fm.geco.model.reference;

import net.fm.geco.model.FieldName;
import net.fm.geco.model.exception.InvalidCollectionAliasException;

public class FieldReference{

	private String collectionAlias;
	
	private FieldName fieldName;
	
	public FieldReference(String collectionAlias, FieldName fieldName) {
		this.collectionAlias = collectionAlias;
		this.fieldName = fieldName;
	}
	
	public FieldReference(String collectionAlias, String fieldName) {
		this.collectionAlias = collectionAlias;
		this.fieldName = FieldName.fromString(fieldName);
	}
	
	public FieldReference(String fieldName) {
		if(fieldName.startsWith(".")) {
			throw new InvalidCollectionAliasException();
		} else {
			String[] parts = fieldName.split("\\.");
			this.collectionAlias = parts[0];
			this.fieldName = FieldName.fromString(fieldName.substring(this.collectionAlias.length()));
		}
	}

	public String getCollectionAlias() {
		return collectionAlias;
	}

	public FieldName getFieldName() {
		return fieldName;
	}

	@Override
	public String toString() {
		return this.collectionAlias + "." + this.fieldName.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collectionAlias == null) ? 0 : collectionAlias.hashCode());
		result = prime * result + ((fieldName == null) ? 0 : fieldName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		FieldReference other = (FieldReference) obj;
		if (collectionAlias == null) {
			if (other.collectionAlias != null) {
				return false;
			}
		} else if (!collectionAlias.equals(other.collectionAlias)) {
			return false;
		}
		if (fieldName == null) {
			if (other.fieldName != null) {
				return false;
			}
		} else if (!fieldName.equals(other.fieldName)) {
			return false;
		}
		return true;
	}
	
}
