package net.fm.geco.model.command;

import java.util.List;

public class KeepingDroppingFuzzySetsCommand {

    private List<String> fuzzySets;
    int type;


    public KeepingDroppingFuzzySetsCommand(List<String> fuzzySets, int type) {
        this.fuzzySets = fuzzySets;
        this.type = type;
    }

    public List<String> getFuzzySets() {
        return fuzzySets;
    }

    public int getType() {
        return type;
    }
}
