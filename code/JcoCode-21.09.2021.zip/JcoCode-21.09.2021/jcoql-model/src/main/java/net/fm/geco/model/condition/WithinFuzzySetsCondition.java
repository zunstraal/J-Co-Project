package net.fm.geco.model.condition;

public class WithinFuzzySetsCondition implements ICondition {

    private String nameFuzzySet;

    public WithinFuzzySetsCondition(String name) {
        nameFuzzySet = name;
    }

    public String getNameFuzzySet() {
        return nameFuzzySet;
    }

    @Override
    public String toString() {
        String str = "WITHIN FUZZY SETS ";
        str += nameFuzzySet;
        return str;
    }
}
