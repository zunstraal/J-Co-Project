package net.fm.geco.model.value;

import java.math.BigDecimal;
import java.util.Date;


public class SimpleValue implements Value, Comparable<SimpleValue>{

	private String stringValue;

	private BigDecimal decimalValue;

	private Boolean booleanValue;

	private EValueType valueType;

	private Date dateValue;

	public SimpleValue() {
		valueType = EValueType.NULL;
	}

	public SimpleValue(String value) {
		valueType = EValueType.STRING;
// PF	verify if it is beeter this way:  if(value.startsWith("\"") || value.startsWith("'")) {   // PF	- verify if it is beeter this way:
		if(value.startsWith("\"")) {
			stringValue = value.substring(1, value.length()-1);
		} else {
			stringValue = value;
		}
	}

	public SimpleValue(BigDecimal value) {
		valueType = EValueType.DECIMAL;
		decimalValue = value;
	}

	public SimpleValue(Boolean value) {
		valueType = EValueType.BOOLEAN;
		booleanValue = value;
	}

	public SimpleValue(Integer value) {
		valueType = EValueType.INTEGER;
		decimalValue = BigDecimal.valueOf(value.longValue());
	}

	public SimpleValue(Long value){
		valueType = EValueType.INTEGER;
		decimalValue = BigDecimal.valueOf(value);
	}


	public SimpleValue(Double value) {
		valueType = EValueType.DECIMAL;
		decimalValue = BigDecimal.valueOf(value);
	}

	public SimpleValue(Date value) {
		valueType = EValueType.DATE;
		dateValue = value;
	}

	@Override
	public EValueType getType() {
		return valueType;
	}

	@Override
	public String getStringValue() {
		String stringVal = "";
		switch(valueType) {
		case STRING:
			stringVal = stringValue.replace("\"", "'");
			stringVal = "\"" + stringVal + "\"";
			break;
		case DATE:
			stringVal = dateValue.toString();
			break;
		case BOOLEAN:
			stringVal = booleanValue.toString();
			break;
		case DECIMAL:

		case INTEGER:
			stringVal = decimalValue.toPlainString();
			break;
		default:
			break;
		}
		return stringVal;
	}

	@Override
	public Object getValue() {
		Object val = null;
		switch(valueType) {
		case STRING:
			val = stringValue;
			break;
		case DATE:
			val = dateValue;
			break;
		case BOOLEAN:
			val = booleanValue;
			break;
		case DECIMAL:
			val = decimalValue.doubleValue();
			break;
		case INTEGER:
			val = decimalValue.longValue();
			break;
		default:
			break;
		}
		return val;
	}

	@Override
	public String toString() {
		return getStringValue();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dateValue == null) ? 0 : dateValue.hashCode());
		result = prime * result + ((booleanValue == null) ? 0 : booleanValue.hashCode());
		result = prime * result + ((decimalValue == null) ? 0 : decimalValue.hashCode());
		result = prime * result + ((stringValue == null) ? 0 : stringValue.hashCode());
		result = prime * result + ((valueType == null) ? 0 : valueType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		SimpleValue other = (SimpleValue) obj;
		if (valueType != other.valueType) {
			return false;
		}
		switch(valueType) {
		case BOOLEAN:
			if (booleanValue == null) {
				if (other.booleanValue != null) {
					return false;
				}
			} else if (!booleanValue.equals(other.booleanValue)) {
				return false;
			}
			break;
		case DECIMAL:
		case INTEGER:
			if (decimalValue == null) {
				if (other.decimalValue != null) {
					return false;
				}
			} else if (!decimalValue.equals(other.decimalValue)) {
				return false;
			}
			break;
		case STRING:
			if (stringValue == null) {
				if (other.stringValue != null) {
					return false;
				}
			} else if (!stringValue.equals(other.stringValue)) {
				return false;
			}
			break;
		case DATE:
			if(dateValue == null){
				if(other.dateValue != null){
					return false;
				}
			}else if(!dateValue.equals(other.dateValue)){
				return false;
			}
			break;
			/* controllo sul value null aggiunto 6-06-2017*/
		case NULL:
			if (other.getType() == EValueType.NULL){
				return true;
			}
			break;

			/* */
		default:
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(SimpleValue v) {

		double temp;
		switch(valueType) {
			case STRING:
				if(v.getType() == EValueType.STRING)
					return stringValue.compareTo((String)v.getValue());
			case BOOLEAN:
					throw new RuntimeException("Comparable not defined for booleans");
			case DECIMAL:	
				if(v.getType()== EValueType.DECIMAL)
					temp = (decimalValue.doubleValue() - ((Double)v.getValue()));
				else if(v.getType()== EValueType.INTEGER)
					temp = (decimalValue.doubleValue() - ((Long)v.getValue()));
				else throw new RuntimeException("Uncomparable types: " +valueType + " and " +v.getType() );

				if(temp > 0 )
					return 1;
				else if(temp < 0)
					return -1;
				else return 0;
			case INTEGER:
				if(v.getType()==EValueType.INTEGER)
					return (int) (decimalValue.longValue() - ((Long)v.getValue()));
				if(v.getType()==EValueType.DECIMAL)
					return (int) (decimalValue.longValue() - ((Double)v.getValue()));
			case DATE:
				if(v.getType()==EValueType.DATE)
					return dateValue.compareTo(v.dateValue);
			default:
				throw new RuntimeException("Uncomparable types: " +valueType + " and " +v.getType() );
		}
	}


}



