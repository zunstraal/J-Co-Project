package net.fm.geco.model.condition;

public class OrCondition implements ICondition {

	private BasicCondition left;
	
	private BasicCondition right;
	
	public OrCondition(BasicCondition left, BasicCondition right) {
		this.left = left;
		this.right = right;
	}
	
	public BasicCondition getLeft() {
		return left;
	}
	
	public BasicCondition getRight() {
		return right;
	}
	
	@Override
	public String toString() {
		return left.toString() + " OR " + right.toString();
	}
}
