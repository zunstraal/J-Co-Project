package net.fm.geco.model.command;

public class SetIntermediateCommand implements ICommand {
	
	private String collectionName;
	
	public SetIntermediateCommand(String collectionName) {
		this.collectionName = collectionName;
	}
	
	public String getCollectionName() {
		return collectionName;
	}

	@Override
	public String toString() {
		return "SET INTERMEDIATE " + collectionName;
	}
	
    public String getName () {
    	return "Set intermediate";
    }

	
}
