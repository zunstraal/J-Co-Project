package net.fm.geco.model.condition;

import net.fm.geco.model.reference.FieldReference;

public class FieldPresenceCondition implements ICondition {

	private FieldReference field;
	
	public FieldPresenceCondition(FieldReference field) {
		this.field = field;
	}

	public FieldReference getField() {
		return field;
	}
	
	//aggiunto
	@Override
	public String toString() {
		return field.toString();
	}
}
