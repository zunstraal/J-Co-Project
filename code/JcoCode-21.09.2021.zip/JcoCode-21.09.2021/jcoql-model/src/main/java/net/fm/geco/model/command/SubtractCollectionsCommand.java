package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.reference.CollectionReference;

public class SubtractCollectionsCommand implements ICommand {
	
	private List<CollectionReference> collections;
	
	public SubtractCollectionsCommand(List<CollectionReference> collections) {
		this.collections = collections;
	}

	public List<CollectionReference> getCollections() {
		return collections;
	}

    public String getName () {
    	return "Subtract";
    }

}
