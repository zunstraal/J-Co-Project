package net.fm.geco.model.command;
import java.util.List;

import geco.model.util.DbName;

public class UseDbCommand implements ICommand{

	private List<DbName> list;
	private boolean defaultServer;
	private String serverName;
	private String connectionString;
	private String serverType;
	private byte type;
	
	
	//ON DEFAULT SERVER
	public UseDbCommand(List<DbName> list, boolean defaultServer) {
		this.list = list;
		this.defaultServer = defaultServer;
		this.type = 0;
	}
	
	//ON SERVER serverName
	public UseDbCommand(List<DbName> list, String serverName) {
		this.list = list;
		this.defaultServer = false;
		this.serverName = serverName;
		this.type = 1;
	}
	
	//ON SERVER serverType serverName
	public UseDbCommand(List<DbName> list, String serverType, String connectionString) {
		this.list = list;
		this.serverType = serverType;
		this.connectionString = connectionString;
		this.defaultServer = false;
		this.type = 2;
	}
	
	public List<DbName> getDbNames(){
		return list;
	}
	
	public boolean isDefaultServer() {
		return defaultServer;
	}
	
	public String getServerName() {
		return serverName;
	}
	
	public String getServerType() {
		return serverType;
	}
	
	public String getConnectionString() {
		return connectionString;
	}
	
	public int getType() {
		return type;
	}
	
	@Override
	public String toString() {
		String stringVal = "USE DB " + list.get(0).toString();
		for (int i = 1; i < list.size(); i++) {
			DbName db = list.get(i);
			stringVal += ", " + db.toString();
		}
		if (type == 0)
			stringVal += " ON DEFAULT SERVER; ";
		else if (type == 1) {
			stringVal += " ON " + serverName + ";";
		}
		else if (type == 2) {
			stringVal += " ON " + serverType + " " + connectionString + ";";
		}
//		stringVal = "GET COLLECTION";
		return stringVal;
	}
		
    public String getName () {
    	return "Use db";
    }

}
