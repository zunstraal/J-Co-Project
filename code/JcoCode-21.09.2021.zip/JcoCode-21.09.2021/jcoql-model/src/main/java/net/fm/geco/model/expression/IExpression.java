package net.fm.geco.model.expression;

public interface IExpression {
	
}
