package net.fm.geco.model.condition.join;

public enum EUnitOfMeasure {
	METERS,
	KILOMETERS,
	MILES;
}
