package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.NoFuzzyFunction;

public class AddFieldsCommand {

    private List<NoFuzzyFunction> nonFuzzyFunction;
    private List<List<String>> fieldReferences;

    public AddFieldsCommand(List<NoFuzzyFunction> listNoFuzzyFunction, List<List<String>> listFieldReference) {
        this.nonFuzzyFunction = listNoFuzzyFunction;
        this.fieldReferences = listFieldReference;
    }

    public List<NoFuzzyFunction> getNonFuzzyFunction() {
        return nonFuzzyFunction;
    }

    public List<List<String>> getFieldReferences() {
        return fieldReferences;
    }

}
