package net.fm.geco.model.operation;

public interface IGeometryOperation {

}
