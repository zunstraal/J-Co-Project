package net.fm.geco.model.command;

import net.fm.geco.model.Case;

public class FilterCommand implements ICommand {

	private Case caseFilter;
	private boolean removeDuplicates;
	
	public FilterCommand(Case caseFilter, boolean removeDuplicates) {
		this.caseFilter = caseFilter;
		this.removeDuplicates = removeDuplicates;
	}
	
	public Case getCaseFilter() {
		return caseFilter;
	}

	public boolean isRemoveDuplicates() {
		return removeDuplicates;
	}

	@Override
	public String toString() {
		String stringVal = "FILTER\n";
		stringVal += this.caseFilter.toString();
		return stringVal;
	}
	
    
    public String getName () {
    	return "Filter";
    }

	
}
