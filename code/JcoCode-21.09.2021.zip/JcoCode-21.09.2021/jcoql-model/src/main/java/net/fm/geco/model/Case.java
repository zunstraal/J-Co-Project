package net.fm.geco.model;

import java.util.List;

import net.fm.geco.model.condition.WhereCondition;

public class Case {

	private List<WhereCondition> whereConditions;
	
	private boolean keepOthers;
	
	public Case(List<WhereCondition> whereConditions, boolean keepOthers) {
		this.whereConditions = whereConditions;
		this.keepOthers = keepOthers;
	}

	public Case(List<WhereCondition> whereConditions) {
		this.whereConditions = whereConditions;
		this.keepOthers = false;
	}

	public List<WhereCondition> getWhereConditions() {
		return whereConditions;
	}

	public boolean isKeepOthers() {
		return keepOthers;
	}

}
