package net.fm.geco.model.engine;

import java.util.List;

import net.fm.geco.model.DocumentDefinition;

public interface IDocumentCollection {

	public List<DocumentDefinition> getDocument();
	
	public void addDocument(DocumentDefinition document);

	public String getName();
}
