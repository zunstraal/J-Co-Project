package net.fm.geco.model.command;

public class GetCollectionCommand implements ICommand {
// PF.	
	public static int UNDEFINED  = -1;
	public static int DB_TYPE  = 0;
	public static int URL_QUOTED_TYPE  = 1;
	public static int URL_APEX_TYPE  = 2;
	private int type;
	private String urlString;

	private String dbName;	
	private String collectionName;
	
	public GetCollectionCommand(String collectionName) {
		this.collectionName = collectionName;
	}
	
	public GetCollectionCommand(String dbName, String collectionName) {
		this.dbName = dbName;
		this.collectionName = collectionName;
		// PF.
		this.type = DB_TYPE;
		this.urlString = null;
	}
	// PF.
	public GetCollectionCommand(String url, int type) {
		this.dbName = null;
		this.collectionName = null;
		this.type = type;
		this.urlString = url;
	}

	public int getType() {
		return type;
	}
	public String getDbName() {
		return dbName;
	}

	public String getCollectionName() {
		return collectionName;
	}

	public String getUrlString() {
		return urlString;
	}

	@Override
	public String toString() {
		String stringVal = "GET COLLECTION";
		if (type == DB_TYPE) {
			if(dbName != null) {
				stringVal += " [" + dbName + "]." + collectionName;
			} else {
				stringVal = " " + collectionName;
			}
		}
		else if (type == URL_APEX_TYPE) 
			stringVal += " FROM WEB '" + urlString +"'";
		else if (type == URL_QUOTED_TYPE) 
			stringVal += " FROM WEB \"" + urlString +"\"";

		return stringVal + ";";
	}
	
    public String getName () {
    	return "Get Collection";
    }
	
}
