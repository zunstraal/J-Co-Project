package net.fm.geco.model.condition;

import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.Value;

public class ValueTypeCondition implements ICondition {
	
	private EValueType type;
	
	private Value value;
	
	public ValueTypeCondition(EValueType type, Value value) {
		this.type = type;
		this.value = value;
	}

	public EValueType getType() {
		return type;
	}

	public Value getValue() {
		return value;
	}
	
	public String toString(){
		
		return type.toString() + " " +value.toString();
		
	}
	
}
