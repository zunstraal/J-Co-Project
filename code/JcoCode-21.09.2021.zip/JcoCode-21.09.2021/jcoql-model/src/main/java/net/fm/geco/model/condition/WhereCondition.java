package net.fm.geco.model.condition;

import java.util.List;

import net.fm.geco.model.command.AlphaCutCommand;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.command.GenerateFuzzyCommand;
import net.fm.geco.model.command.KeepingDroppingFuzzySetsCommand;

public class WhereCondition {
	
	private List<ICondition> conditions;
	private GenerateCommand generate;
	private List<GenerateFuzzyCommand> generateFuzzyList;
	private List<AlphaCutCommand> alphaCutCommands;
	private KeepingDroppingFuzzySetsCommand keepDropFuzzyCommand;

	public WhereCondition(List<ICondition> conditions, GenerateCommand generate, List<GenerateFuzzyCommand> generateFuzzy,
						  List<AlphaCutCommand> alphaCutCommands, KeepingDroppingFuzzySetsCommand keepDropFuzzyCommand) {
		this.conditions = conditions;
		this.generate = generate;
		this.generateFuzzyList = generateFuzzy;
		this.alphaCutCommands = alphaCutCommands;
		this.keepDropFuzzyCommand = keepDropFuzzyCommand;
	}

	public WhereCondition(List<ICondition> conditions) {
		this.conditions = conditions;
	}

	public List<ICondition> getConditions() {
		return conditions;
	}

	public GenerateCommand getGenerate() {
		return generate;
	}

	public List<GenerateFuzzyCommand> getGenerateFuzzyList() {
		return generateFuzzyList;
	}

	public List<AlphaCutCommand> getAlphaCutCommands() {
		return alphaCutCommands;
	}

	public KeepingDroppingFuzzySetsCommand getKeepDropFuzzyCommand() {
		return keepDropFuzzyCommand;
	}
	
	public String toString () {
		String x  ="";
		for (ICondition c : conditions) {
			x+=c.toString()+"\n";
		}
		return x;
	}
}
