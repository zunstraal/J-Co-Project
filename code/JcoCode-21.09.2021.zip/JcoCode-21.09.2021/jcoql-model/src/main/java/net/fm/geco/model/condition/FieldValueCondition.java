package net.fm.geco.model.condition;

import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.Value;

public class FieldValueCondition implements ICondition {

	private FieldReference field;
	
	private Value value;
	
	public FieldValueCondition(FieldReference field, Value value) {
		this.field = field;
		this.value = value;
	}

	public FieldReference getField() {
		return field;
	}

	public Value getValue() {
		return value;
	}
	
}
