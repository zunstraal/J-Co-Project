package net.fm.geco.model;

public class RangeDefinition {
    String x1;
    String x2;

    public RangeDefinition(String x1, String x2) {
        this.x1 = x1;
        this.x2 = x2;
    }

    public String getX1() {
        return x1;
    }

    public String getX2() {
        return x2;
    }
}
