package net.fm.geco.model.condition;

import java.util.List;

import geco.model.util.Field;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.command.GenerateCommand;
import net.fm.geco.model.reference.FieldReference;

public class PartitionCondition implements ICondition {

	private List<ICondition> with;

	private List<FieldReference> groupBy;

	private FieldName groupOutputField;

	//NUOVO
	private Field groupOutputFieldRef;

	private List<FieldReference> orderBy;

	private List<Integer> versus;

	private GenerateCommand generate;

	private boolean dropGrougpingField;		//NUOVO

	public PartitionCondition(List<ICondition> with, List<FieldReference> groupBy,
							  FieldName groupOutputField, List<FieldReference> orderBy,List<Integer> versus,GenerateCommand generate) {
		this.with = with;
		this.groupBy = groupBy;
		this.groupOutputField = groupOutputField;
		this.orderBy = orderBy;
		this.versus = versus;
		this.generate = generate;
	}

	//NUOVO COSTRUTTORE
	public PartitionCondition(List<ICondition> with, List<FieldReference> groupBy,
							  FieldName groupOutputField, List<FieldReference> orderBy,List<Integer> versus,GenerateCommand generate, boolean dropGrougpingField) {
		this.with = with;
		this.groupBy = groupBy;
		this.groupOutputField = groupOutputField;
		this.orderBy = orderBy;
		this.versus = versus;
		this.generate = generate;
		this.dropGrougpingField = dropGrougpingField;
	}

	//NUOVO COSTRUTTORE fieldRef
	public PartitionCondition(List<ICondition> with, List<FieldReference> groupBy,
							  Field groupOutputFieldRef, List<FieldReference> orderBy,List<Integer> versus,GenerateCommand generate, boolean dropGrougpingField) {
		this.with = with;
		this.groupBy = groupBy;
		this.groupOutputFieldRef = groupOutputFieldRef;
		this.orderBy = orderBy;
		this.versus = versus;
		this.generate = generate;
		this.dropGrougpingField = dropGrougpingField;
	}

	public List<ICondition> getWith() {
		return with;
	}

	public List<FieldReference> getGroupBy() {
		return groupBy;
	}

	public FieldName getGroupOutputField() {
		return groupOutputField;
	}

	public List<FieldReference> getOrderBy() {
		return orderBy;
	}

	public List<Integer> getVersus(){
		return versus;
	}

	public GenerateCommand getGenerate() {
		return generate;
	}

	//NUOVO
	public boolean getDropGrougpingField()
	{
		return dropGrougpingField;
	}

	//NUOVO 2
	public Field getGroupOutputFieldRef() {
		return groupOutputFieldRef;
	}
}
