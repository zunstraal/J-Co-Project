package net.fm.geco.model.expression;

import net.fm.geco.model.EOperator;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.Value;

public class FieldExpression implements IExpression {
	
	private FieldValue field;
	
	private EOperator operator;
	
	private Value value;
	
	public FieldExpression(FieldValue field, EOperator operator, Value value) {
		this.field = field;
		this.operator = operator;
		this.value = value;
	}

	public FieldValue getField() {
		return field;
	}

	public EOperator getOperator() {
		return operator;
	}

	public Value getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return field + " " + operator + " " + value;
	}
}
