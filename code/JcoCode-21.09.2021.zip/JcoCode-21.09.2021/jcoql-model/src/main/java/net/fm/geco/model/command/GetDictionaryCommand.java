package net.fm.geco.model.command;

// PF. Added on 22.07.2021
public class GetDictionaryCommand implements ICommand {
	public static int UNDEFINED  = -1;

	private String dbName;	
	private String collectionName;	
	private String dictionary;
	
	public GetDictionaryCommand(String collectionName, String dbName, String dictionary) {
		this.dbName = dbName;
		this.collectionName = collectionName;
		this.dictionary = dictionary;
	}

	public String getDbName() {
		return dbName;
	}

	public String getCollectionName() {
		return collectionName;
	}

	public String getDictionary() {
		return dictionary;
	}


	@Override
	public String toString() {
		String stringVal = "GET DICIONARY " + collectionName + "@" + dbName+ " AS " + dictionary + ";" ;
		return stringVal;
	}
	
    public String getName () {
    	return "Get Dictionary";
    }
	
}
