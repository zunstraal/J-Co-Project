package net.fm.geco.model.condition.tree;

import geco.model.util.Condition;

public interface ITreeModel {

	public TreeNode getRoot();
		
	public boolean evaluate();

	public void parser2Engine(Condition condition);

	public String printTree();

	
}
