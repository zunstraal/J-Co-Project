package net.fm.geco.model.value;

import java.util.List;
import java.util.StringJoiner;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ArrayValue implements Value {
	
	@JsonIgnore
	private List<Value> values;
	
	public ArrayValue(List<Value> values) {
		this.values = values;
	}

	@Override
	public EValueType getType() {
		return EValueType.ARRAY;
	}

	public List<Value> getValues() {
		return values;
	}

	@Override
	public String getStringValue() {
		return toString();
	}
	
	@Override
	public Object getValue() {
		return values;
	}

	@Override
	public String toString() {
		StringJoiner stringJoiner = new StringJoiner(", ", "[", "]");
		for(Value value : values) {
			stringJoiner.add(value.getStringValue());
		}
		return stringJoiner.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((values == null) ? 0 : values.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		ArrayValue other = (ArrayValue) obj;
		if (values == null) {
			if (other.values != null) {
				return false;
			}
		} else if (!values.equals(other.values)) {
			return false;
		}
		return true;
	}
}
