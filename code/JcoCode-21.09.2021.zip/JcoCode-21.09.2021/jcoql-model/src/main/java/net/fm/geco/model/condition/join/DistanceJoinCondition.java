package net.fm.geco.model.condition.join;

import net.fm.geco.model.EOperator;

public class DistanceJoinCondition implements JoinCondition {
	
	private EUnitOfMeasure unit;
	private EOperator eOperator;
	private double distance;
	
	public DistanceJoinCondition(EUnitOfMeasure unit, EOperator eOperator, float distance) {
		this.unit = unit;
		this.eOperator = eOperator;
		this.distance = distance;
	}

	public EUnitOfMeasure getUnit() {
		return unit;
	}
	
	public EOperator getOperator(){
		return eOperator;
	}
	
	public double getDistance(){
		return distance;
	}
	
}
