package net.fm.geco.model.command;

import net.fm.geco.model.Case;
import net.fm.geco.model.reference.CollectionReference;

public class JoinCommand implements ICommand {
	
	private CollectionReference leftCollection;	
	private CollectionReference rightCollection;
	private Case caseFilter;
	private AddFieldsCommand addFieldsCommand;
	private SetFuzzySetsCommand setFuzzySets;
	private boolean removeDuplicates;


	// da aggiungere al costruttore
	public JoinCommand(CollectionReference leftCollection, CollectionReference rightCollection,
						AddFieldsCommand addFieldsCommand, SetFuzzySetsCommand setFuzzySets,
						Case caseFilter, boolean removeDuplicates) {
		this.leftCollection = leftCollection;
		this.rightCollection = rightCollection;
		this.addFieldsCommand = addFieldsCommand;
		this.setFuzzySets = setFuzzySets;
		this.caseFilter = caseFilter;
		this.removeDuplicates = removeDuplicates;
}

	public CollectionReference getLeftCollection() {
		return leftCollection;
	}

	public CollectionReference getRightCollection() {
		return rightCollection;
	}

	public Case getCaseFilter() {
		return caseFilter;
	}
	
	public AddFieldsCommand getAddFieldsCommand() {
		return addFieldsCommand;
	}

	public SetFuzzySetsCommand getSetFuzzySetsCommand () {
		return setFuzzySets;
	}

	public boolean isRemoveDuplicates() {
		return removeDuplicates;
	}

	public String getName () {
    	return "Join";
    }
}
