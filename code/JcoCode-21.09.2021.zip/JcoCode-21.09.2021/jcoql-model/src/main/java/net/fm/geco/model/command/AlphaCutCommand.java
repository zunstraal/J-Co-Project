package net.fm.geco.model.command;

public class AlphaCutCommand implements ICommand {

    private String alphaCut;
    private String on;

    public AlphaCutCommand(String alphaCut, String on) {
        this.alphaCut = alphaCut;
        this.on = on;
    }

    public String getAlphaCut() {
        return alphaCut;
    }

    public String getOn() {
        return on;
    }
    
    public String getName () {
    	return "Alpha cut";
    }

}
