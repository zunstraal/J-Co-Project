package net.fm.geco.model.condition.join;

import net.fm.geco.model.condition.ICondition;

public interface JoinCondition extends ICondition {

}
