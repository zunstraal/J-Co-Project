package net.fm.geco.model;

import java.util.List;

import net.fm.geco.model.condition.WhereCondition;
import net.fm.geco.model.expression.FieldExpression;
import net.fm.geco.model.value.FieldValue;

@Deprecated
public class FilterCase {
	
	private List<FieldExpression> fieldExpressions;
	
	private List<FieldValue> withFields;

	private List<FieldValue> withoutFields;
	
	private WhereCondition whereCondition;
	
	private List<FieldValue> projectionFields;
	
	public FilterCase(List<FieldExpression> fieldExpressions,
				List<FieldValue> withFields,
				List<FieldValue> withoutFields,
				WhereCondition whereCondition,
				List<FieldValue> projectionFields) {
		this.fieldExpressions = fieldExpressions;
		this.withFields = withFields;
		this.withoutFields = withoutFields;
		this.whereCondition = whereCondition;
		this.projectionFields = projectionFields;
	}

	public List<FieldExpression> getFieldExpressions() {
		return fieldExpressions;
	}

	public List<FieldValue> getWithFields() {
		return withFields;
	}

	public List<FieldValue> getWithoutFields() {
		return withoutFields;
	}

	public WhereCondition getWhereCondition() {
		return whereCondition;
	}

	public List<FieldValue> getProjectionFields() {
		return projectionFields;
	}
	
}
