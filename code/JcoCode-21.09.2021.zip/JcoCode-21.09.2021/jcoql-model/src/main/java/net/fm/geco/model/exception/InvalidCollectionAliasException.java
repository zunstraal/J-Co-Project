package net.fm.geco.model.exception;

public class InvalidCollectionAliasException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
