package net.fm.geco.model.value;

public class IdValue implements Value {

    String id;

    public IdValue(String id) {
        this.id = id;
    }

    @Override
    public EValueType getType() {
        return null;
    }

    @Override
    public String getStringValue() {
        return id;
    }

    @Override
    public Object getValue() {
        return id;
    }
}
