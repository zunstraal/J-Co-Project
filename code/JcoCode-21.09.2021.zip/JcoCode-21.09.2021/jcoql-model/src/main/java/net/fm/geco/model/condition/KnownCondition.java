package net.fm.geco.model.condition;

public class KnownCondition implements ICondition {
    private String nameFuzzySet;

    public KnownCondition(String name) {
        nameFuzzySet = name;
    }

    public String getNameFuzzySets() {
        return nameFuzzySet;
    }

    @Override
    public String toString() {
        String returnStr = "KNOWN FUZZY SETS ";
        returnStr += nameFuzzySet;
        return returnStr;
    }
}
