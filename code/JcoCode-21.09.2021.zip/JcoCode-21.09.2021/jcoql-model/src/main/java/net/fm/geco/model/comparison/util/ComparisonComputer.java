package net.fm.geco.model.comparison.util;

import geco.model.util.Expression;
import geco.model.util.ExpressionFactor;
import geco.model.util.Field;
import geco.model.util.Value;
import net.fm.geco.model.EOperator;
import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.BasicCondition;
import net.fm.geco.model.condition.ICondition;
import net.fm.geco.model.condition.tree.OperationCondition;
import net.fm.geco.model.expression.BasicExpression;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.IdValue;
import net.fm.geco.model.value.SimpleValue;

public class ComparisonComputer {

	Expression e1;
	Expression e2;
	String comparator;
	private String alias;

	public ComparisonComputer(Expression e1, Expression e2, String comparator, String currentCollection) {

		this.e1 = e1;
		this.e2 = e2;
		this.comparator = comparator;
		this.alias = currentCollection;
	}
	
	
	public ICondition evaluateCondition(){

		ICondition condition = null;
		if(e1.terms.size() == 1 && e2.terms.size() == 1 && e1.operators.get(0).equals("")  && e2.operators.get(0).equals("")){
		
			if(e1.terms.get(0).factors.size() == 1 && e2.terms.get(0).factors.size() == 1){
			
				if(e1.terms.get(0).factors.get(0).type != ExpressionFactor.SUBCONDITION && 
						e2.terms.get(0).factors.get(0).type != ExpressionFactor.SUBCONDITION ){
					
					/* Value destra e value sinistra (es. 3>2) */
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE && 
							e2.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE  ){
									
						Value v1 = e1.terms.get(0).factors.get(0).value;
						Value v2 = e2.terms.get(0).factors.get(0).value;
			
						condition = new BasicCondition(new BasicExpression(evaluateValue(v1), evaluateOperator(comparator), evaluateValue(v2)));
						return condition;
			
					}
					
					/* FieldReference a sinistra e value a destra (es. .pippo = 3)*/
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.FIELDNAME && e2.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE ){
			
						Field f1 = e1.terms.get(0).factors.get(0).field;
						Value v1 = e2.terms.get(0).factors.get(0).value;
			
						condition = new BasicCondition(new BasicExpression(new FieldValue(new FieldReference(alias+f1.toString().substring(1))), evaluateOperator(comparator), evaluateValue(v1)));
						return condition;			
						
					}
					
					/* Value a sinistra e FieldReference a destra (es. 22 = .pippo )*/
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE && e2.terms.get(0).factors.get(0).type == ExpressionFactor.FIELDNAME){
						
						Value v1 = e1.terms.get(0).factors.get(0).value;
						Field f1 = e2.terms.get(0).factors.get(0).field;
						
						condition = new BasicCondition(new BasicExpression(evaluateValue(v1), evaluateOperator(comparator), new FieldValue(new FieldReference(alias+f1.toString().substring(1)))));
						return condition;
			
						
					}
					
					/* FieldReference a sinistra e FieldReference a destra (es. .pippo = .a)*/
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.FIELDNAME && e2.terms.get(0).factors.get(0).type == ExpressionFactor.FIELDNAME){
			
						Field f1 = e1.terms.get(0).factors.get(0).field;
						Field f2 = e2.terms.get(0).factors.get(0).field;
						
						condition = new BasicCondition(new BasicExpression(new FieldValue(new FieldReference(alias+f1.toString().substring(1))), evaluateOperator(comparator), new FieldValue(new FieldReference(alias+f2.toString().substring(1)))));
						return condition;
			
					}
					
					/* FieldReference a sinistra e ID(stringa senza apici) a destra (es. .pippo = true)*/
					if((e1.terms.get(0).factors.get(0).type == ExpressionFactor.FIELDNAME && e2.terms.get(0).factors.get(0).type == ExpressionFactor.ID) || 
						(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID && e2.terms.get(0).factors.get(0).type == ExpressionFactor.FIELDNAME) ){
			
						Field f;
						String string;
						if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID){
							
						    f = e2.terms.get(0).factors.get(0).field;
						    string = e1.terms.get(0).factors.get(0).id;
						}else{
							
							f = e1.terms.get(0).factors.get(0).field;
							string = e2.terms.get(0).factors.get(0).id;
						}
			
						if(comparator.equals("=")||comparator.equals("!=")){
							if(string.equals("true")){
								condition = new BasicCondition(new BasicExpression(new FieldValue(new FieldReference(alias+f.toString().substring(1))), evaluateOperator(comparator), new SimpleValue(true)));
							}else if(string.equals("false")){
								condition = new BasicCondition(new BasicExpression(new FieldValue(new FieldReference(alias+f.toString().substring(1))), evaluateOperator(comparator), new SimpleValue(false)));
							}else if(string.equals("null")){
								condition = new BasicCondition(new BasicExpression(new FieldValue(new FieldReference(alias+f.toString().substring(1))), evaluateOperator(comparator), new SimpleValue()));
							}
						} else {
							if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID){
								IdValue f1 = new IdValue(e1.terms.get(0).factors.get(0).id);
								Field f2 = e2.terms.get(0).factors.get(0).field;
			
								condition = new BasicCondition(new BasicExpression(f1, evaluateOperator(comparator) , new FieldValue(new FieldReference(alias+f2.toString().substring(1)))));
								return condition;
							} else {
								Field f1 = e1.terms.get(0).factors.get(0).field;
								IdValue f2 = new IdValue(e2.terms.get(0).factors.get(0).id);
								condition = new BasicCondition(new BasicExpression(new FieldValue(new FieldReference(alias+f1.toString().substring(1))), evaluateOperator(comparator) , f2));
								return condition;
							}
						}
			
						return condition;
			
					}
			
					/* ** ** ** ** ** ** */
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID && e2.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE) {
						/*
						FieldValue f1 = new FieldValue(new FieldReference(alias + e1.terms.get(0).factors.get(0).id));
						Value v1 = e2.terms.get(0).factors.get(0).value;
			
						condition = new BasicCondition(new BasicExpression(f1, evaluateOperator(comparator), evaluateValue(v1)));
						return condition;
						 */
						IdValue value1 = new IdValue(e1.terms.get(0).factors.get(0).id);
						Value v1 = e2.terms.get(0).factors.get(0).value;
			
						condition = new BasicCondition(new BasicExpression(value1, evaluateOperator(comparator), evaluateValue(v1)));
						return condition;
			
					}
			
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE && e2.terms.get(0).factors.get(0).type == ExpressionFactor.ID) {
			
						Value v1 = e1.terms.get(0).factors.get(0).value;
						FieldValue f2 = new FieldValue(new FieldReference(alias + e2.terms.get(0).factors.get(0).id));
						//IdValue f2 = new IdValue(e2.terms.get(0).factors.get(0).id);
			
						condition = new BasicCondition(new BasicExpression(evaluateValue(v1), evaluateOperator(comparator), f2));
						return condition;
						/*
						IdValue value2 = new IdValue(e2.terms.get(0).factors.get(0).id);
						Value v1 = e2.terms.get(0).factors.get(0).value;
						System.out.println("value - ID");
						condition = new BasicCondition(new BasicExpression(evaluateValue(v1), evaluateOperator(comparator), value2));
						return condition;*/
					}
			
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID && e2.terms.get(0).factors.get(0).type == ExpressionFactor.ID) {
			
						FieldValue f1 = new FieldValue(new FieldReference(alias + e1.terms.get(0).factors.get(0).id));
						FieldValue f2 = new FieldValue(new FieldReference(alias + e2.terms.get(0).factors.get(0).id));
			
						condition = new BasicCondition(new BasicExpression(f1, evaluateOperator(comparator) , f2));
						return condition;
					}
					/* ** ** ** ** ** ** */
			
			
					/* caso con true, false o null */
					if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID && 
						e2.terms.get(0).factors.get(0).type == ExpressionFactor.ID &&  
						(e1.terms.get(0).factors.get(0).id == "true" && e2.terms.get(0).factors.get(0).id == "true") || 
						(e1.terms.get(0).factors.get(0).id == "false" && e2.terms.get(0).factors.get(0).id == "false")){
						
						String string1 = e1.terms.get(0).factors.get(0).id;
						String string2 = e2.terms.get(0).factors.get(0).id;
					
						boolean b1 = false;
						boolean b2 = false;
						
						if(string1.equals("true") || string1.equals("false")){
							
							b1 = Boolean.valueOf(string1);
			
							if(string2.equals("true") || string2.equals("false")){
								
								b2 = Boolean.valueOf(string2);
			
								
								condition = new BasicCondition(new BasicExpression(new SimpleValue(b1), evaluateOperator(comparator), new SimpleValue(b2) ));
								return condition;
							}
							else
								throw new RuntimeException("Did not found neither a boolean type or null matching");
							
						}
						
						else if(string1.equals("null") && string2.equals("null")){
							
			
							condition = new BasicCondition(new BasicExpression(new SimpleValue(), evaluateOperator(comparator), new SimpleValue() ));
							return condition;
						}
						
						else
							throw new RuntimeException("Did not found neither a boolean type or null matching");
						
						
					}		
		
				}
			}
		}
		
		
		/* Si costruisce l'albero se:
		 * - la dimensione dei terms e/o i factors è maggiore di 1
		 * - la dimensione dei terms è 1 e o l'operatore è != ""
		 * - la dimensione dei terms e dei factors è 1 e quel factor è una subcondition
		 *  
		 */
		
		OperationTree left = null;
		OperationTree right = null;
		net.fm.geco.model.value.Value value = null;

		/* Caso 1*/
		if(e1.terms.size() != 1 || e1.terms.get(0).factors.size() != 1){			

				left = new OperationTree(alias);
				left.expression2Tree(e1);

		/* Caso 2*/
		}else if(e1.terms.size() == 1 && !e1.operators.get(0).equals("")){

			left = new OperationTree(alias);
			left.expression2Tree(e1);
			
		/* Caso 3*/
		}else if(e1.terms.size() == 1 && e1.terms.get(0).factors.size() == 1 && e1.terms.get(0).factors.get(0).type == ExpressionFactor.SUBCONDITION){

			left = new OperationTree(alias);
			left.expression2Tree(e1);
		
		/* Caso valore*/
		}else{

			if(e1.terms.get(0).factors.get(0).type != ExpressionFactor.VALUE && 
				e1.terms.get(0).factors.get(0).type != ExpressionFactor.FIELDNAME && 
				e1.terms.get(0).factors.get(0).type != ExpressionFactor.ID) {
				throw new RuntimeException("Invalid type");
			} else if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.ID) {
				// aggiunto
				value = new IdValue(e1.terms.get(0).factors.get(0).id);
			} else if(e1.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE)
				value = evaluateValue(e1.terms.get(0).factors.get(0).value);
			else
				value = new FieldValue(new FieldReference(alias+e1.terms.get(0).factors.get(0).field.toString().substring(1)));
			
		}
		/* Caso 1*/
		if(e2.terms.size() != 1 || e2.terms.get(0).factors.size() != 1){
			
				right = new OperationTree(alias);
				right.expression2Tree(e2);
		/* Caso 2*/
		}else if(e2.terms.size() == 1 && !e2.operators.get(0).equals("")){
			right = new OperationTree(alias);
			right.expression2Tree(e2);
			
		/* Caso 3*/
		}else if(e2.terms.size() == 1 && e2.terms.get(0).factors.size() == 1 && e2.terms.get(0).factors.get(0).type == ExpressionFactor.SUBCONDITION){
		
			right = new OperationTree(alias);
			right.expression2Tree(e2);
		
		/* Caso valore*/
		}else{
						
			if(e2.terms.get(0).factors.get(0).type != ExpressionFactor.VALUE && 
					e2.terms.get(0).factors.get(0).type != ExpressionFactor.FIELDNAME && 
					e2.terms.get(0).factors.get(0).type != ExpressionFactor.ID) {
				throw new RuntimeException("Invalid types");
			}else if(e2.terms.get(0).factors.get(0).type == ExpressionFactor.ID) {
				// aggiunto
				value = new IdValue(e2.terms.get(0).factors.get(0).id);
			} else if(e2.terms.get(0).factors.get(0).type == ExpressionFactor.VALUE) {
				value = evaluateValue(e2.terms.get(0).factors.get(0).value);
			} else {
				value = new FieldValue(new FieldReference(alias + e2.terms.get(0).factors.get(0).field.toString().substring(1)));
			}
		}
		
		condition = computeOperationCondition(left,right,value,comparator);
	
		
		return condition;
	}
	
	
	private OperationCondition computeOperationCondition(OperationTree left, OperationTree right, net.fm.geco.model.value.Value value, String comparator){
		
		if(value == null)
			return new OperationCondition(left, right, evaluateOperator(comparator));
		else if(left == null)
			return new OperationCondition(value,right,evaluateOperator(comparator));
		else if(right == null)
			return new OperationCondition(left,value,evaluateOperator(comparator));
		else
			throw new RuntimeException("Error at predicate");
		
		
		
	}
	
	
	private EOperator evaluateOperator(String comparator){
		
		EOperator operator;
		
		
		if(comparator.equals("=")){
			
			operator = EOperator.EQUALS;
		}else if(comparator.equals(">")){
			
			operator = EOperator.GREATER_THAN;
		}else if(comparator.equals(">=")){
			
			operator = EOperator.GREATER_EQUAL;
		}else if(comparator.equals("<")){
			
			operator = EOperator.LESS_THAN;
		}else if(comparator.equals("<=")){
			
			operator = EOperator.LESS_EQUAL;
		}else if(comparator.equals("!=")){
			
			operator = EOperator.NOT_EQUALS;
		}else{
			operator = null;
		}
		
		return operator;
				
	}
	
	private SimpleValue evaluateValue(Value v){
		
		SimpleValue simpleValue = null;
		/* Int */
		if(v.type == Value.INT){			
			simpleValue = new SimpleValue(Integer.parseInt(v.value));
			
		/* Float*/	
		} else if(v.type == Value.FLOAT){			
			simpleValue = new SimpleValue(Double.parseDouble(v.value));

		/* Quoted or Apexed String */
		}else if((v.type == Value.APEX) || (v.type == Value.QUOTED)){			
			String s = v.value.substring(1, v.value.length()-1); 	
			simpleValue = new SimpleValue(s);			
		}
		return simpleValue;
		
	}	

}
