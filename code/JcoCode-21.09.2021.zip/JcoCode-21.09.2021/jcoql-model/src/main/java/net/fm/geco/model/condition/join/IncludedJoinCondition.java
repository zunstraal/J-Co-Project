package net.fm.geco.model.condition.join;

public class IncludedJoinCondition implements JoinCondition {

	private EFrom side;
	
	public IncludedJoinCondition(EFrom side) {
		this.side = side;
	}

	public EFrom getSide() {
		return side;
	}
	
}
