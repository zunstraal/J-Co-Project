package net.fm.geco.model.command;

import geco.model.fuzzy.SetFuzzySets;

// PF - Rewritten 16.07.2021
public class SetFuzzySetsCommand extends SetFuzzySets implements ICommand {

	public SetFuzzySetsCommand (SetFuzzySets sfs) {
		policyType = sfs.policyType;
		policyStr = sfs.policyStr;
		setType = sfs.setType;
		setByKeepStr = sfs.setByKeepStr;
		fuzzySetsList = sfs.fuzzySetsList;
	}

	
	public String getName () {
    	return "Set fuzzy sets";
    }

}
