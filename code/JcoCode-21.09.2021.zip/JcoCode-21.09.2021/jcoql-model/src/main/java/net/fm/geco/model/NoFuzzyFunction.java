package net.fm.geco.model;

public class NoFuzzyFunction {

    private int type;
    private String unit;
    private String from;
    private String orientation;
    private String side;

    public NoFuzzyFunction(int type, String unit, String from, String orientation, String side) {

        this.type = type;
        this.unit = unit;
        this.from = from;
        this.orientation = orientation;
        this.side = side;

    }

    public int getType() {
        return type;
    }

    public String getUnit() {
        return unit;
    }

    public String getFrom() {
        return from;
    }

    public String getOrientation() {
        return orientation;
    }

    public String getSide() {
        return side;
    }
}
