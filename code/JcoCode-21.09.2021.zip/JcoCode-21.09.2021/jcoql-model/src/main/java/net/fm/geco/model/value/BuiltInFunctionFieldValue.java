package net.fm.geco.model.value;

import net.fm.geco.byZun.ZunWarningTracker;
import net.fm.geco.model.reference.FieldReference;

// PF. addend on 22.03.2021 to handle ALL BUILT-IN FUNCTION  function
public class BuiltInFunctionFieldValue implements Value {
	
	private FieldReference fieldReference;
	private EValueType type = EValueType.BUILT_IN_FUNCTION;
	private String dictionary;
	private boolean dictionaryCase;
	private String defaultTranslation;
	
	public BuiltInFunctionFieldValue(FieldReference fieldReference, EValueType type) {
		this.type = type;				
		this.fieldReference = fieldReference;
		dictionary = null;
		dictionaryCase = true;
		defaultTranslation = null;
		ZunWarningTracker.add("-10.BuiltInFunctionFieldValue\t"+type+"\t"+fieldReference.toString());
	}
	// PF. added on 24.07.2021 - remove APEX or QUOTE from defaultTranslation
	public BuiltInFunctionFieldValue(FieldReference fieldReference, EValueType type, String dictionary, boolean dictionaryCase, String defaultTranslation) {
		this.type = type;				
		this.fieldReference = fieldReference;
		this.dictionary = dictionary ;
		this.dictionaryCase = dictionaryCase;
		this.defaultTranslation = defaultTranslation;
		if (hasDefaultTranslation ())
			this.defaultTranslation = this.defaultTranslation.substring(1, this.defaultTranslation.length()-1); 
		ZunWarningTracker.add("-13.BuiltInFunctionFieldValue\t"+type+"\t"+fieldReference.toString()+"\t"+dictionary+"\t"+dictionaryCase+"\t"+this.defaultTranslation);
	}
	// PF. added on 24.07.2021
	public String getDictionary () {
		return dictionary;
	}
	// PF. added on 24.07.2021
	public boolean isDictionaryCaseSensitive () {
		return dictionaryCase;
	}
	// PF. added on 04.08.2021
	public boolean hasDefaultTranslation () {
		return (defaultTranslation != null);
	}
	// PF. added on 04.08.2021
	public String getDefaultTranslation () {
		return defaultTranslation;
	}
	

	@Override
	public EValueType getType() {
		return type;
	}

	public FieldReference getFieldReference() {
		return fieldReference;
	}
	
	@Override
	public String getStringValue() {
		return toString();
	}

	@Override
	public Object getValue() {
		return fieldReference;
	}

	@Override
	public String toString() {		
		return fieldReference.toString();
	}
	public String toDebugString() {		
		String st = type.toString() + "(" + fieldReference.toString();
		if (dictionary != null)
			st += ", " + dictionary + ", " + dictionaryCase;
		st += ")";
		return st;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fieldReference == null) ? 0 : fieldReference.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		BuiltInFunctionFieldValue other = (BuiltInFunctionFieldValue) obj;
		if (fieldReference == null) {
			if (other.fieldReference != null) {
				return false;
			}
		} else if (!fieldReference.equals(other.fieldReference)) {
			return false;
		}
		return true;
	}

}
