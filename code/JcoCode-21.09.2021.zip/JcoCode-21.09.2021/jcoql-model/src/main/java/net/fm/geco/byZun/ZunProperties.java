package net.fm.geco.byZun;


public class ZunProperties {

    private static ZunProperties only = new ZunProperties();

	private int rnd;
	private String ver;
    private String scriptPath;
    private String logPath;
    private String reportPath;

    
    private ZunProperties() {
        this.rnd = (int) (1000*Math.random());
        this.scriptPath = "..\\.zunTestScripts\\";
        this.logPath = "..\\.zunLogs\\";
        this.reportPath = "..\\.zunReports\\";
        this.ver = "";
    }

    public static ZunProperties getInstance() {
        return only;
    }

    public void setVer(String ver) {
		this.ver = ver;
	}
    public String getVer() {
		return ver;
	}

    public int getRnd() {
		return rnd;
	}

	public String getScriptPath() {
		return scriptPath;
	}

	public String getLogPath() {
		return logPath;
	}

	public String getReportPath() {
		return reportPath;
	}
}
