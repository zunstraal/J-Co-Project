package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.reference.CollectionReference;

public class MergeCollectionsCommand implements ICommand {
	
	private List<CollectionReference> collections;
	
	private boolean removeDuplicates;
	
	public MergeCollectionsCommand(List<CollectionReference> collections, boolean removeDuplicates) {
		this.collections = collections;
		this.removeDuplicates = removeDuplicates;
	}

	public List<CollectionReference> getCollections() {
		return collections;
	}

		public boolean isRemoveDuplicates() {
			return removeDuplicates;
		}

    public String getName () {
    	return "Merge";
    }

}
