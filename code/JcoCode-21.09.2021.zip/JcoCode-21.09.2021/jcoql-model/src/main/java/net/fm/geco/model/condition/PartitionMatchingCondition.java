package net.fm.geco.model.condition;

import java.util.List;

import geco.model.util.Field;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.condition.join.EUnitOfMeasure;
import net.fm.geco.model.reference.FieldReference;

public class PartitionMatchingCondition implements ICondition {
	private FieldReference matchingTarget;
	private FieldReference WRTinput;
	private FieldName into;
	private EUnitOfMeasure unit;
	private double threshold;
	private double min_similarity=0;
	private List<ICondition> selectionCondition;
	//NUOVO EC
	private Field pathToInput;


	public PartitionMatchingCondition(FieldReference matchingTarget, FieldReference WRTinput,List<ICondition> selectionCondition, FieldName into,EUnitOfMeasure unit, double threshold , double min_similarity, Field pathToInput) {

		this.matchingTarget=matchingTarget;
		this.WRTinput=WRTinput;
		this.into= into;
		this.selectionCondition=selectionCondition;
		this.unit=unit;
		this.threshold=threshold;
		this.min_similarity=min_similarity;
		this.pathToInput = pathToInput;
	}

	public EUnitOfMeasure getUnit() {
		return unit;
	}

	public FieldReference getMatchingTarget() {

		return matchingTarget;
	}

	public FieldReference getWRTinput() {

		return WRTinput;
	}

	public List<ICondition> getSelectionCondition() {

		return selectionCondition;
	}

	public FieldName getInto() {
		return into;
	}
	public double getThreshold() {

		return threshold;
	}

	public double getMinSimilarity() {

		return min_similarity;
	}
	public boolean hasSimilarity() {
		if(min_similarity != 0) return true;
		else return false;
	}
	public boolean hasSelectionCondition() {
		if(selectionCondition.isEmpty()) return false;
		else return true;
	}

	public Field getPathToInput() {
		return pathToInput;
	}
}
