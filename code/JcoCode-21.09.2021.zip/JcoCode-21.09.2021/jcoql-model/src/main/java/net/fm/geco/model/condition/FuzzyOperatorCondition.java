package net.fm.geco.model.condition;

import java.util.List;

import geco.model.util.Expression;


public class FuzzyOperatorCondition implements ICondition {
    private String nameFunction;
    private List<Expression> parameters;

    public FuzzyOperatorCondition(String name, List<Expression> param) {
        this.nameFunction = name;
        this.parameters = param;
    }

    public String toString() {
        return "OperatorCondition";
    }

    public String getNameFunction() {
        return nameFunction;
    }

    public List<Expression> getParameters() {
        return parameters;
    }

}
