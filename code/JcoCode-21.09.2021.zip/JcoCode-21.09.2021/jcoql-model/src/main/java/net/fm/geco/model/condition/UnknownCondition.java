package net.fm.geco.model.condition;

public class UnknownCondition implements ICondition {

    private String nameFuzzySet;

    public UnknownCondition(String fuzzySetsName) {
        this.nameFuzzySet = fuzzySetsName;
    }

    public String getNameFuzzySet() {
        return nameFuzzySet;
    }

    @Override
    public String toString() {
        String returnStr = "UNKNOWN FUZZY SETS ";
        returnStr += nameFuzzySet;
        return returnStr;
    }

}
