package net.fm.geco.model.engine;

import net.fm.geco.model.FieldName;
import net.fm.geco.model.value.Value;

public interface IDocument {

	public Value getValue(FieldName fieldName);
}
