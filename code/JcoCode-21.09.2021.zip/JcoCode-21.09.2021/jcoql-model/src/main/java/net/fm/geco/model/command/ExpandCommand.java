package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.condition.UnpackCondition;

public class ExpandCommand implements ICommand {
	
	private List<UnpackCondition> unpack;
	
	private boolean keepOthers;
	
	public ExpandCommand(List<UnpackCondition> unpack, boolean keepOthers) {
		this.unpack = unpack;
		this.keepOthers = keepOthers;
	}

	public List<UnpackCondition> getUnpack() {
		return unpack;
	}

	public boolean isKeepOthers() {
		return keepOthers;
	}
    
    public String getName () {
    	return "Expand";
    }

}
