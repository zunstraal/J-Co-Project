package net.fm.geco.model.operation;

public class RightOperation implements IGeometryOperation{

}
