package net.fm.geco.model.builder;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.wololo.jts2geojson.GeoJSONReader;


import geco.model.util.Field;
import geco.model.util.OutputFieldSpec;
import net.fm.geco.byZun.ZunWarningTracker;
import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.FieldDefinition;
import net.fm.geco.model.FieldName;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.ArrayValue;
import net.fm.geco.model.value.BuiltInFunctionFieldValue;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.GeoJsonValue;
import net.fm.geco.model.value.RootableFieldValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class FieldDefinitionBuilder {

	private DocumentDefinitionBuilder parentDocument;

	private FieldDefinition field;


	public FieldDefinitionBuilder() {
		super();
		parentDocument = null;
		field = null;
	}

	FieldDefinitionBuilder(DocumentDefinitionBuilder parentDocument) {
		this.parentDocument = parentDocument;
	}

	public FieldDefinitionBuilder fromString(String name, String value) {
		field = new FieldDefinition(name, new SimpleValue(value));
		return this;
	}

	public FieldDefinitionBuilder fromBoolean(String name, Boolean value) {
		field = new FieldDefinition(name, new SimpleValue(value));
		return this;
	}

	public FieldDefinitionBuilder fromInteger(String name, Integer value) {
		field = new FieldDefinition(name, new SimpleValue(value));
		return this;
	}

	public FieldDefinitionBuilder fromDecimal(String name, BigDecimal value) {
		field = new FieldDefinition(name, new SimpleValue(value));
		return this;
	}

	
	//PF NUOVO		con il substring elimino il punto "." iniziale al nome del campo
	public FieldDefinitionBuilder fromBuiltInFunctionFieldReference(Field fieldRef, FieldReference value, int type) {
		EValueType fieldType = EValueType.BUILT_IN_FUNCTION;
		field = new FieldDefinition(fieldRef.fields.get(0).substring(1), new FieldValue(value));
		ZunWarningTracker.add("10\tfromBuiltInFunctionFieldReference\t--->\t"+field.getValue().toString()+"\t"+fieldType.toString());
		if (type == OutputFieldSpec.VALUE_FIELD_REF_TO_BOOL) {
			fieldType = EValueType.TO_BOOL_FIELD;
		}
		else if (type == OutputFieldSpec.VALUE_FIELD_REF_TO_FLOAT) {
			fieldType = EValueType.TO_FLOAT_FIELD;
		}
		else if (type == OutputFieldSpec.VALUE_FIELD_REF_TO_INT) {
			fieldType = EValueType.TO_INT_FIELD;
		}
		else if (type == OutputFieldSpec.VALUE_FIELD_REF_TO_STRING) {
			fieldType = EValueType.TO_STRING_FIELD;
		}
		else if (type == OutputFieldSpec.VALUE_SERIALIZE_FIELD_REF) {
			fieldType = EValueType.TO_SERIALIZE_FIELD;
		}
		else if (type == OutputFieldSpec.VALUE_COUNT_FIELD_REF) {
			fieldType = EValueType.COUNT;
		}

			field = new FieldDefinition(fieldRef.fields.get(0).substring(1), 
											new BuiltInFunctionFieldValue(value, fieldType));
		ZunWarningTracker.add("11\tfromBuiltInFunctionFieldReference\t--->\t"+fieldType.toString()+"\t");
		return this;
	}
	public FieldDefinitionBuilder fromBuiltInFunctionFieldReference(Field fieldRef, FieldReference value, int type,
			String dictionary, boolean caseSensitive, String defaultTranslation) {
		EValueType fieldType = EValueType.BUILT_IN_FUNCTION;
		field = new FieldDefinition(fieldRef.fields.get(0).substring(1), new FieldValue(value));
		ZunWarningTracker.add("10\tfromBuiltInFunctionFieldReference\t--->\t"+field.getValue().toString()+"\t"+fieldType.toString());

		if (type == OutputFieldSpec.VALUE_TRANSLATE) {
			fieldType = EValueType.TRANSLATE_FIELD;
		}		
		field = new FieldDefinition(fieldRef.fields.get(0).substring(1), 
				new BuiltInFunctionFieldValue(value, fieldType, dictionary, caseSensitive, defaultTranslation));
		ZunWarningTracker.add("12\tfromBuiltInFunctionFieldReference\t--->\t"+fieldType.toString());
		return this;
	}


	
	//EC NUOVO		con il substring elimino il punto "." iniziale al nome del campo
	public FieldDefinitionBuilder fromFieldReference(Field fieldRef, FieldReference value) {
		field = new FieldDefinition(fieldRef.fields.get(0).substring(1), new FieldValue(value));
		return this;
	}

	public FieldDefinitionBuilder fromRootableFieldReference(Field fieldRef, FieldReference value) {
		field = new FieldDefinition(fieldRef.fields.get(0).substring(1), new RootableFieldValue(value));
		return this;
	}

	public FieldDefinitionBuilder fromFieldReference(String name, FieldReference value) {
		field = new FieldDefinition(name, new FieldValue(value));
		return this;
	}

	public FieldDefinitionBuilder fromFieldReference(String name, String collectionAlias, String fieldName) {
		field = new FieldDefinition(name, new FieldValue(collectionAlias, fieldName));
		return this;
	}

	public FieldDefinitionBuilder fromFieldReference(String collectionAlias, String fieldName) {
		final FieldValue value = new FieldValue(collectionAlias, fieldName);
		field = new FieldDefinition(value.getFieldReference().getFieldName().getFirstLevelName(), value);
		return this;
	}

	public FieldDefinitionBuilder fromFieldReference(String name, String collectionAlias, FieldName fieldName) {
		field = new FieldDefinition(name, new FieldValue(collectionAlias, fieldName));
		return this;
	}

	public FieldDefinitionBuilder fromFieldReference(String collectionAlias, FieldName fieldName) {
		field = new FieldDefinition(fieldName.getFirstLevelName(), new FieldValue(collectionAlias, fieldName));
		return this;
	}

	//EC NUOVO
	public FieldDefinitionBuilder fromValue(Field fieldRef, Value fieldValue) {
		field = new FieldDefinition(fieldRef.fields.get(0).substring(1), fieldValue);
		return this;
	}

	public FieldDefinitionBuilder fromValue(String fieldName, Value fieldValue) {
		field = new FieldDefinition(fieldName, fieldValue);
		return this;
	}

	public FieldDefinitionBuilder fromList(String fieldName, List<Value> values) {
		field = new FieldDefinition(fieldName, new ArrayValue(values));
		return this;
	}

	public FieldDefinitionBuilder fromStringList(String fieldName, List<String> stringValues) {
		List<Value> values = new LinkedList<Value>();
		if(stringValues != null) {
			values = stringValues.stream().map(SimpleValue::new).collect(Collectors.toList());
		}
		field = new FieldDefinition(fieldName, new ArrayValue(values));
		return this;
	}

	public FieldDefinitionBuilder fromDocumentList(String fieldName, List<DocumentDefinition> documents) {
		return fromList(fieldName, documents.stream().map(DocumentValue::new).collect(Collectors.toList()));
	}

	//EC NUOVO
	public DocumentDefinitionBuilder fromDocument(Field fieldRef) {
		return new DocumentDefinitionBuilder(fieldRef.fields.get(0).substring(1), this);
	}

	public DocumentDefinitionBuilder fromDocument(String name) {
		return new DocumentDefinitionBuilder(name, this);
	}

	public FieldDefinitionBuilder fromDocument(String name, DocumentValue value) {
		this.field = new FieldDefinition(name, value);
		return this;
	}

	public FieldDefinitionBuilder fromGeoJsonString(String name, String geoJsonString) {
		field = new FieldDefinition(name, new GeoJsonValue(new GeoJSONReader().read(geoJsonString)));
		return this;
	}

	public FieldDefinitionBuilder fromGeoJson(String name, GeoJsonValue geoJson) {
		field = new FieldDefinition(name, geoJson);
		return this;
	}

	public FieldDefinition build() {
		return field;
	}

	public DocumentDefinitionBuilder add() {
		return parentDocument.withField(field);
	}



}
