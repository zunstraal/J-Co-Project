package net.fm.geco.model.condition;

import net.fm.geco.model.expression.IExpression;

public class NotCondition implements ICondition {
	
	private IExpression expression;
	
	public NotCondition(IExpression expression) {
		this.expression = expression;
	}
	
	public IExpression getExpression() {
		return this.expression;
	}
	
	@Override
	public String toString() {
		return "NOT " + expression.toString();
	}

}
