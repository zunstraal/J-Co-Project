package net.fm.geco.model.command;

import net.fm.geco.model.Case;
import net.fm.geco.model.condition.join.JoinCondition;
import net.fm.geco.model.operation.IGeometryOperation;
import net.fm.geco.model.reference.CollectionReference;

public class SpatialJoinCommand implements ICommand {
	
	private CollectionReference leftCollection;
	private CollectionReference rightCollection;
	private JoinCondition joinCondition;
	private IGeometryOperation geometryOperation;
	private Case caseFilter;
	private SetFuzzySetsCommand setFuzzySets;
	private AddFieldsCommand addFieldsCommand;
	private boolean removeDuplicates;

	
	public SpatialJoinCommand(CollectionReference leftCollection, CollectionReference rightCollection,
                              JoinCondition joinCondition, IGeometryOperation geometryOperation, 
                              AddFieldsCommand addFieldsCommand, SetFuzzySetsCommand setFuzzySets,
                              Case caseFilter, boolean removeDuplicates) {
		this.leftCollection = leftCollection;
		this.rightCollection = rightCollection;
		this.joinCondition = joinCondition;
		this.geometryOperation = geometryOperation;
		this.addFieldsCommand = addFieldsCommand;
		this.setFuzzySets = setFuzzySets;
		this.caseFilter = caseFilter;
		this.removeDuplicates = removeDuplicates;
	}

	public CollectionReference getLeftCollection() {
		return leftCollection;
	}

	public CollectionReference getRightCollection() {
		return rightCollection;
	}

	public JoinCondition getJoinCondition() {
		return joinCondition;
	}

	public IGeometryOperation getGeometryOperation() {
		return geometryOperation;
	}

	public Case getCaseFilter() {
		return caseFilter;
	}

	public AddFieldsCommand getAddFieldsCommand() {
		return addFieldsCommand;
	}

	public SetFuzzySetsCommand getSetFuzzySetsCommand () {
		return setFuzzySets;
	}

	public boolean isRemoveDuplicates() {
		return removeDuplicates;
	}

	public String getName () {
    	return "Spatial join";
    }
/*
	@Override
	public Object clone() {
	    try {
	        return (SpatialJoinCommand) super.clone();
	    } catch (CloneNotSupportedException e) {
	        return this;
    	}
	}
*/
}
