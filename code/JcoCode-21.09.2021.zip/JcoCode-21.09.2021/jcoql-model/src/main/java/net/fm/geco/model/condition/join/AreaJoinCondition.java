package net.fm.geco.model.condition.join;

import net.fm.geco.model.EOperator;

public class AreaJoinCondition implements JoinCondition {

	private EUnitOfMeasure unit;
	private EOperator eOperator;
	private double area;
	
	public AreaJoinCondition(EUnitOfMeasure unit,EOperator eOperator, float area) {
		this.unit = unit;
		this.eOperator = eOperator;
		this.area = area;
	}

	public EUnitOfMeasure getUnit() {
		return unit;
	}
	
	public EOperator getOperator(){
		return eOperator;
	}
	
	public double getArea(){
		return area;
	}
}
