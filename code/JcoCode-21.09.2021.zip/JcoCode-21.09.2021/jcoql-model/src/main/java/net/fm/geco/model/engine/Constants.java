package net.fm.geco.model.engine;

public class Constants {

	public static  String GEOMETRY_FIELD_NAME = "~geometry";
	public static String FUZZY_FIELD_NAME = "~fuzzysets";
	public static final String LEFT_DOCUMENT_ALIAS = "left";
	public static final String RIGHT_DOCUMENT_ALIAS = "right";

	
}
