package net.fm.geco.model.command;



import java.util.List;

import net.fm.geco.model.condition.TrajectoryPartitionCondition;
import net.fm.geco.model.reference.CollectionReference;

public class TrajectoryMatchingCommand implements ICommand{
	private List<TrajectoryPartitionCondition> partitions;
	private CollectionReference targetCollection;
	private CollectionReference inputCollection;
	private boolean keepOthers;
	
	
	
	public TrajectoryMatchingCommand(CollectionReference targetCollection, CollectionReference inputCollection,List<TrajectoryPartitionCondition> partitions,boolean keepOthers) {
		
		this.partitions = partitions;
		this.targetCollection=targetCollection;
		this.inputCollection=inputCollection;
		this.keepOthers= keepOthers;
	}
	
	public CollectionReference getTargetCollection() {
		return targetCollection;
	}

	public CollectionReference getInputCollection() {
		return inputCollection;
	}
	
	public List<TrajectoryPartitionCondition> getPartitions() {
		return partitions;
	}
	public boolean isKeepOthers() {
		return keepOthers;
	}
	
    public String getName () {
    	return "Trajectory matching";
    }

	
}
