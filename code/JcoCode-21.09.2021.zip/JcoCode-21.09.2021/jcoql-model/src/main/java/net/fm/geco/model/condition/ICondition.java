package net.fm.geco.model.condition;

public interface ICondition {

}
