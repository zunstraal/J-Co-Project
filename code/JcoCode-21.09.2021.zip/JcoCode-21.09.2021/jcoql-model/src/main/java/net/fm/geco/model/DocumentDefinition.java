package net.fm.geco.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import net.fm.geco.model.builder.DocumentDefinitionBuilder;
import net.fm.geco.model.value.ArrayValue;
import net.fm.geco.model.value.DocumentValue;
import net.fm.geco.model.value.EValueType;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class DocumentDefinition {

	private String name;

	private Map<String, Value> fields;

	public DocumentDefinition() {
		this.name = null;
		this.fields = new TreeMap<String, Value>();
	}

	// PF - Added on 16.07.2021
	public DocumentDefinition(String name) {
		this.name = name;
		this.fields = new TreeMap<String, Value>();
	}

	public DocumentDefinition(List<FieldDefinition> fields) {
		this.name = null;
		this.fields = initFields(fields);
	}

	public DocumentDefinition(String name, List<FieldDefinition> fields) {
		this.name = name;
		this.fields = initFields(fields);
	}

	private Map<String, Value> initFields(List<FieldDefinition> fields) {
		Map<String, Value> localFields = new TreeMap<String, Value>();
		
		for (FieldDefinition f : fields) {
			localFields.put(f.getName(), f.getValue());
		}
		return localFields;
	}

	public static DocumentDefinitionBuilder create() {
		return new DocumentDefinitionBuilder();
	}

	public String getName() {
		return name;
	}

	@JsonIgnore
	public List<FieldDefinition> getFields() {
		return fields.entrySet().stream().map(e -> new FieldDefinition(e.getKey(), e.getValue()))
				.collect(Collectors.toList());
	}

	public void addField(FieldDefinition field) {
		this.fields.put(field.getName(), field.getValue());
	}

	@JsonIgnore
	public ArrayValue getArrayValue(String fieldName) {
		return getValue(fieldName, ArrayValue.class);
	}

	@JsonIgnore
	public SimpleValue getSimpleValue(String fieldName) {
		return getValue(fieldName, SimpleValue.class);
	}

	@JsonIgnore
	public <T> T getValue(String fieldName, Class<T> clazz) {
		Value value = getValue(fieldName);
		if(value != null && value.getClass().getTypeName().equals(clazz.getTypeName())) {
			return clazz.cast(value);
		}
		return null;
	}

	@JsonIgnore
	public Value getValue(String fieldName) {
		return getValue(FieldName.fromString(fieldName));
	}

	@JsonIgnore
	public Value getValue(FieldName fieldName) {
		Value value = null;
		if (fieldName.getLevel() == 1) {
			value = fields.get(fieldName.getParts()[0]);
		} else {
			// aggiunto, deve partire da 1 non da 0!!!!!!!
			value = getValue(fields.get(fieldName.getParts()[0]), fieldName.getParts(), 1);
		}
		return value;
	}

	@JsonIgnore
	private Value getValue(Value value, String[] parts, int i) {
		Value v = null;
		if (i == parts.length) {
			v = value;

		} else if (value instanceof DocumentValue) {
			v = getValue(
					((DocumentValue) value).getValue(FieldName.fromParts(Arrays.copyOfRange(parts, 1, parts.length))),
					parts, parts.length);
		}
		return v;
	}

	public Value removeValue(String fieldName) {
		return removeValue(FieldName.fromString(fieldName));
	}

	public Value removeValue(FieldName fieldName) {
		Value value = null;
		if (fieldName.getLevel() == 1) {
			value = fields.get(fieldName.getParts()[0]);
			fields.remove(fieldName.getParts()[0]);
		} else {
			// aggiunto, deve partire da 1 non da 0!!!!!!!
			value = removeValue(fields.get(fieldName.getParts()[0]), fieldName.getParts(), 1);
		}

		return value;
	}

	private Value removeValue(Value value, String[] parts, int i) {
		Value v = null;
		if (i == parts.length) {
			v = value;

		} else if (value instanceof DocumentValue) {
			v = removeValue(((DocumentValue) value)
					.removeValue(FieldName.fromParts(Arrays.copyOfRange(parts, 1, parts.length))), parts, parts.length);
		}
		return v;
	}

	public boolean hasField(FieldName fieldName) {
		return getValue(fieldName) != null;
	}

	public boolean hasField(String fieldName) {
		return hasField(FieldName.fromString(fieldName));
	}
	public FieldDefinition getField(String fieldName) {
		return new FieldDefinition (fieldName, getValue(fieldName));
	}

	@JsonIgnore
	public List<Value> getValues(List<FieldName> fieldNames) {

		List<Value> list = new ArrayList<>();

		for (FieldName fieldName : fieldNames) {

			list.add(getValue(fieldName));
		}

		return list;
	}

	@Override
	public String toString() {
		//rimuovo ID per comodit� perch� in Elasticsearch crea problemi
		//in realt� non dovrebbe esserci questo pezzo
		if(fields.containsKey("_id"))
			fields.remove("_id");
		StringBuilder output = new StringBuilder("{\n");
		if (name != null) {
			output.append("\t\"name\": \"" + name + "\",\n");
		}
		StringJoiner joiner = new StringJoiner(",\n");
		Iterator<String> keys = fields.keySet().iterator();
		while (keys.hasNext()) {
			String key = keys.next();
			if(fields.get(key) != null) {
				if (fields.get(key).getType() == EValueType.DATE)
					joiner.add("\t\"" + key + "\": " + convertToISO((Date) fields.get(key).getValue()) + "");
				else
					joiner.add("\t\"" + key + "\": "
							+ fields.get(key).getStringValue()
							.replace("\r\n", " ").replace("\n", " ")
							+ "");
			}
		}
		output.append(joiner.toString());
		output.append("\n}");
		return output.toString();
	}

	private String convertToISO(Date d) {
		//formato ISO 8601
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		return "\"" + df.format(d) + "\"";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fields == null) ? 0 : fields.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		DocumentDefinition other = (DocumentDefinition) obj;
		if (fields == null) {
			if (other.fields != null) {

				return false;
			}
		} else if (!fields.equals(other.fields)) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {

				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

	/**
	 * Per l'inserimento dei dati in Elasticsearch non possono esserci dei campi che
	 * contengono "_" Questo metodo controlla se sono presenti o meno dei campi con
	 * questa caratteristica
	 *
	 * @return true: se nel documento ci sono dei campi che iniziano con "_" false:
	 *         altrimenti
	 */
	public boolean checkUnderscores() {
		Iterator<String> i = fields.keySet().iterator();
		while (i.hasNext()) {
			String key = i.next();
			if (key.startsWith("_"))
				return true;
		}
		return false;
	}

	@JsonProperty("fields")
	public Map<String, Value> getMap(){
		Map<String, Value> campi = new TreeMap<>();
		campi.putAll(fields);

		if(campi.containsKey("_id"))
			campi.remove("_id");
		return campi;
	}

	public void setMap(Map<String, Value> field){
		this.fields = field;
	}

}
