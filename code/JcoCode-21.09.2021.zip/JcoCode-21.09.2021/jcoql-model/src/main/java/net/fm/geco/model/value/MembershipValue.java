package net.fm.geco.model.value;

public class MembershipValue implements Value {

    public MembershipValue(Double d) {

    }

    @Override
    public EValueType getType() {
        return null;
    }

    @Override
    public String getStringValue() {
        return null;
    }

    @Override
    public Object getValue() {
        return null;
    }
}
