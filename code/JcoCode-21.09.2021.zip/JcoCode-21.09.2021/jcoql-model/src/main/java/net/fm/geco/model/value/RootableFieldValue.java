package net.fm.geco.model.value;

import net.fm.geco.model.FieldName;
import net.fm.geco.model.reference.FieldReference;

public class RootableFieldValue extends FieldValue {
		
	public RootableFieldValue(FieldReference fieldReference) {
		super (fieldReference);
	}

	public RootableFieldValue(String collectionAlias, String fieldName) {
		super (collectionAlias, fieldName);
	}

	public RootableFieldValue(String collectionAlias, FieldName fieldName) {
		super (collectionAlias, fieldName);
	}
	
	@Override
	public EValueType getType() {
		return EValueType.ROOTABLE_FIELD;
	}

}
