package net.fm.geco.model.condition.tree;

import java.util.ArrayList;
import java.util.List;

import net.fm.geco.model.condition.ICondition;

public class TreeNode {

	public static int UNDEFINED = -1;
	public static int WITH = 0;
	public static int WITHOUT = 1;
	public static int WITHIN = 2;
	public static int KNOWN = 3;
	public static int UNKNOWN = 4;
	public static int FUNCTION = 5;
	public static int ID = 6;
	public static int IF_FAILS = 7;
	public static int FIELDNAME = 8;

	/*
	 * Dati del nodo: tipo e condizioni da verificare tipo può essere OR, AND,
	 * NOT e NULL. nel caso fosse uno dei primi tre conditionList è vuoto quindi
	 * null.
	 */
	
	private int conditionType;
	private EBooleanType booleanType;
	private List<ICondition> conditionList;

	/*
	 * Lista di figli (non è detti che l'albero sia binario infatti) e oggetto
	 * che punta al padre
	 */
	private List<TreeNode> children;
	private TreeNode parent;

	public TreeNode() {
		conditionType = UNDEFINED;
		conditionList = new ArrayList<>();
		children = new ArrayList<>();
	}
	

	public TreeNode(EBooleanType booleanType) {
		this();
		this.booleanType = booleanType;

		/*
		 * Se il tipo booleano è NULL allora il nodo contiene condizione/i per
		 * questo si inizializza l'ArrayList delle condizioni, altrimenti si
		 * pone uguale a null
		 */
		if (booleanType != EBooleanType.NULL) {
			conditionList = null;
		}
	}

	public TreeNode(EBooleanType booleanType,int conditionType) {
		this();
		this.booleanType = booleanType;
		this.conditionType = conditionType;

		/*
		 * Se il tipo booleano è NULL allora il nodo contiene condizione/i per
		 * questo si inizializza l'ArrayList delle condizioni, altrimenti si
		 * pone uguale a nul
		 */
		if (booleanType != EBooleanType.NULL) {
			conditionList = null;
		}

	}

	public TreeNode(EBooleanType booleanType,int conditionType, List<ICondition> conditionsList) {
		this();
		this.booleanType = booleanType;
		this.conditionType = conditionType;

		/*
		 * Se il tipo booleano è NULL allora il nodo contiene condizione/i per
		 * questo si inizializza l'ArrayList delle condizioni, altrimenti si
		 * pone uguale a nul
		 */
		if (booleanType == EBooleanType.NULL) {
			this.conditionList = conditionsList;
		} else {
			conditionList = null;
		}
	}

	public TreeNode(List<ICondition> conditionList) {
		children = null;
		booleanType = EBooleanType.NULL;

		/* potrei controllare che non mi venga passato null */
		this.conditionList = conditionList;
	}

	public TreeNode getParent() {
		return this.parent;
	}

	public List<TreeNode> getChildren() {
		return this.children;
	}

	public void setChildren(List<TreeNode> children) {
		for (TreeNode child : children) {
			child.parent = this;
		}

		this.children = children;
	}

	public TreeNode addChild(TreeNode child) {
		child.parent = this;
		children.add(child);
		return child;
	}

	public void addChildAt(int index, TreeNode child) throws IndexOutOfBoundsException {
		child.parent = this;
		children.add(index, child);
	}

	public void removeChildren() {
		this.children = new ArrayList<TreeNode>();
	}

	public void removeChildAt(int index) throws IndexOutOfBoundsException {
		children.remove(index);
	}

	public TreeNode getChildAt(int index) throws IndexOutOfBoundsException {
		return children.get(index);
	}

	public EBooleanType getType() {
		return this.booleanType;
	}

	public void setType(EBooleanType booleanType) {
		this.booleanType = booleanType;
	}

	public List<ICondition> getConditionList() {
		return this.conditionList;
	}
	
	public void setConditionList(List<ICondition> conditionList){
		this.conditionList = conditionList;
	}
	
	public void addCondition(ICondition condition){
		if(conditionList!=null) {
			this.conditionList.add(condition);
		}
	}
	
	public void setConditionType(int type){
		if(type == 1 || type == 0) {
			this.conditionType = type;
		} else { 
			this.conditionType = UNDEFINED;
		}
	}
	
	public int getConditionType(){
		return conditionType;
	}
	
	@Override
	public String toString() {
		
		if(booleanType != EBooleanType.NULL) {
			return  booleanType.toString();
		} else if (conditionType == UNDEFINED) {
			return conditionList.toString();
		} else if(conditionType == WITH) { 
			return "WITH " + conditionList.toString();
		} else if(conditionType == WITHOUT) {
			return "WITHOUT " + conditionList.toString();
		} else if(conditionType == WITHIN) {
			return "WITHIN " + conditionList.toString();
		} else if(conditionType == KNOWN) {
			return "KNOWN " + conditionList.toString();
		} else if(conditionType == ID) {
			return "ID " + conditionList.toString();
		} else if(conditionType == FUNCTION) {
			return "FUNCTION " + conditionList.toString();
		} else if(conditionType == IF_FAILS) {
			return "IF-FAILS " + conditionList.toString();
		} else if(conditionType == FIELDNAME) {
			return "FIELDNAME " + conditionList.toString();
		} else {
			return "UNDEFINED " + conditionList.toString();
		}
	}
	

}
