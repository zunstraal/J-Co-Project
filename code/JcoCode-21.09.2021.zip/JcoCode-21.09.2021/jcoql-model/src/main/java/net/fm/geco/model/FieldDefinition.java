package net.fm.geco.model;

import net.fm.geco.model.builder.FieldDefinitionBuilder;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.Value;

public class FieldDefinition {

	private String name;

	private Value value;

	public FieldDefinition(String name, Value value) {
		this.name = name;
		this.value = value;
	}


	public FieldDefinition(FieldValue value) {
		this.name = value.getFieldReference().getFieldName().getFirstLevelName();
		this.value = value;
	}

	public static FieldDefinitionBuilder create() {
		return new FieldDefinitionBuilder();
	}

	public String getName() {
		return name;
	}

	public Value getValue() {
		return value;
	}

	// PF - add to check field content
	public String getDebugString () {
		String st = "--FieldDefinition -> " + name + "-> ";
		if (value==null)
			st += "NO VALUE";
		else
			if (value.getType()==null)
				st += "NO TYPE";
			else
				st += "ValueType:" + value.getType().name() + " -> Value:" + value.getStringValue();
		return st;
	}
}
