package net.fm.geco.model.condition;


public class AndCondition implements ICondition, CompoundCondition{
/*
	private BasicCondition left;
	
	private BasicCondition right;
	
	public AndCondition(BasicCondition left, BasicCondition right) {
		this.left = left;
		this.right = right;
	}
	
	public BasicCondition getLeft() {
		return left;
	}
	
	public BasicCondition getRight() {
		return right;
	}
	
*/
	
	/*6-09-2017*/
	/*Modifica per far sì che AndCondition supporti qualsiasi tipo di condizione*/
	
	private ICondition left;
	
	private ICondition right;
	
	public AndCondition(ICondition left, ICondition right) {
		this.left = left;
		this.right = right;
	}
	
	public ICondition getLeft() {
		return left;
	}
	
	public ICondition getRight() {
		return right;
	}
	
	@Override
	public String toString() {
		return left.toString() + " AND " + right.toString();
	}
}
