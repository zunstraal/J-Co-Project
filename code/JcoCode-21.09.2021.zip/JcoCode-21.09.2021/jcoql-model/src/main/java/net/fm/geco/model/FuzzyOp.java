package net.fm.geco.model;

import java.util.List;

import net.fm.geco.model.comparison.model.OperationTree;
import net.fm.geco.model.condition.WhereCondition;

public class FuzzyOp {
    String fuzzyOperatorName;
    List<ParameterDefinition> parameters;
    WhereCondition precondition;
    List<OperationTree> evaluate;
    RangeDefinition range;
    List<PointDefinition> polyline;

    public FuzzyOp(String name, List<ParameterDefinition> parameters, WhereCondition preCondition,
                   List<OperationTree> evaluate, RangeDefinition range, List<PointDefinition> polyline) {
        fuzzyOperatorName = name;
        this.parameters = parameters;
        this.precondition = preCondition;
        this.evaluate = evaluate;
        this.range = range;
        this.polyline = polyline;

/* PF. What is for?       
        for (ICondition c : preCondition.getConditions()) {
//        	TreeCondition t = (TreeCondition) c;
        }
 */       
    }
    
    // PF. Check if 2 Fuzzy Operator are the same
    public boolean equals(String name, List<ParameterDefinition> parameters) {
        if(!this.fuzzyOperatorName.equals(name)) {
            return false;
        } else {
            if(this.parameters.size() != parameters.size()) {
                return false;
            } else {
                for(int p = 0; p < parameters.size(); p++) {
                    if(!this.parameters.get(p).type.equals(parameters.get(p).type)) {
                        return false;
                    }
                }
                return true;
            }
        }
    }

    // controllo RANGE
    public boolean checkRange(double value) {
        if(value >= Double.parseDouble(range.getX1()) && value <= Double.parseDouble(range.getX2())) {
            return true;
        } else {
            return false;
        }
    }

    // calcolo MEMBERSHIP
    public double evaluateMembership(double value) {

        float x1, x2;
        float y1, y2;

        // controllo range
        if(checkRange(value)) {
            for (int i = 0; i < getPolyline().size() - 1; i++) {

                x1 = getPolyline().get(i).getX();
                y1 = getPolyline().get(i).getY();
                x2 = getPolyline().get(i + 1).getX();
                y2 = getPolyline().get(i + 1).getY();

                if (value <= x2 && value >= x1) {
                    // membership value
                    return ((((value) - x1) / (x2 - x1)) * (y2 - y1)) + y1;
                }
            }
            return 0;
        } else {
        	if (value < getPolyline().get(0).getX())
        		return getPolyline().get(0).getY();
        	else if (value > getPolyline().get(this.getPolyline().size()-1).getX())
        		return getPolyline().get(this.getPolyline().size()-1).getY();

        	return 0;
        }
    }

    public String getFuzzyOperatorName() {
        return fuzzyOperatorName;
    }

    public List<ParameterDefinition> getParameters() {
        return parameters;
    }

    public WhereCondition getPrecondition() {
        return precondition;
    }

    public List<OperationTree> getEvaluate() {
        return evaluate;
    }

    public RangeDefinition getRange() {
        return range;
    }

    public List<PointDefinition> getPolyline() {
        return polyline;
    }

}
