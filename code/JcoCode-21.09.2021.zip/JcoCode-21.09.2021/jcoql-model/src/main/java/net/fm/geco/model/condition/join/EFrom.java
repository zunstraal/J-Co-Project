package net.fm.geco.model.condition.join;

public enum EFrom {
	LEFT,
	RIGHT;
}
