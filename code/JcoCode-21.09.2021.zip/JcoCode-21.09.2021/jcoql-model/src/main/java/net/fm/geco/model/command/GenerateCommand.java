package net.fm.geco.model.command;

import net.fm.geco.model.DocumentDefinition;
import net.fm.geco.model.GeometryDefinition;

public class GenerateCommand implements ICommand {

	private DocumentDefinition outputDefinition;
	
	private GeometryDefinition geometry;
	
	private EGeometryAction geometryAction;
	
	private boolean hasGeometry;
	
	public GenerateCommand(DocumentDefinition definition, EGeometryAction geometryAction, GeometryDefinition geometry) {
		this.outputDefinition = definition;
		this.geometryAction = geometryAction;
		if(geometry != null) {
			hasGeometry = true;
			this.geometry = geometry;
		} else {
			hasGeometry = false;
		}
	}

	public DocumentDefinition getOutputDefinition() {
		return outputDefinition;
	}

	public GeometryDefinition getGeometry() {
		return geometry;
	}

	public EGeometryAction getGeometryAction() {
		return geometryAction;
	}

	public boolean isHasGeometry() {
		return hasGeometry;
	}
	
    public String getName () {
    	return "Generate";
    }

}
