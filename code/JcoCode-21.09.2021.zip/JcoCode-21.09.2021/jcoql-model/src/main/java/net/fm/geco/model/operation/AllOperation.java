package net.fm.geco.model.operation;

public class AllOperation implements IGeometryOperation {

}
