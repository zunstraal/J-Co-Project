package net.fm.geco.model.condition;

import java.util.List;

public class TrajectoryPartitionCondition implements ICondition {
	//change Case with IContion..
	private List<ICondition> selectionCondition;
	private List<PartitionMatchingCondition> matchings;
	
	public TrajectoryPartitionCondition(List<ICondition> selectionCondition,List<PartitionMatchingCondition> matchings) {
		
		this.selectionCondition = selectionCondition;
		this.matchings=matchings;
			
	}
	public List<ICondition> getSelectionCondition() {
		
		return selectionCondition;
	}
	public List<PartitionMatchingCondition> getMatchings(){
		return matchings;
	}

}
