package net.fm.geco.model.condition.join;

public class MeetJoinCondition implements JoinCondition {

}
