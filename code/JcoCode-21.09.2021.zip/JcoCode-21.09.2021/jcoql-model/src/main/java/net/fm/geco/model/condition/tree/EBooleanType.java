package net.fm.geco.model.condition.tree;

/*Classe enumerativa che serve a sapere se un nodo ha una funzione booleana oppure no.
 * 
 * WITH .a OR .a="pippo"
 * 
 *           OR
 *          /  \
 *         /    \
 *  	  /      \
 *    WITH .a     .a ="pippo"
 *    
 *   Esempio: Il nodo OR ha il campo type = OR
 *   		  Il nodo with .a ha il campo type = NULL
 *            Il nodo .a = "pippo" ha il campo type = NULL
 *            
 *   In questo modo si può, in fase di elaborazione, capire se bisogna fare un'operazione booleana 
 *   (e di che tipo) al nodo corrente oppure se va valutata l'espressione alla foglia
 */
public enum EBooleanType {

	OR,
	AND,
	NOT,
	NULL;
	
}
