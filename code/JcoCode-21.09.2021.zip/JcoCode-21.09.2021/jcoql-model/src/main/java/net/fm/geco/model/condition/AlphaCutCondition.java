package net.fm.geco.model.condition;

public class AlphaCutCondition implements ICondition {

}
