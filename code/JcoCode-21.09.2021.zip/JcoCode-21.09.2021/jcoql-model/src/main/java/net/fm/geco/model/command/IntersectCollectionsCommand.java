package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.reference.CollectionReference;

public class IntersectCollectionsCommand implements ICommand {
	
	private List<CollectionReference> collections;
	
	public IntersectCollectionsCommand(List<CollectionReference> collections) {
		this.collections = collections;
	}

	public List<CollectionReference> getCollections() {
		return collections;
	}

    public String getName () {
    	return "Intersect";
    }

}
