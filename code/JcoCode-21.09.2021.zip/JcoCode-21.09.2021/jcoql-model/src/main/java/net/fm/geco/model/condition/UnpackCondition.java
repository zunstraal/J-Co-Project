package net.fm.geco.model.condition;

import java.util.List;

import net.fm.geco.model.FieldName;
import net.fm.geco.model.reference.FieldReference;

public class UnpackCondition implements ICondition {

	private List<ICondition> with;

	/* aggiunto 24-07 */
	private FieldReference inputField;

	private FieldName outputField;

//	private GenerateCommand generate;

//	public UnpackCondition(List<ICondition> with, FieldReference inputField, FieldName outputField, GenerateCommand generate) {
	public UnpackCondition(List<ICondition> with, FieldReference inputField, FieldName outputField) {
		this.with = with;
		this.inputField = inputField;
		this.outputField = outputField;
//		this.generate = generate;
	}

	public List<ICondition> getWith() {
		return with;
	}

	public FieldReference getInputField() {
		return inputField;
	}

	public FieldName getOutputField() {
		return outputField;
	}

/*	PF. Generate Action deprecated on 07.05.2021
 	public GenerateCommand getGenerate() {
 		return generate;
	}
*/

}
