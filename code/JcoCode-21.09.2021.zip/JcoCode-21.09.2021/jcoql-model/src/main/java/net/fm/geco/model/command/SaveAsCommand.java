package net.fm.geco.model.command;

public class SaveAsCommand implements ICommand {
	
	private String dbName;	
	private String collectionName;
	
	public SaveAsCommand(String collectionName) {
		this.dbName = null;
		this.collectionName = collectionName;
	}
	
	public SaveAsCommand(String dbName, String collectionName) {
		this.dbName = dbName;
		this.collectionName = collectionName;
	}

	public String getDbName() {
		return dbName;
	}

	public String getCollectionName() {
		return collectionName;
	}

	@Override
	public String toString() {
		String stringVal = "SAVE AS";
		if(dbName != null) {
			stringVal = "SAVE AS [" + dbName + "]." + collectionName;
		} else {
			stringVal = "SAVE AS " + collectionName;
		}
		return stringVal;
	}
	
    public String getName () {
    	return "Save as";
    }
	
}
