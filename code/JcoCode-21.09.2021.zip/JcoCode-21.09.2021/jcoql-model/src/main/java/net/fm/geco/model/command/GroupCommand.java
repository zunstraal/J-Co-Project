package net.fm.geco.model.command;

import java.util.List;

import net.fm.geco.model.condition.PartitionCondition;

public class GroupCommand implements ICommand {
	
	private List<PartitionCondition> partitions;

	private boolean keepOthers;
	
	public GroupCommand(List<PartitionCondition> partitions, boolean keepOthers) {
		this.partitions = partitions;
		this.keepOthers = keepOthers;
	}

	public List<PartitionCondition> getPartitions() {
		return partitions;
	}

	public boolean isKeepOthers() {
		return keepOthers;
	}
	
    public String getName () {
    	return "Group";
    }

}
