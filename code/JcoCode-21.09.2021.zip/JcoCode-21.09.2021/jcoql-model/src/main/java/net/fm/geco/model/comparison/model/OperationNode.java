package net.fm.geco.model.comparison.model;

import geco.model.util.ExpressionFactor;
import net.fm.geco.model.reference.FieldReference;
import net.fm.geco.model.value.FieldValue;
import net.fm.geco.model.value.FunctionJsValue;
import net.fm.geco.model.value.SimpleValue;
import net.fm.geco.model.value.Value;

public class OperationNode {

	private EOperationType operationType;
	public OperationNode left;
	public OperationNode right;
	public OperationNode parent;
	public ExpressionFactor factor;
	private String alias;
	private Value value;

	public OperationNode() {

		left = right = parent = null;

	}

	public OperationNode(EOperationType operator, String currentCollection) {

		this();
		this.operationType = operator;
		this.factor = null;
		this.alias = currentCollection;

	}

	public OperationNode(ExpressionFactor f, String currentCollection) {

		this();
		this.alias = currentCollection;
		this.operationType = null;
		this.factor = f;
		this.value = factor2Value(f);
	}

	public OperationNode addLeft(OperationNode left) {

		this.left = left;
		return this.left;

	}

	public OperationNode addRight(OperationNode right) {

		this.right = right;
		return this.right;

	}

	public OperationNode getLeft() {

		return left;

	}

	public OperationNode getRight() {

		return right;

	}

	public EOperationType getType() {
		return this.operationType;
	}

	public void setType(EOperationType operationType) {
		this.operationType = operationType;
	}

	public void setFactor(ExpressionFactor ef) {

		this.factor = ef;
		this.value = factor2Value(ef);

	}

	public ExpressionFactor getFactor() {

		return this.factor;

	}

	public Value getValue() {

		return value;
	}

	private Value factor2Value(ExpressionFactor f) {

		/*
		 * Sono gestiti i casi in cui ci sono interi, decimali, stringhe e
		 * riferimenti di campi NON null e booleani
		 */
		// Value
		if (f.type == 1) {
			geco.model.util.Value v = f.value;
			SimpleValue simpleValue = null;
			/* Int */
			if (v.type == 1) {
				simpleValue = new SimpleValue(Integer.parseInt(v.value));
				/* Float */
			} else if (v.type == 2) {
				simpleValue = new SimpleValue(Double.parseDouble(v.value));
				/* Quoted String */
			} else if (v.type == 4) {
				String s = v.value.substring(1, v.value.length() - 1);
				simpleValue = new SimpleValue(s);
			}

			return simpleValue;

		// Manca ID???? forse non serve!!!
		// Function Js
		} else if(f.type == 3) {

            return new FunctionJsValue(f.function, f.functionParams);

		// FieldValue
		} else if (f.type == 5) {
			FieldValue fieldValue = new FieldValue(new FieldReference(alias, f.field.toString()));
			//FieldValue fieldValue = new FieldValue(new FieldReference(alias + f.toString().substring(1)));
			return fieldValue;
		}

		return null;
	}

	@Override
	public String toString() {
		if (operationType != null)
			return operationType.toString();
		else
			return value.toString();
	}

}
