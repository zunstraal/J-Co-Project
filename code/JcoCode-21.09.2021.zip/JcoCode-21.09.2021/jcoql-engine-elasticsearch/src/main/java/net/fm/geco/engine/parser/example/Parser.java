//PF forse questa classe era solo per fare un test

package net.fm.geco.engine.parser.example;

import net.fm.geco.engine.ESExecuteJCO;

public class Parser {

	
	public static void main(String[] args) {
		if(args.length != 3)
			throw new RuntimeException("Invalid arguments number: " + args.length + ". Must be 3");
		
		ESExecuteJCO ee = new ESExecuteJCO();
		
		ee.executeJCOQL(args[0], args[1].substring(1), args[2]);

	}
}
